// ATS Optimization utilities for Computer Science and all other fields
// Provides keyword optimization, section ordering, and formatting guidelines

export interface ATSOptimization {
  keywords: string[];
  sectionOrder: string[];
  formatGuidelines: string[];
  avoidList: string[];
  scoreBoosts: { action: string; boost: number }[];
}

// Computer Science specific ATS optimizations
export const csATSOptimizations: ATSOptimization = {
  keywords: [
    // Programming Languages
    'Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'C#', 'Go', 'Rust', 'Kotlin', 'Swift',
    'SQL', 'R', 'Scala', 'Ruby', 'PHP', 'Perl', 'Shell', 'Bash', 'PowerShell',
    
    // Frameworks & Libraries
    'React', 'Angular', 'Vue.js', 'Next.js', 'Node.js', 'Express', 'Django', 'Flask', 'FastAPI',
    'Spring Boot', 'ASP.NET', 'Ruby on Rails', 'Laravel', 'TensorFlow', 'PyTorch', 'Scikit-learn',
    
    // Cloud & DevOps
    'AWS', 'Azure', 'Google Cloud', 'GCP', 'Docker', 'Kubernetes', 'Terraform', 'Ansible',
    'Jenkins', 'GitLab CI', 'GitHub Actions', 'CircleCI', 'ArgoCD', 'Helm',
    
    // Databases
    'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'Elasticsearch', 'Cassandra', 'DynamoDB',
    'Oracle', 'SQL Server', 'SQLite', 'Neo4j', 'InfluxDB',
    
    // Concepts
    'RESTful API', 'GraphQL', 'Microservices', 'CI/CD', 'Agile', 'Scrum', 'DevOps', 'MLOps',
    'Machine Learning', 'Deep Learning', 'Data Structures', 'Algorithms', 'System Design',
    'Object-Oriented Programming', 'Functional Programming', 'Test-Driven Development',
    
    // Tools
    'Git', 'GitHub', 'GitLab', 'Bitbucket', 'JIRA', 'Confluence', 'Slack', 'VS Code',
    'IntelliJ IDEA', 'Postman', 'Swagger', 'Figma', 'Notion',
  ],
  
  sectionOrder: [
    'Summary',
    'Technical Skills',
    'Work Experience',
    'Projects',
    'Education',
    'Certifications',
    'Publications',
  ],
  
  formatGuidelines: [
    'Use standard section headings (Experience, Education, Skills)',
    'List programming languages and tools in a dedicated Skills section',
    'Quantify achievements (e.g., "reduced load time by 40%")',
    'Use action verbs: Developed, Implemented, Designed, Optimized, Led',
    'Include relevant GitHub or portfolio links',
    'Keep resume to 1-2 pages for most roles',
    'Use reverse chronological order for experience',
    'Include graduation year and GPA if > 3.5 or recent graduate',
  ],
  
  avoidList: [
    'Graphics, images, or icons within resume content',
    'Tables with complex formatting',
    'Headers and footers (ATS may not read them)',
    'Text boxes or columns created with tables',
    'Unusual fonts or special characters',
    'Abbreviations without full form first usage',
    'Personal pronouns (I, me, my)',
    'Generic objectives without specific role focus',
  ],
  
  scoreBoosts: [
    { action: 'Add quantified achievements', boost: 15 },
    { action: 'Include all listed skills from job description', boost: 20 },
    { action: 'Use exact keywords from job posting', boost: 25 },
    { action: 'Add relevant certifications', boost: 10 },
    { action: 'Include GitHub/portfolio links', boost: 5 },
    { action: 'Add projects with tech stack details', boost: 10 },
  ],
};

// Get ATS keywords for a specific role
export function getATSKeywordsForRole(roleId: string): string[] {
  const roleKeywords: Record<string, string[]> = {
    'software-engineer': [
      'software development', 'full-stack', 'backend', 'frontend', 'API', 
      'microservices', 'scalable', 'production', 'deployment', 'agile',
      ...csATSOptimizations.keywords,
    ],
    'data-scientist': [
      'machine learning', 'deep learning', 'statistical modeling', 'data analysis',
      'predictive modeling', 'NLP', 'computer vision', 'feature engineering',
      'Python', 'R', 'TensorFlow', 'PyTorch', 'SQL', 'Spark', 'Jupyter',
    ],
    'data-analyst': [
      'data analysis', 'SQL', 'Excel', 'Tableau', 'Power BI', 'reporting',
      'dashboards', 'KPIs', 'metrics', 'visualization', 'ETL', 'business intelligence',
    ],
    'frontend-developer': [
      'React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'responsive design',
      'Vue.js', 'Angular', 'Next.js', 'Tailwind', 'accessibility', 'performance',
    ],
    'backend-developer': [
      'Node.js', 'Python', 'Java', 'API design', 'database', 'PostgreSQL',
      'MongoDB', 'Redis', 'microservices', 'REST', 'GraphQL', 'security',
    ],
    'devops-engineer': [
      'CI/CD', 'Docker', 'Kubernetes', 'Terraform', 'AWS', 'Azure', 'GCP',
      'automation', 'infrastructure as code', 'monitoring', 'Jenkins', 'GitLab',
    ],
    'product-manager': [
      'product strategy', 'roadmap', 'user research', 'agile', 'scrum',
      'stakeholder management', 'prioritization', 'MVP', 'data-driven', 'KPIs',
    ],
  };
  
  return roleKeywords[roleId] || csATSOptimizations.keywords;
}

// Analyze resume content for ATS compatibility
export function analyzeATSCompatibility(content: {
  summary?: string;
  skills?: string[];
  experience?: { description: string }[];
  targetRole?: string;
}): {
  score: number;
  suggestions: string[];
  matchedKeywords: string[];
  missingKeywords: string[];
} {
  const targetKeywords = content.targetRole 
    ? getATSKeywordsForRole(content.targetRole)
    : csATSOptimizations.keywords;
  
  // Combine all content for analysis
  const allContent = [
    content.summary || '',
    ...(content.skills || []),
    ...(content.experience?.map(e => e.description) || []),
  ].join(' ').toLowerCase();
  
  const matchedKeywords: string[] = [];
  const missingKeywords: string[] = [];
  
  targetKeywords.forEach(keyword => {
    if (allContent.includes(keyword.toLowerCase())) {
      matchedKeywords.push(keyword);
    } else {
      missingKeywords.push(keyword);
    }
  });
  
  // Calculate score
  const keywordScore = (matchedKeywords.length / targetKeywords.length) * 40;
  
  const suggestions: string[] = [];
  let bonusScore = 0;
  
  // Check for quantified achievements
  const hasQuantified = /\d+%|\d+x|\$\d+|\d+ (users|customers|team|projects)/i.test(allContent);
  if (hasQuantified) {
    bonusScore += 15;
  } else {
    suggestions.push('Add quantified achievements (e.g., "increased performance by 40%")');
  }
  
  // Check for action verbs
  const actionVerbs = ['developed', 'implemented', 'designed', 'led', 'optimized', 'built', 'created', 'managed'];
  const hasActionVerbs = actionVerbs.some(verb => allContent.includes(verb));
  if (hasActionVerbs) {
    bonusScore += 10;
  } else {
    suggestions.push('Use strong action verbs (Developed, Implemented, Led, Optimized)');
  }
  
  // Add missing keyword suggestions
  if (missingKeywords.length > 0) {
    const topMissing = missingKeywords.slice(0, 5);
    suggestions.push(`Consider adding relevant keywords: ${topMissing.join(', ')}`);
  }
  
  const totalScore = Math.min(100, Math.round(keywordScore + bonusScore + 35));
  
  return {
    score: totalScore,
    suggestions,
    matchedKeywords,
    missingKeywords: missingKeywords.slice(0, 10),
  };
}

// Format content for maximum ATS compatibility
export function formatForATS(text: string): string {
  return text
    // Remove special characters that ATS might not read
    .replace(/[^\w\s.,;:!?()@#$%&*+-/]/g, '')
    // Normalize whitespace
    .replace(/\s+/g, ' ')
    // Trim
    .trim();
}

export default csATSOptimizations;
