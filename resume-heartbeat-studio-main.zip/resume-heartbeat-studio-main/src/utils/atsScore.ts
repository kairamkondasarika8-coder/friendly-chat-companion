import { ResumeData } from '@/stores/resumeStore';

interface ATSResult {
  score: number;
  suggestions: string[];
  breakdown: {
    category: string;
    score: number;
    maxScore: number;
    message: string;
  }[];
}

export const calculateATSScore = (resumeData: ResumeData): ATSResult => {
  const suggestions: string[] = [];
  const breakdown: ATSResult['breakdown'] = [];
  
  // Personal Info (25 points max)
  let personalScore = 0;
  const { personalInfo } = resumeData;
  
  if (personalInfo.fullName.trim()) personalScore += 5;
  else suggestions.push('Add your full name');
  
  if (personalInfo.email.trim() && personalInfo.email.includes('@')) personalScore += 5;
  else suggestions.push('Add a valid email address');
  
  if (personalInfo.phone.trim()) personalScore += 5;
  else suggestions.push('Add your phone number');
  
  if (personalInfo.location.trim()) personalScore += 3;
  else suggestions.push('Add your location');
  
  if (personalInfo.summary.trim() && personalInfo.summary.length >= 50) personalScore += 7;
  else if (personalInfo.summary.trim()) {
    personalScore += 3;
    suggestions.push('Expand your professional summary (at least 50 characters)');
  } else {
    suggestions.push('Add a professional summary');
  }
  
  breakdown.push({
    category: 'Contact Information',
    score: personalScore,
    maxScore: 25,
    message: personalScore >= 20 ? 'Great contact details!' : 'Add missing contact information',
  });
  
  // Experience (30 points max)
  let experienceScore = 0;
  const { experience } = resumeData;
  
  if (experience.length >= 3) experienceScore += 10;
  else if (experience.length >= 2) {
    experienceScore += 7;
    suggestions.push('Add more work experience entries');
  } else if (experience.length >= 1) {
    experienceScore += 4;
    suggestions.push('Add more work experience (2-3 recommended)');
  } else {
    suggestions.push('Add your work experience');
  }
  
  // Check for detailed descriptions
  const detailedExperiences = experience.filter(
    (exp) => exp.description.trim().length >= 100
  );
  if (detailedExperiences.length >= experience.length && experience.length > 0) {
    experienceScore += 10;
  } else if (detailedExperiences.length > 0) {
    experienceScore += 5;
    suggestions.push('Add more detailed descriptions to your work experiences');
  } else if (experience.length > 0) {
    suggestions.push('Add detailed descriptions with accomplishments to each role');
  }
  
  // Check for action verbs and metrics
  const actionVerbs = ['led', 'managed', 'developed', 'created', 'increased', 'reduced', 'improved', 'achieved', 'implemented', 'designed'];
  const hasActionVerbs = experience.some((exp) =>
    actionVerbs.some((verb) => exp.description.toLowerCase().includes(verb))
  );
  if (hasActionVerbs) experienceScore += 5;
  else if (experience.length > 0) suggestions.push('Use action verbs in your experience descriptions (led, managed, achieved, etc.)');
  
  const hasMetrics = experience.some((exp) => /\d+%|\$\d+|\d+ (people|team|projects)/i.test(exp.description));
  if (hasMetrics) experienceScore += 5;
  else if (experience.length > 0) suggestions.push('Add quantifiable achievements with metrics (%, $, numbers)');
  
  breakdown.push({
    category: 'Work Experience',
    score: experienceScore,
    maxScore: 30,
    message: experienceScore >= 25 ? 'Strong experience section!' : 'Enhance your experience entries',
  });
  
  // Education (15 points max)
  let educationScore = 0;
  const { education } = resumeData;
  
  if (education.length >= 1) {
    educationScore += 8;
    if (education.some((edu) => edu.degree.trim() && edu.field.trim())) {
      educationScore += 7;
    } else {
      educationScore += 3;
      suggestions.push('Add degree and field of study details');
    }
  } else {
    suggestions.push('Add your education background');
  }
  
  breakdown.push({
    category: 'Education',
    score: educationScore,
    maxScore: 15,
    message: educationScore >= 12 ? 'Education section complete!' : 'Add education details',
  });
  
  // Skills (20 points max)
  let skillsScore = 0;
  const { skills } = resumeData;
  
  if (skills.length >= 8) skillsScore += 15;
  else if (skills.length >= 5) {
    skillsScore += 10;
    suggestions.push('Add more relevant skills (8+ recommended)');
  } else if (skills.length >= 3) {
    skillsScore += 6;
    suggestions.push('Add more skills to showcase your expertise');
  } else if (skills.length > 0) {
    skillsScore += 3;
    suggestions.push('Add more skills (at least 5-8 recommended)');
  } else {
    suggestions.push('Add your skills section');
  }
  
  // Check for skill variety
  const hasAdvancedSkills = skills.some((s) => s.level === 'advanced' || s.level === 'expert');
  if (hasAdvancedSkills && skills.length >= 3) skillsScore += 5;
  
  breakdown.push({
    category: 'Skills',
    score: skillsScore,
    maxScore: 20,
    message: skillsScore >= 15 ? 'Great skills section!' : 'Add more relevant skills',
  });
  
  // Projects (10 points max - bonus)
  let projectsScore = 0;
  const { projects } = resumeData;
  
  if (projects.length >= 2) projectsScore += 10;
  else if (projects.length >= 1) {
    projectsScore += 5;
    suggestions.push('Add more projects to showcase your work');
  } else {
    suggestions.push('Consider adding projects to demonstrate your skills');
  }
  
  breakdown.push({
    category: 'Projects',
    score: projectsScore,
    maxScore: 10,
    message: projectsScore >= 8 ? 'Projects showcase your abilities!' : 'Add projects to stand out',
  });
  
  // Calculate total
  const totalScore = Math.min(100, personalScore + experienceScore + educationScore + skillsScore + projectsScore);
  
  return {
    score: totalScore,
    suggestions: suggestions.slice(0, 5), // Return top 5 suggestions
    breakdown,
  };
};

export const getScoreColor = (score: number): string => {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-yellow-600';
  if (score >= 40) return 'text-orange-600';
  return 'text-red-600';
};

export const getScoreLabel = (score: number): string => {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Fair';
  return 'Needs Work';
};
