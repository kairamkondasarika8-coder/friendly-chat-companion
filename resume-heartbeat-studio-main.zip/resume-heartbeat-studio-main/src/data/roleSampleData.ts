// Comprehensive role-specific sample resume data for 100+ roles
// Each sample is fully filled with realistic dummy data - NO blank sections

export interface RoleSampleData {
  roleId: string;
  name: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  github?: string;
  portfolio?: string;
  summary: string;
  experience: {
    title: string;
    company: string;
    location: string;
    dates: string;
    bullets: string[];
  }[];
  education: {
    degree: string;
    school: string;
    dates: string;
    gpa?: string;
    honors?: string;
  }[];
  skills: Record<string, string>;
  projects?: {
    name: string;
    tech: string;
    description: string;
    link?: string;
  }[];
  certifications: string[];
  achievements?: string[];
  publications?: string[];
  languages?: string[];
}

// ============= TECHNOLOGY & DATA ROLES =============

export const dataScienceSample: RoleSampleData = {
  roleId: 'data-scientist',
  name: 'Dr. Priya Sharma',
  title: 'Senior Data Scientist',
  email: 'priya.sharma@email.com',
  phone: '+1 (415) 892-3456',
  location: 'San Francisco, CA',
  linkedin: 'linkedin.com/in/priyasharma-ds',
  github: 'github.com/priyasharma-ml',
  summary: 'Results-driven Data Scientist with 6+ years of experience in machine learning, predictive modeling, and advanced analytics. Led cross-functional teams to build ML pipelines that increased revenue by $12M annually. Published researcher with expertise in NLP, deep learning, and statistical modeling.',
  experience: [
    {
      title: 'Senior Data Scientist',
      company: 'Netflix Inc.',
      location: 'Los Gatos, CA',
      dates: '2021 - Present',
      bullets: [
        'Built recommendation system improving user engagement by 23% across 200M+ subscribers',
        'Developed NLP-based content classification model with 94% accuracy for 15K+ titles',
        'Led team of 4 data scientists delivering A/B testing framework reducing experiment time by 40%',
        'Implemented real-time fraud detection system saving $8M annually in subscription fraud'
      ]
    },
    {
      title: 'Data Scientist',
      company: 'Uber Technologies',
      location: 'San Francisco, CA',
      dates: '2018 - 2021',
      bullets: [
        'Designed demand forecasting model reducing driver wait times by 18% in 50+ cities',
        'Created customer churn prediction model achieving 89% precision, retaining $5M in revenue',
        'Built automated feature engineering pipeline processing 2TB+ daily ride data',
        'Collaborated with product team to deploy surge pricing optimization increasing revenue by 12%'
      ]
    }
  ],
  education: [
    {
      degree: 'Ph.D. Computer Science (Machine Learning)',
      school: 'Stanford University',
      dates: '2014 - 2018',
      honors: 'Dissertation: "Deep Learning Approaches for Sequential Data Analysis"'
    },
    {
      degree: 'B.Tech Computer Science',
      school: 'IIT Delhi',
      dates: '2010 - 2014',
      gpa: '9.2/10 CGPA'
    }
  ],
  skills: {
    'Machine Learning': 'TensorFlow, PyTorch, Scikit-learn, XGBoost, LightGBM',
    'Programming': 'Python, R, SQL, Scala, PySpark',
    'Deep Learning': 'CNNs, RNNs, Transformers, GANs, Reinforcement Learning',
    'Tools & Platforms': 'AWS SageMaker, Databricks, Airflow, MLflow, Kubernetes',
    'Visualization': 'Tableau, Power BI, Matplotlib, Plotly, D3.js'
  },
  projects: [
    {
      name: 'Customer Lifetime Value Prediction',
      tech: 'Python, XGBoost, AWS',
      description: 'End-to-end ML pipeline predicting CLV with 92% accuracy for 10M+ customers'
    },
    {
      name: 'Real-time Sentiment Analysis API',
      tech: 'BERT, FastAPI, Docker',
      description: 'Production NLP service processing 50K tweets/hour with 95% accuracy'
    }
  ],
  certifications: ['AWS Machine Learning Specialty', 'Google Cloud Professional ML Engineer', 'TensorFlow Developer Certificate', 'Deep Learning Specialization - Coursera'],
  publications: ['Neural Networks for Time Series Forecasting - ICML 2020', 'Efficient Transformers for NLP - ACL 2019'],
  achievements: ['Best Paper Award - KDD 2021', 'Led Netflix Data Science Hackathon Winner Team']
};

export const dataEngineerSample: RoleSampleData = {
  roleId: 'data-engineer',
  name: 'Marcus Johnson',
  title: 'Senior Data Engineer',
  email: 'marcus.johnson@email.com',
  phone: '+1 (206) 734-5678',
  location: 'Seattle, WA',
  linkedin: 'linkedin.com/in/marcusjohnson-de',
  github: 'github.com/marcusjohnson',
  summary: 'Data Engineer with 7+ years designing scalable data infrastructure processing 50+ petabytes daily. Expert in building real-time streaming pipelines, data lakes, and ETL systems. Reduced data processing costs by 60% through architecture optimization at Fortune 500 companies.',
  experience: [
    {
      title: 'Senior Data Engineer',
      company: 'Amazon Web Services',
      location: 'Seattle, WA',
      dates: '2020 - Present',
      bullets: [
        'Architected data lake solution processing 50PB+ daily across 200+ AWS accounts',
        'Built real-time streaming pipeline using Kafka and Flink handling 2M events/second',
        'Reduced data warehouse costs by 60% through query optimization and partitioning strategies',
        'Led migration of 500+ legacy ETL jobs to Apache Airflow, improving reliability to 99.9%'
      ]
    },
    {
      title: 'Data Engineer',
      company: 'Spotify',
      location: 'New York, NY',
      dates: '2017 - 2020',
      bullets: [
        'Designed data pipelines powering personalization features for 350M+ users',
        'Implemented data quality framework reducing data incidents by 75%',
        'Built unified event tracking system processing 500B+ events monthly',
        'Developed automated data lineage tool adopted by 50+ engineering teams'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Computer Science',
      school: 'University of Washington',
      dates: '2015 - 2017',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.S. Computer Engineering',
      school: 'Georgia Tech',
      dates: '2011 - 2015',
      gpa: '3.8/4.0'
    }
  ],
  skills: {
    'Big Data': 'Apache Spark, Hadoop, Flink, Kafka, Hive, Presto',
    'Cloud Platforms': 'AWS (Redshift, S3, Glue, EMR), GCP (BigQuery), Azure',
    'Databases': 'PostgreSQL, MySQL, MongoDB, Cassandra, DynamoDB, Redis',
    'Programming': 'Python, Scala, Java, SQL, Bash',
    'Orchestration': 'Airflow, Luigi, Dagster, Prefect, dbt'
  },
  projects: [
    {
      name: 'Real-time Analytics Platform',
      tech: 'Kafka, Flink, ClickHouse',
      description: 'Sub-second analytics dashboard processing 1M+ events/minute'
    },
    {
      name: 'Data Catalog & Lineage Tool',
      tech: 'Python, Neo4j, React',
      description: 'Enterprise data discovery platform tracking 10K+ datasets'
    }
  ],
  certifications: ['AWS Certified Data Analytics Specialty', 'Databricks Certified Data Engineer', 'Google Professional Data Engineer', 'Apache Kafka Certification'],
  achievements: ['AWS Community Builder 2023', 'Speaker at DataEngConf 2022']
};

export const dataAnalystSample: RoleSampleData = {
  roleId: 'data-analyst',
  name: 'Emily Chen',
  title: 'Senior Data Analyst',
  email: 'emily.chen@email.com',
  phone: '+1 (312) 456-7890',
  location: 'Chicago, IL',
  linkedin: 'linkedin.com/in/emilychen-analytics',
  summary: 'Data Analyst with 5+ years transforming complex datasets into actionable business insights. Expert in SQL, Python, and Tableau with proven track record of driving data-informed decisions that increased revenue by $15M. Strong communicator bridging technical and business teams.',
  experience: [
    {
      title: 'Senior Data Analyst',
      company: 'McKinsey & Company',
      location: 'Chicago, IL',
      dates: '2021 - Present',
      bullets: [
        'Led analytics for Fortune 100 retail client, identifying $25M cost optimization opportunities',
        'Built executive dashboard tracking 50+ KPIs across 12 business units, adopted by C-suite',
        'Developed customer segmentation model increasing campaign ROI by 45%',
        'Mentored team of 3 junior analysts on advanced SQL and visualization techniques'
      ]
    },
    {
      title: 'Data Analyst',
      company: 'Deloitte Consulting',
      location: 'New York, NY',
      dates: '2018 - 2021',
      bullets: [
        'Analyzed 5M+ transaction records identifying fraud patterns saving $3M annually',
        'Created automated reporting suite reducing manual effort by 20 hours/week',
        'Designed A/B testing framework for e-commerce client improving conversion by 18%',
        'Presented insights to senior leadership driving strategic product decisions'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Business Analytics',
      school: 'Northwestern University',
      dates: '2016 - 2018',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.A. Economics',
      school: 'University of Michigan',
      dates: '2012 - 2016',
      honors: 'Magna Cum Laude'
    }
  ],
  skills: {
    'Analytics Tools': 'SQL, Python, R, Excel (Advanced), Google Analytics',
    'Visualization': 'Tableau, Power BI, Looker, Google Data Studio',
    'Databases': 'PostgreSQL, MySQL, BigQuery, Snowflake, Redshift',
    'Statistical': 'Regression Analysis, A/B Testing, Cohort Analysis, Forecasting',
    'Business': 'KPI Development, Executive Reporting, Stakeholder Management'
  },
  projects: [
    {
      name: 'Revenue Analytics Dashboard',
      tech: 'Tableau, SQL, Python',
      description: 'Real-time dashboard tracking $500M+ annual revenue across regions'
    },
    {
      name: 'Customer Churn Analysis',
      tech: 'Python, Scikit-learn',
      description: 'Predictive model achieving 85% accuracy in identifying at-risk customers'
    }
  ],
  certifications: ['Google Data Analytics Professional Certificate', 'Tableau Desktop Specialist', 'Microsoft Power BI Data Analyst', 'SQL Advanced Certification - HackerRank'],
  achievements: ['Deloitte Analytics Excellence Award 2020', 'Published in Harvard Business Review Analytics']
};

export const aiEngineerSample: RoleSampleData = {
  roleId: 'ai-engineer',
  name: 'Aditya Patel',
  title: 'AI/ML Engineer',
  email: 'aditya.patel@email.com',
  phone: '+1 (650) 234-5678',
  location: 'Palo Alto, CA',
  linkedin: 'linkedin.com/in/adityapatel-ai',
  github: 'github.com/adityapatel-ai',
  summary: 'AI Engineer with 5+ years building production-grade machine learning systems and LLM applications. Led development of generative AI products serving 10M+ users. Expert in deep learning, MLOps, and scalable AI infrastructure with 3 patents in natural language processing.',
  experience: [
    {
      title: 'Senior AI Engineer',
      company: 'OpenAI',
      location: 'San Francisco, CA',
      dates: '2022 - Present',
      bullets: [
        'Developed fine-tuning infrastructure for GPT models used by 100M+ users globally',
        'Built RAG-based knowledge retrieval system improving response accuracy by 35%',
        'Optimized inference pipeline reducing latency by 40% while maintaining model quality',
        'Led team of 6 engineers shipping enterprise AI features generating $50M ARR'
      ]
    },
    {
      title: 'Machine Learning Engineer',
      company: 'Google DeepMind',
      location: 'Mountain View, CA',
      dates: '2019 - 2022',
      bullets: [
        'Contributed to AlphaFold protein structure prediction achieving breakthrough accuracy',
        'Built distributed training infrastructure for models with 100B+ parameters',
        'Developed novel attention mechanisms improving transformer efficiency by 25%',
        'Published 4 papers at top-tier ML conferences (NeurIPS, ICML, ICLR)'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Artificial Intelligence',
      school: 'MIT',
      dates: '2017 - 2019',
      gpa: '4.0/4.0'
    },
    {
      degree: 'B.Tech Computer Science',
      school: 'IIT Bombay',
      dates: '2013 - 2017',
      honors: 'Gold Medalist - Department Rank 1'
    }
  ],
  skills: {
    'Deep Learning': 'PyTorch, TensorFlow, JAX, Transformers, Hugging Face',
    'LLMs & GenAI': 'GPT, LLaMA, BERT, RAG, LangChain, Prompt Engineering',
    'MLOps': 'MLflow, Kubeflow, Weights & Biases, Ray, NVIDIA Triton',
    'Infrastructure': 'CUDA, AWS SageMaker, GCP Vertex AI, Docker, Kubernetes',
    'Languages': 'Python, C++, CUDA, Rust'
  },
  projects: [
    {
      name: 'Enterprise LLM Platform',
      tech: 'GPT-4, LangChain, FastAPI',
      description: 'Secure AI assistant for Fortune 500 with 99.9% uptime serving 100K daily queries'
    },
    {
      name: 'Multimodal AI Search',
      tech: 'CLIP, FAISS, PyTorch',
      description: 'Visual search engine processing 1B+ images with sub-100ms latency'
    }
  ],
  certifications: ['NVIDIA Deep Learning Institute', 'Google Cloud ML Engineer', 'AWS Machine Learning Specialty', 'DeepLearning.AI Specialization'],
  publications: ['Efficient Transformers for Long Sequences - NeurIPS 2021', 'Scalable Multi-Task Learning - ICML 2020'],
  achievements: ['3 US Patents in NLP', 'MIT Technology Review Innovator Under 35']
};

export const mlEngineerSample: RoleSampleData = {
  roleId: 'ml-engineer',
  name: 'Sarah Williams',
  title: 'Machine Learning Engineer',
  email: 'sarah.williams@email.com',
  phone: '+1 (425) 678-9012',
  location: 'Bellevue, WA',
  linkedin: 'linkedin.com/in/sarahwilliams-ml',
  github: 'github.com/sarahwilliams-ml',
  summary: 'Machine Learning Engineer with 6+ years deploying ML systems at scale. Expert in MLOps, model optimization, and production ML infrastructure. Deployed 50+ models serving 100M+ predictions daily with 99.99% uptime. Strong focus on responsible AI and model fairness.',
  experience: [
    {
      title: 'Senior ML Engineer',
      company: 'Microsoft Azure AI',
      location: 'Bellevue, WA',
      dates: '2020 - Present',
      bullets: [
        'Built ML platform serving 100M+ predictions/day across Azure Cognitive Services',
        'Reduced model deployment time from weeks to hours through automated CI/CD pipelines',
        'Implemented model monitoring system detecting drift with 95% accuracy',
        'Led initiative on responsible AI, reducing bias in 20+ production models by 40%'
      ]
    },
    {
      title: 'ML Engineer',
      company: 'LinkedIn',
      location: 'Sunnyvale, CA',
      dates: '2017 - 2020',
      bullets: [
        'Developed job recommendation model increasing apply rates by 28% for 800M+ users',
        'Built real-time feature store processing 10B+ events daily',
        'Optimized model serving reducing inference latency by 60% saving $2M/year',
        'Mentored 5 junior engineers on ML best practices and production deployment'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Machine Learning',
      school: 'Carnegie Mellon University',
      dates: '2015 - 2017',
      gpa: '3.95/4.0'
    },
    {
      degree: 'B.S. Computer Science',
      school: 'UC Berkeley',
      dates: '2011 - 2015',
      honors: 'Summa Cum Laude'
    }
  ],
  skills: {
    'ML Frameworks': 'PyTorch, TensorFlow, Scikit-learn, XGBoost, LightGBM',
    'MLOps': 'MLflow, Kubeflow, Airflow, DVC, Feature Store, Model Registry',
    'Infrastructure': 'Kubernetes, Docker, Terraform, AWS/GCP/Azure',
    'Programming': 'Python, Java, Scala, Go, SQL',
    'Monitoring': 'Prometheus, Grafana, DataDog, Model Drift Detection'
  },
  projects: [
    {
      name: 'End-to-End ML Platform',
      tech: 'Kubeflow, MLflow, Kubernetes',
      description: 'Self-service ML platform enabling 200+ data scientists to deploy models'
    },
    {
      name: 'Real-time Fraud Detection',
      tech: 'Kafka, Flink, XGBoost',
      description: 'Sub-50ms fraud scoring system processing 10K transactions/second'
    }
  ],
  certifications: ['AWS Machine Learning Specialty', 'Google Cloud ML Engineer', 'Kubernetes Administrator (CKA)', 'MLOps Specialization - Coursera'],
  achievements: ['Microsoft Patent: ML Model Optimization', 'LinkedIn ML Excellence Award 2019']
};

// ============= SOFTWARE DEVELOPMENT ROLES =============

export const softwareEngineerSample: RoleSampleData = {
  roleId: 'software-engineer',
  name: 'Alex Thompson',
  title: 'Senior Software Engineer',
  email: 'alex.thompson@email.com',
  phone: '+1 (408) 567-8901',
  location: 'San Jose, CA',
  linkedin: 'linkedin.com/in/alexthompson-dev',
  github: 'github.com/alexthompson',
  summary: 'Senior Software Engineer with 8+ years building scalable distributed systems. Expert in microservices architecture, cloud-native development, and system design. Led teams delivering products serving 50M+ users. Passionate about code quality, mentoring, and engineering excellence.',
  experience: [
    {
      title: 'Senior Software Engineer',
      company: 'Stripe',
      location: 'San Francisco, CA',
      dates: '2020 - Present',
      bullets: [
        'Architected payment processing system handling $500B+ annual transaction volume',
        'Led team of 8 engineers building real-time fraud detection reducing losses by 35%',
        'Designed API rate limiting system supporting 10K+ requests/second with 99.99% uptime',
        'Mentored 12 engineers on distributed systems and code review best practices'
      ]
    },
    {
      title: 'Software Engineer',
      company: 'Airbnb',
      location: 'San Francisco, CA',
      dates: '2016 - 2020',
      bullets: [
        'Built search ranking system improving booking conversion by 18% for 7M+ listings',
        'Developed real-time pricing engine processing 100K+ price updates/minute',
        'Led migration from monolith to microservices reducing deployment time by 80%',
        'Implemented automated testing framework increasing code coverage to 95%'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Computer Science',
      school: 'Stanford University',
      dates: '2014 - 2016',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.S. Computer Science',
      school: 'University of Illinois Urbana-Champaign',
      dates: '2010 - 2014',
      honors: 'Dean\'s List, James Scholar'
    }
  ],
  skills: {
    'Languages': 'Java, Python, Go, TypeScript, Kotlin, Rust',
    'Backend': 'Spring Boot, Node.js, gRPC, GraphQL, REST APIs',
    'Databases': 'PostgreSQL, MongoDB, Redis, Elasticsearch, Cassandra',
    'Cloud & DevOps': 'AWS, GCP, Kubernetes, Docker, Terraform, CI/CD',
    'Architecture': 'Microservices, Event-Driven, CQRS, Domain-Driven Design'
  },
  projects: [
    {
      name: 'Distributed Task Queue',
      tech: 'Go, Redis, Kubernetes',
      description: 'High-throughput job processing system handling 5M+ tasks/day'
    },
    {
      name: 'API Gateway',
      tech: 'Go, gRPC, Envoy',
      description: 'Enterprise gateway with rate limiting, auth, and observability'
    }
  ],
  certifications: ['AWS Solutions Architect Professional', 'Google Cloud Professional Architect', 'Kubernetes Administrator (CKA)', 'System Design Certification'],
  achievements: ['Stripe Engineering Excellence Award 2022', 'Open Source Contributor - 5K+ GitHub Stars']
};

export const frontendDeveloperSample: RoleSampleData = {
  roleId: 'frontend-developer',
  name: 'Jessica Kim',
  title: 'Senior Frontend Developer',
  email: 'jessica.kim@email.com',
  phone: '+1 (646) 234-5678',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/jessicakim-frontend',
  github: 'github.com/jessicakim-ui',
  portfolio: 'jessicakim.dev',
  summary: 'Frontend Developer with 6+ years crafting exceptional user experiences. Expert in React, TypeScript, and modern CSS. Built component libraries used by 100+ developers. Passionate about accessibility, performance optimization, and design systems.',
  experience: [
    {
      title: 'Senior Frontend Developer',
      company: 'Figma',
      location: 'San Francisco, CA (Remote)',
      dates: '2021 - Present',
      bullets: [
        'Built collaborative editing features used by 4M+ designers in real-time',
        'Developed design system component library with 200+ components and 95% accessibility score',
        'Optimized canvas rendering reducing frame time by 40% for complex designs',
        'Led frontend architecture migration to React 18 improving performance by 30%'
      ]
    },
    {
      title: 'Frontend Developer',
      company: 'Shopify',
      location: 'Toronto, Canada',
      dates: '2018 - 2021',
      bullets: [
        'Built checkout optimization features increasing conversion by 15% across 1M+ stores',
        'Developed Polaris design system components used by 500+ internal developers',
        'Implemented lazy loading and code splitting reducing bundle size by 45%',
        'Mentored 4 junior developers on React patterns and testing best practices'
      ]
    }
  ],
  education: [
    {
      degree: 'B.S. Computer Science',
      school: 'University of Waterloo',
      dates: '2014 - 2018',
      gpa: '3.8/4.0',
      honors: 'Co-op Program with 5 Industry Placements'
    }
  ],
  skills: {
    'Frontend': 'React, TypeScript, Next.js, Vue.js, Redux, Zustand',
    'Styling': 'Tailwind CSS, CSS-in-JS, SCSS, CSS Modules, Framer Motion',
    'Testing': 'Jest, React Testing Library, Cypress, Playwright, Storybook',
    'Performance': 'Core Web Vitals, Lighthouse, Webpack, Vite, Bundle Analysis',
    'Tools': 'Git, Figma, Chrome DevTools, GitHub Actions, Vercel'
  },
  projects: [
    {
      name: 'React Component Library',
      tech: 'React, TypeScript, Storybook',
      description: 'Open-source UI library with 50+ components and 3K+ GitHub stars',
      link: 'github.com/jessicakim/react-ui'
    },
    {
      name: 'E-commerce Starter Kit',
      tech: 'Next.js, Tailwind, Stripe',
      description: 'Production-ready template powering 200+ online stores'
    }
  ],
  certifications: ['Meta Frontend Developer Certificate', 'Google UX Design Certificate', 'Web Accessibility Specialist (WAS)', 'JavaScript Advanced - HackerRank'],
  achievements: ['Shopify Hack Days Winner 2020', 'React Conf Speaker 2022']
};

export const backendDeveloperSample: RoleSampleData = {
  roleId: 'backend-developer',
  name: 'Michael Rodriguez',
  title: 'Senior Backend Developer',
  email: 'michael.rodriguez@email.com',
  phone: '+1 (512) 345-6789',
  location: 'Austin, TX',
  linkedin: 'linkedin.com/in/michaelrodriguez-backend',
  github: 'github.com/michaelrodriguez',
  summary: 'Backend Developer with 7+ years building high-performance APIs and distributed systems. Expert in Node.js, Python, and database optimization. Scaled systems from startup to 10M+ users. Strong advocate for clean code, testing, and documentation.',
  experience: [
    {
      title: 'Senior Backend Developer',
      company: 'Twilio',
      location: 'Austin, TX',
      dates: '2020 - Present',
      bullets: [
        'Designed messaging API handling 100B+ messages/year with 99.99% uptime',
        'Built real-time notification system reducing delivery latency by 60%',
        'Led database optimization reducing query times by 75% saving $500K/year',
        'Architected event-driven system processing 500K events/second'
      ]
    },
    {
      title: 'Backend Developer',
      company: 'Atlassian',
      location: 'San Francisco, CA',
      dates: '2017 - 2020',
      bullets: [
        'Developed JIRA API endpoints used by 180K+ organizations',
        'Built webhook system delivering 50M+ events daily with guaranteed delivery',
        'Implemented caching layer reducing database load by 70%',
        'Created developer documentation increasing API adoption by 40%'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Software Engineering',
      school: 'University of Texas at Austin',
      dates: '2015 - 2017',
      gpa: '3.85/4.0'
    },
    {
      degree: 'B.S. Computer Science',
      school: 'Texas A&M University',
      dates: '2011 - 2015',
      gpa: '3.7/4.0'
    }
  ],
  skills: {
    'Languages': 'Node.js, Python, Java, Go, TypeScript',
    'Frameworks': 'Express, NestJS, FastAPI, Django, Spring Boot',
    'Databases': 'PostgreSQL, MongoDB, Redis, Elasticsearch, DynamoDB',
    'Message Queues': 'Kafka, RabbitMQ, SQS, Redis Pub/Sub',
    'DevOps': 'Docker, Kubernetes, AWS, Terraform, GitHub Actions'
  },
  projects: [
    {
      name: 'API Rate Limiter',
      tech: 'Go, Redis, gRPC',
      description: 'Distributed rate limiting service handling 1M+ requests/second'
    },
    {
      name: 'Event Sourcing Framework',
      tech: 'Node.js, Kafka, PostgreSQL',
      description: 'CQRS/ES library adopted by 3 enterprise teams'
    }
  ],
  certifications: ['AWS Developer Associate', 'MongoDB Certified Developer', 'PostgreSQL Administration', 'Node.js Services Developer'],
  achievements: ['Twilio Engineering Award 2022', 'Open Source: 2K+ npm package downloads/week']
};

export const fullstackDeveloperSample: RoleSampleData = {
  roleId: 'fullstack-developer',
  name: 'David Park',
  title: 'Full Stack Developer',
  email: 'david.park@email.com',
  phone: '+1 (206) 456-7890',
  location: 'Seattle, WA',
  linkedin: 'linkedin.com/in/davidpark-fullstack',
  github: 'github.com/davidpark-dev',
  summary: 'Full Stack Developer with 5+ years building end-to-end web applications. Proficient in React, Node.js, and cloud infrastructure. Delivered 20+ production applications from concept to deployment. Strong problem solver with startup and enterprise experience.',
  experience: [
    {
      title: 'Full Stack Developer',
      company: 'Notion',
      location: 'San Francisco, CA',
      dates: '2021 - Present',
      bullets: [
        'Built collaborative workspace features used by 20M+ users worldwide',
        'Developed real-time sync engine maintaining consistency across 100K concurrent editors',
        'Implemented API integrations enabling 5K+ third-party automations',
        'Led migration to edge computing reducing latency by 50% globally'
      ]
    },
    {
      title: 'Software Developer',
      company: 'Startup (YC W19)',
      location: 'Seattle, WA',
      dates: '2018 - 2021',
      bullets: [
        'Built MVP that secured $5M seed funding, grew to 100K users',
        'Developed full-stack application from scratch using React and Node.js',
        'Implemented payment system processing $2M+ monthly transactions',
        'Scaled infrastructure from 0 to 50K daily active users'
      ]
    }
  ],
  education: [
    {
      degree: 'B.S. Computer Science',
      school: 'University of Washington',
      dates: '2014 - 2018',
      gpa: '3.85/4.0',
      honors: 'Mary Gates Research Scholar'
    }
  ],
  skills: {
    'Frontend': 'React, TypeScript, Next.js, Vue.js, TailwindCSS',
    'Backend': 'Node.js, Python, Express, FastAPI, GraphQL',
    'Databases': 'PostgreSQL, MongoDB, Redis, Supabase, Prisma',
    'Cloud': 'AWS, Vercel, Docker, Kubernetes, Terraform',
    'Tools': 'Git, GitHub Actions, Jest, Cypress, Figma'
  },
  projects: [
    {
      name: 'SaaS Starter Template',
      tech: 'Next.js, Supabase, Stripe',
      description: 'Production-ready template with auth, payments, and dashboard - 1K+ GitHub stars'
    },
    {
      name: 'Real-time Chat Application',
      tech: 'React, Node.js, Socket.io',
      description: 'Scalable chat with 10K+ concurrent connections'
    }
  ],
  certifications: ['AWS Solutions Architect Associate', 'Meta Full-Stack Developer', 'MongoDB Developer', 'GraphQL Associate'],
  achievements: ['YC Hackathon Winner 2020', 'ProductHunt #1 Product of the Day']
};

export const cyberSecurityAnalystSample: RoleSampleData = {
  roleId: 'cybersecurity-analyst',
  name: 'James Wilson',
  title: 'Senior Security Analyst',
  email: 'james.wilson@email.com',
  phone: '+1 (703) 678-9012',
  location: 'Washington, DC',
  linkedin: 'linkedin.com/in/jameswilson-security',
  summary: 'Cybersecurity Analyst with 6+ years protecting enterprise systems and conducting threat assessments. Led incident response for Fortune 500 companies. Expert in penetration testing, SIEM, and compliance frameworks. Holds CISSP, CEH, and OSCP certifications.',
  experience: [
    {
      title: 'Senior Security Analyst',
      company: 'Palo Alto Networks',
      location: 'Santa Clara, CA',
      dates: '2020 - Present',
      bullets: [
        'Led security operations for 200+ enterprise clients protecting $50B+ in assets',
        'Developed threat detection rules reducing mean time to detect by 65%',
        'Conducted 50+ penetration tests identifying 300+ critical vulnerabilities',
        'Built automated incident response playbooks reducing MTTR by 40%'
      ]
    },
    {
      title: 'Security Analyst',
      company: 'Deloitte Cyber',
      location: 'Washington, DC',
      dates: '2017 - 2020',
      bullets: [
        'Performed security assessments for 20+ government agencies',
        'Led incident response for 15+ major security breaches',
        'Implemented SIEM solution monitoring 10K+ endpoints',
        'Developed security awareness training reaching 50K+ employees'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Cybersecurity',
      school: 'George Washington University',
      dates: '2015 - 2017',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.S. Information Security',
      school: 'Virginia Tech',
      dates: '2011 - 2015',
      honors: 'Summa Cum Laude'
    }
  ],
  skills: {
    'Security': 'Penetration Testing, Vulnerability Assessment, Threat Hunting, SIEM',
    'Tools': 'Splunk, CrowdStrike, Wireshark, Burp Suite, Metasploit, Nessus',
    'Frameworks': 'NIST, ISO 27001, SOC 2, HIPAA, PCI-DSS, MITRE ATT&CK',
    'Programming': 'Python, Bash, PowerShell, SQL',
    'Cloud Security': 'AWS Security, Azure Security Center, GCP Security'
  },
  projects: [
    {
      name: 'Threat Intelligence Platform',
      tech: 'Python, MISP, ElasticSearch',
      description: 'Automated threat intel aggregation from 50+ feeds'
    },
    {
      name: 'Security Automation Suite',
      tech: 'Python, Ansible, Terraform',
      description: 'Infrastructure-as-code security scanning pipeline'
    }
  ],
  certifications: ['CISSP', 'CEH (Certified Ethical Hacker)', 'OSCP', 'AWS Security Specialty', 'CompTIA Security+'],
  achievements: ['DEF CON CTF Finalist 2021', 'Published: "Modern Threat Detection Strategies"']
};

// ============= DESIGN ROLES =============

export const uiDesignerSample: RoleSampleData = {
  roleId: 'ui-designer',
  name: 'Isabella Garcia',
  title: 'Senior UI Designer',
  email: 'isabella.garcia@email.com',
  phone: '+1 (415) 789-0123',
  location: 'San Francisco, CA',
  linkedin: 'linkedin.com/in/isabellagarcia-design',
  portfolio: 'isabellagarcia.design',
  summary: 'UI Designer with 7+ years creating beautiful, intuitive interfaces for web and mobile. Expert in design systems, prototyping, and user-centered design. Led design for products reaching 50M+ users. Passionate about accessibility and inclusive design.',
  experience: [
    {
      title: 'Senior UI Designer',
      company: 'Slack',
      location: 'San Francisco, CA',
      dates: '2020 - Present',
      bullets: [
        'Led UI redesign of core messaging experience used by 18M+ daily active users',
        'Created and maintained design system with 500+ components across web and mobile',
        'Improved accessibility score from 72% to 98% through inclusive design practices',
        'Mentored team of 4 designers on interaction design and prototyping'
      ]
    },
    {
      title: 'UI Designer',
      company: 'Dropbox',
      location: 'San Francisco, CA',
      dates: '2017 - 2020',
      bullets: [
        'Designed file sharing experience increasing sharing rate by 35%',
        'Created motion design system establishing brand consistency',
        'Led user research studies informing product decisions for 700M+ users',
        'Collaborated with engineering to implement design system in React'
      ]
    }
  ],
  education: [
    {
      degree: 'BFA Graphic Design',
      school: 'Rhode Island School of Design',
      dates: '2013 - 2017',
      honors: 'Magna Cum Laude'
    }
  ],
  skills: {
    'Design Tools': 'Figma, Sketch, Adobe Creative Suite, Framer, Principle',
    'Prototyping': 'Figma Prototypes, Framer, InVision, ProtoPie',
    'Design Systems': 'Component Libraries, Design Tokens, Documentation',
    'Frontend': 'HTML/CSS, Tailwind, Basic React/JavaScript',
    'Methods': 'User Research, A/B Testing, Accessibility (WCAG), Responsive Design'
  },
  projects: [
    {
      name: 'Enterprise Design System',
      tech: 'Figma, Storybook, React',
      description: 'Scalable design system with 300+ components used by 50+ designers'
    },
    {
      name: 'Mobile Banking App',
      tech: 'Figma, ProtoPie',
      description: 'Award-winning fintech app design with 4.9 App Store rating'
    }
  ],
  certifications: ['Google UX Design Certificate', 'Interaction Design Foundation', 'Accessibility Fundamentals', 'Design Leadership Program'],
  achievements: ['Slack Design Excellence Award 2022', 'Featured in Awwwards - Mobile Excellence']
};

export const uxResearcherSample: RoleSampleData = {
  roleId: 'ux-researcher',
  name: 'Maya Johnson',
  title: 'Senior UX Researcher',
  email: 'maya.johnson@email.com',
  phone: '+1 (206) 890-1234',
  location: 'Seattle, WA',
  linkedin: 'linkedin.com/in/mayajohnson-uxr',
  summary: 'UX Researcher with 6+ years uncovering user insights that drive product strategy. Expert in mixed-methods research, usability testing, and research democratization. Research influenced products used by 100M+ users. Passionate about evidence-based design decisions.',
  experience: [
    {
      title: 'Senior UX Researcher',
      company: 'Microsoft',
      location: 'Redmond, WA',
      dates: '2020 - Present',
      bullets: [
        'Led research program for Microsoft Teams informing features for 270M+ users',
        'Established research operations framework adopted by 50+ product teams',
        'Conducted 200+ user interviews and 50+ usability studies annually',
        'Built research repository democratizing insights across 3 business units'
      ]
    },
    {
      title: 'UX Researcher',
      company: 'Amazon',
      location: 'Seattle, WA',
      dates: '2017 - 2020',
      bullets: [
        'Conducted research for Alexa voice interface improving task completion by 25%',
        'Designed and executed diary studies with 500+ participants',
        'Created user personas adopted across 10+ product lines',
        'Trained 30+ designers and PMs on research methods'
      ]
    }
  ],
  education: [
    {
      degree: 'Ph.D. Human-Computer Interaction',
      school: 'University of Washington',
      dates: '2013 - 2017'
    },
    {
      degree: 'M.S. Cognitive Psychology',
      school: 'Stanford University',
      dates: '2011 - 2013'
    }
  ],
  skills: {
    'Qualitative': 'User Interviews, Contextual Inquiry, Focus Groups, Diary Studies',
    'Quantitative': 'Surveys, A/B Testing, Analytics, Statistical Analysis',
    'Methods': 'Usability Testing, Card Sorting, Journey Mapping, Heuristic Evaluation',
    'Tools': 'UserTesting, Dovetail, Optimal Workshop, Qualtrics, SPSS, R',
    'Strategy': 'Research Ops, Stakeholder Management, Research Democratization'
  },
  projects: [
    {
      name: 'Voice UX Research Framework',
      tech: 'Mixed Methods',
      description: 'Methodology for evaluating voice interfaces adopted by 5 teams'
    },
    {
      name: 'Accessibility Research Program',
      tech: 'Inclusive Research',
      description: 'Research with users with disabilities informing WCAG compliance'
    }
  ],
  certifications: ['UXPA Certified UX Professional', 'Human Subjects Research Certification', 'Qualtrics Research Core', 'NNGroup UX Certification'],
  publications: ['Voice Interface Usability - CHI 2019', 'Research Democratization at Scale - UXPA 2021']
};

export const graphicDesignerSample: RoleSampleData = {
  roleId: 'graphic-designer',
  name: 'Alex Rivera',
  title: 'Senior Graphic Designer',
  email: 'alex.rivera@email.com',
  phone: '+1 (310) 123-4567',
  location: 'Los Angeles, CA',
  linkedin: 'linkedin.com/in/alexrivera-design',
  portfolio: 'alexrivera.design',
  summary: 'Graphic Designer with 8+ years creating impactful visual identities and marketing materials. Expert in brand design, illustration, and print production. Worked with Fortune 500 brands and award-winning agencies. Strong conceptual thinker with technical execution skills.',
  experience: [
    {
      title: 'Senior Graphic Designer',
      company: 'Pentagram',
      location: 'New York, NY',
      dates: '2019 - Present',
      bullets: [
        'Led brand identity projects for 15+ Fortune 500 clients including Nike, HBO, and Citi',
        'Designed packaging system for consumer brand generating $200M+ in sales',
        'Art directed photoshoots and video productions for global campaigns',
        'Mentored 6 junior designers on brand strategy and visual systems'
      ]
    },
    {
      title: 'Graphic Designer',
      company: 'IDEO',
      location: 'San Francisco, CA',
      dates: '2015 - 2019',
      bullets: [
        'Created visual identities for 20+ startups and established brands',
        'Designed pitch decks helping clients raise $100M+ in funding',
        'Developed illustration style guides for editorial publications',
        'Collaborated with strategists on brand positioning workshops'
      ]
    }
  ],
  education: [
    {
      degree: 'BFA Graphic Design',
      school: 'ArtCenter College of Design',
      dates: '2011 - 2015',
      honors: 'Graduate with Distinction'
    }
  ],
  skills: {
    'Design': 'Brand Identity, Typography, Layout, Illustration, Packaging',
    'Software': 'Adobe Creative Suite, Figma, After Effects, Cinema 4D',
    'Print': 'Pre-press, Color Management, Paper Stocks, Binding',
    'Digital': 'Social Media Graphics, Motion Graphics, Web Design',
    'Strategy': 'Brand Strategy, Art Direction, Creative Direction'
  },
  projects: [
    {
      name: 'Tech Startup Brand Identity',
      tech: 'Adobe CC, Figma',
      description: 'Complete brand system including logo, guidelines, and collateral'
    },
    {
      name: 'Publication Design System',
      tech: 'InDesign, Illustrator',
      description: 'Editorial design system for quarterly magazine - 100K circulation'
    }
  ],
  certifications: ['Adobe Certified Expert', 'Typography Masterclass', 'Brand Strategy Certificate', 'Print Production Professional'],
  achievements: ['D&AD Yellow Pencil 2022', 'Communication Arts Design Annual', 'AIGA 50 Books/50 Covers']
};

// ============= BUSINESS ROLES =============

export const productManagerSample: RoleSampleData = {
  roleId: 'product-manager',
  name: 'Rachel Foster',
  title: 'Senior Product Manager',
  email: 'rachel.foster@email.com',
  phone: '+1 (415) 234-5678',
  location: 'San Francisco, CA',
  linkedin: 'linkedin.com/in/rachelfoster-pm',
  summary: 'Product Manager with 7+ years driving product strategy and execution at high-growth tech companies. Led products generating $100M+ ARR. Expert in data-driven decision making, cross-functional leadership, and agile methodologies. Passionate about solving customer problems at scale.',
  experience: [
    {
      title: 'Senior Product Manager',
      company: 'Salesforce',
      location: 'San Francisco, CA',
      dates: '2020 - Present',
      bullets: [
        'Led product roadmap for Sales Cloud generating $4B+ annual revenue',
        'Launched AI-powered features increasing user productivity by 35%',
        'Managed cross-functional team of 25+ engineers, designers, and data scientists',
        'Drove 40% increase in enterprise customer adoption through strategic feature development'
      ]
    },
    {
      title: 'Product Manager',
      company: 'Zoom',
      location: 'San Jose, CA',
      dates: '2017 - 2020',
      bullets: [
        'Owned webinar product growing from 0 to 500K+ customers',
        'Defined and executed go-to-market strategy for 5 major feature launches',
        'Increased Net Promoter Score by 20 points through UX improvements',
        'Built and scaled product team from 3 to 12 members'
      ]
    }
  ],
  education: [
    {
      degree: 'MBA',
      school: 'Harvard Business School',
      dates: '2015 - 2017'
    },
    {
      degree: 'B.S. Computer Science',
      school: 'UC Berkeley',
      dates: '2010 - 2014',
      gpa: '3.8/4.0'
    }
  ],
  skills: {
    'Product': 'Roadmap Planning, PRDs, User Stories, A/B Testing, Analytics',
    'Strategy': 'Market Research, Competitive Analysis, Go-to-Market, Pricing',
    'Leadership': 'Cross-functional Leadership, Stakeholder Management, Agile/Scrum',
    'Tools': 'JIRA, Confluence, Amplitude, Mixpanel, Figma, SQL',
    'Technical': 'API Understanding, Data Analysis, Basic SQL/Python'
  },
  projects: [
    {
      name: 'AI Assistant Launch',
      tech: 'Strategy, GTM',
      description: 'Launched AI feature to 10M+ users with 95% satisfaction rate'
    },
    {
      name: 'Enterprise Expansion',
      tech: 'Strategy',
      description: 'Product strategy driving 200% growth in enterprise segment'
    }
  ],
  certifications: ['Pragmatic Product Management', 'PSPO (Professional Scrum Product Owner)', 'Google Analytics Certified', 'SQL for Product Managers'],
  achievements: ['Salesforce President\'s Club 2022', 'Product School Guest Lecturer']
};

export const businessAnalystSample: RoleSampleData = {
  roleId: 'business-analyst',
  name: 'Jennifer Lee',
  title: 'Senior Business Analyst',
  email: 'jennifer.lee@email.com',
  phone: '+1 (212) 345-6789',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/jenniferlee-ba',
  summary: 'Business Analyst with 6+ years bridging business needs and technology solutions. Expert in requirements gathering, process optimization, and stakeholder management. Delivered 30+ projects generating $50M+ in business value. Strong communicator with technical depth.',
  experience: [
    {
      title: 'Senior Business Analyst',
      company: 'JPMorgan Chase',
      location: 'New York, NY',
      dates: '2020 - Present',
      bullets: [
        'Led requirements for $50M digital transformation program across 5 business lines',
        'Designed process improvements reducing loan approval time by 60%',
        'Facilitated 100+ stakeholder workshops gathering requirements for enterprise systems',
        'Created business cases securing $10M+ in project funding'
      ]
    },
    {
      title: 'Business Analyst',
      company: 'Accenture',
      location: 'Chicago, IL',
      dates: '2017 - 2020',
      bullets: [
        'Delivered business analysis for 15+ clients across financial services and retail',
        'Developed requirements documentation for CRM implementation serving 5K+ users',
        'Built data models and process flows for enterprise integration projects',
        'Trained 20+ junior analysts on BA methodologies and tools'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Information Systems',
      school: 'NYU Stern School of Business',
      dates: '2015 - 2017',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.A. Economics',
      school: 'Cornell University',
      dates: '2011 - 2015'
    }
  ],
  skills: {
    'Analysis': 'Requirements Gathering, Gap Analysis, Process Modeling, Use Cases',
    'Tools': 'JIRA, Confluence, Visio, Lucidchart, SQL, Excel (Advanced)',
    'Methodologies': 'Agile, Waterfall, Business Process Modeling (BPMN)',
    'Data': 'SQL, Tableau, Power BI, Data Analysis, Reporting',
    'Domain': 'Financial Services, Banking, Payments, Risk Management'
  },
  projects: [
    {
      name: 'Digital Banking Platform',
      tech: 'Requirements, Process Design',
      description: 'Requirements for mobile banking app with 2M+ users'
    },
    {
      name: 'Risk Management System',
      tech: 'Business Analysis',
      description: 'Enterprise risk platform reducing compliance issues by 40%'
    }
  ],
  certifications: ['CBAP (Certified Business Analysis Professional)', 'PMI-PBA', 'Six Sigma Green Belt', 'Agile Business Analyst'],
  achievements: ['JPMorgan Excellence Award 2022', 'Published BA Best Practices Guide']
};

export const marketingManagerSample: RoleSampleData = {
  roleId: 'marketing-executive',
  name: 'Christina Martinez',
  title: 'Marketing Manager',
  email: 'christina.martinez@email.com',
  phone: '+1 (646) 456-7890',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/christinamartinez-marketing',
  summary: 'Marketing Manager with 6+ years driving growth through data-driven campaigns. Expert in digital marketing, brand strategy, and content marketing. Scaled customer acquisition 5x while reducing CAC by 40%. Passionate about building brands that resonate.',
  experience: [
    {
      title: 'Marketing Manager',
      company: 'HubSpot',
      location: 'Boston, MA (Remote)',
      dates: '2020 - Present',
      bullets: [
        'Led demand generation campaigns generating $15M+ pipeline annually',
        'Grew organic traffic 3x through SEO and content strategy',
        'Managed $2M annual marketing budget with 400% ROI',
        'Built and led team of 5 marketers across content, paid, and email'
      ]
    },
    {
      title: 'Digital Marketing Specialist',
      company: 'Mailchimp',
      location: 'Atlanta, GA',
      dates: '2017 - 2020',
      bullets: [
        'Executed paid campaigns across Google, Facebook, and LinkedIn generating 50K+ leads',
        'Developed email marketing strategy increasing engagement by 45%',
        'Created content strategy driving 100K+ monthly blog visitors',
        'Optimized conversion funnels improving lead-to-customer rate by 25%'
      ]
    }
  ],
  education: [
    {
      degree: 'MBA, Marketing Concentration',
      school: 'Columbia Business School',
      dates: '2018 - 2020'
    },
    {
      degree: 'B.A. Communications',
      school: 'Boston University',
      dates: '2013 - 2017'
    }
  ],
  skills: {
    'Digital Marketing': 'SEO, SEM, Social Media, Email Marketing, Content Marketing',
    'Analytics': 'Google Analytics, HubSpot, Mixpanel, Attribution Modeling',
    'Paid Media': 'Google Ads, Facebook Ads, LinkedIn Ads, Programmatic',
    'Tools': 'HubSpot, Marketo, Salesforce, Hootsuite, SEMrush, Ahrefs',
    'Strategy': 'Brand Strategy, Go-to-Market, Campaign Planning, Budget Management'
  },
  projects: [
    {
      name: 'Product Launch Campaign',
      tech: 'Multi-channel',
      description: 'GTM campaign generating 10K+ signups in first month'
    },
    {
      name: 'Brand Refresh Initiative',
      tech: 'Brand Strategy',
      description: 'Rebranding project increasing brand awareness by 60%'
    }
  ],
  certifications: ['Google Analytics Certified', 'HubSpot Inbound Marketing', 'Facebook Blueprint', 'Google Ads Certified'],
  achievements: ['HubSpot Partner of the Year 2022', 'MarketingProfs Top 50 Marketers']
};

// ============= FINANCE ROLES =============

export const financeAnalystSample: RoleSampleData = {
  roleId: 'finance-analyst',
  name: 'Andrew Thompson',
  title: 'Senior Financial Analyst',
  email: 'andrew.thompson@email.com',
  phone: '+1 (212) 567-8901',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/andrewthompson-finance',
  summary: 'Financial Analyst with 6+ years in corporate finance, FP&A, and investment analysis. Expert in financial modeling, valuation, and strategic planning. Advised on $500M+ in M&A transactions. CFA charterholder with strong communication and presentation skills.',
  experience: [
    {
      title: 'Senior Financial Analyst',
      company: 'Goldman Sachs',
      location: 'New York, NY',
      dates: '2020 - Present',
      bullets: [
        'Built financial models for $500M+ M&A transactions across tech sector',
        'Led quarterly forecasting for $2B revenue business unit with 98% accuracy',
        'Developed valuation frameworks adopted by 20+ analysts in division',
        'Presented investment recommendations to senior leadership driving $100M+ decisions'
      ]
    },
    {
      title: 'Financial Analyst',
      company: 'Morgan Stanley',
      location: 'New York, NY',
      dates: '2017 - 2020',
      bullets: [
        'Created DCF and LBO models for 30+ client engagements',
        'Performed industry research and competitive analysis for investment banking deals',
        'Built automated reporting tools reducing manual work by 15 hours/week',
        'Supported due diligence for 10+ private equity transactions'
      ]
    }
  ],
  education: [
    {
      degree: 'MBA, Finance',
      school: 'Wharton School, UPenn',
      dates: '2018 - 2020'
    },
    {
      degree: 'B.S. Finance',
      school: 'NYU Stern',
      dates: '2013 - 2017',
      gpa: '3.9/4.0',
      honors: 'Summa Cum Laude'
    }
  ],
  skills: {
    'Financial Modeling': 'DCF, LBO, M&A, Three-Statement Models, Sensitivity Analysis',
    'Valuation': 'Comparable Analysis, Precedent Transactions, Sum-of-Parts',
    'Tools': 'Excel (Expert), Bloomberg, Capital IQ, FactSet, Tableau',
    'Analysis': 'FP&A, Budgeting, Forecasting, Variance Analysis',
    'Reporting': 'Financial Presentations, Board Decks, Investor Relations'
  },
  projects: [
    {
      name: 'Tech M&A Advisory',
      tech: 'Financial Modeling',
      description: 'Led financial analysis for $300M acquisition'
    },
    {
      name: 'FP&A Automation',
      tech: 'Excel, Python',
      description: 'Automated forecasting reducing cycle time by 50%'
    }
  ],
  certifications: ['CFA Charterholder', 'Financial Modeling & Valuation Analyst (FMVA)', 'Bloomberg Market Concepts', 'Excel Expert Certification'],
  achievements: ['Goldman Sachs Analyst of the Year 2022', 'Morgan Stanley Excellence Award']
};

export const charteredAccountantSample: RoleSampleData = {
  roleId: 'chartered-accountant',
  name: 'Priya Mehta',
  title: 'Chartered Accountant',
  email: 'priya.mehta@email.com',
  phone: '+91 98765 43210',
  location: 'Mumbai, India',
  linkedin: 'linkedin.com/in/priyamehta-ca',
  summary: 'Chartered Accountant with 8+ years in audit, taxation, and financial advisory. Led audits for 50+ companies with combined revenue of ₹5000+ crores. Expert in Indian taxation, IFRS, and Ind AS. Strong track record of identifying cost savings and compliance improvements.',
  experience: [
    {
      title: 'Senior Manager - Audit',
      company: 'Deloitte India',
      location: 'Mumbai, India',
      dates: '2019 - Present',
      bullets: [
        'Led statutory audits for 15+ listed companies with revenue exceeding ₹2000 crores',
        'Managed team of 12 auditors across multiple concurrent engagements',
        'Identified ₹50 crores in tax savings through strategic planning for clients',
        'Implemented IFRS convergence projects for 5 multinational clients'
      ]
    },
    {
      title: 'Assistant Manager - Audit',
      company: 'KPMG India',
      location: 'Mumbai, India',
      dates: '2016 - 2019',
      bullets: [
        'Conducted audits for banking and financial services clients',
        'Performed tax assessments and GST compliance for 30+ companies',
        'Developed audit programs improving efficiency by 25%',
        'Trained 20+ junior staff on Ind AS and audit procedures'
      ]
    }
  ],
  education: [
    {
      degree: 'Chartered Accountant (CA)',
      school: 'ICAI (Institute of Chartered Accountants of India)',
      dates: '2012 - 2015',
      honors: 'All India Rank 45'
    },
    {
      degree: 'B.Com (Hons)',
      school: 'Shri Ram College of Commerce, Delhi University',
      dates: '2009 - 2012',
      gpa: '85%'
    }
  ],
  skills: {
    'Audit': 'Statutory Audit, Internal Audit, Risk Assessment, Controls Testing',
    'Taxation': 'Income Tax, GST, Transfer Pricing, International Tax',
    'Standards': 'Ind AS, IFRS, Indian GAAP, Companies Act 2013',
    'Tools': 'SAP, Tally, Excel (Advanced), ACL, TeamMate',
    'Advisory': 'Due Diligence, Valuations, Restructuring, IPO Advisory'
  },
  projects: [
    {
      name: 'IPO Readiness',
      tech: 'DRHP, Audit',
      description: 'Led audit workstreams for ₹1000 crore IPO'
    },
    {
      name: 'GST Implementation',
      tech: 'Compliance',
      description: 'Managed GST transition for manufacturing conglomerate'
    }
  ],
  certifications: ['Chartered Accountant (CA)', 'DISA (Diploma in Information Systems Audit)', 'Certified Fraud Examiner (CFE)', 'IFRS Certificate - ACCA'],
  achievements: ['Deloitte Impact Award 2022', 'ICAI Best Research Paper 2020']
};

// ============= HR ROLES =============

export const hrManagerSample: RoleSampleData = {
  roleId: 'hr-manager',
  name: 'Amanda Brooks',
  title: 'HR Manager',
  email: 'amanda.brooks@email.com',
  phone: '+1 (408) 678-9012',
  location: 'San Jose, CA',
  linkedin: 'linkedin.com/in/amandabrooks-hr',
  summary: 'HR Manager with 7+ years building high-performing teams and fostering inclusive cultures. Expert in talent acquisition, employee engagement, and HR operations. Scaled organizations from 50 to 500+ employees. SHRM-SCP certified with strong business acumen.',
  experience: [
    {
      title: 'HR Manager',
      company: 'Zoom Video Communications',
      location: 'San Jose, CA',
      dates: '2020 - Present',
      bullets: [
        'Led HR operations for engineering organization of 800+ employees',
        'Reduced time-to-hire by 40% through process optimization and ATS implementation',
        'Designed and launched DEI programs increasing diverse hiring by 50%',
        'Implemented employee engagement initiatives improving eNPS from 45 to 72'
      ]
    },
    {
      title: 'Senior HR Business Partner',
      company: 'LinkedIn',
      location: 'Sunnyvale, CA',
      dates: '2016 - 2020',
      bullets: [
        'Partnered with 5 VP-level leaders supporting 400+ employees',
        'Developed performance management framework adopted company-wide',
        'Led compensation review ensuring market competitiveness for 200+ roles',
        'Managed employee relations cases maintaining 95% resolution rate'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Human Resources Management',
      school: 'Cornell University ILR School',
      dates: '2014 - 2016'
    },
    {
      degree: 'B.A. Psychology',
      school: 'UCLA',
      dates: '2010 - 2014'
    }
  ],
  skills: {
    'HR Operations': 'Talent Acquisition, Onboarding, Performance Management, HRIS',
    'Employee Relations': 'Conflict Resolution, Policy Development, Investigations',
    'Strategy': 'Workforce Planning, Compensation, Benefits, DEI',
    'Tools': 'Workday, Greenhouse, Lever, BambooHR, LinkedIn Recruiter',
    'Compliance': 'Employment Law, FMLA, ADA, EEO, I-9'
  },
  projects: [
    {
      name: 'Hybrid Work Policy',
      tech: 'Policy Design',
      description: 'Developed flexible work program for 2K+ employees'
    },
    {
      name: 'Talent Analytics Dashboard',
      tech: 'Workday, Tableau',
      description: 'Built HR analytics platform tracking 20+ metrics'
    }
  ],
  certifications: ['SHRM-SCP', 'PHR (Professional in Human Resources)', 'LinkedIn Talent Insights', 'Diversity & Inclusion Certificate - Cornell'],
  achievements: ['LinkedIn HR Excellence Award 2019', 'SHRM Conference Speaker 2022']
};

// ============= HEALTHCARE ROLES =============

export const doctorSample: RoleSampleData = {
  roleId: 'doctor',
  name: 'Dr. Robert Chen',
  title: 'Internal Medicine Physician',
  email: 'robert.chen.md@email.com',
  phone: '+1 (617) 789-0123',
  location: 'Boston, MA',
  linkedin: 'linkedin.com/in/drrobertchen',
  summary: 'Board-certified Internal Medicine physician with 10+ years providing comprehensive patient care. Fellowship-trained in Cardiology with expertise in preventive medicine and chronic disease management. Published researcher with 15+ peer-reviewed publications.',
  experience: [
    {
      title: 'Attending Physician - Internal Medicine',
      company: 'Massachusetts General Hospital',
      location: 'Boston, MA',
      dates: '2018 - Present',
      bullets: [
        'Manage panel of 1,500+ patients with complex chronic conditions',
        'Supervise and mentor 15+ medical residents and students annually',
        'Lead quality improvement initiatives reducing hospital readmissions by 25%',
        'Serve on Hospital Quality Committee driving patient safety protocols'
      ]
    },
    {
      title: 'Internal Medicine Resident',
      company: 'Johns Hopkins Hospital',
      location: 'Baltimore, MD',
      dates: '2015 - 2018',
      bullets: [
        'Completed 3-year residency program in Internal Medicine',
        'Managed 15-20 inpatients daily in high-acuity academic setting',
        'Conducted clinical research on cardiovascular risk factors',
        'Received Chief Resident nomination for excellence in patient care'
      ]
    }
  ],
  education: [
    {
      degree: 'Doctor of Medicine (MD)',
      school: 'Harvard Medical School',
      dates: '2011 - 2015',
      honors: 'Alpha Omega Alpha Medical Honor Society'
    },
    {
      degree: 'B.S. Biology',
      school: 'Stanford University',
      dates: '2007 - 2011',
      gpa: '3.95/4.0'
    }
  ],
  skills: {
    'Clinical': 'Primary Care, Chronic Disease Management, Preventive Medicine',
    'Procedures': 'ECG Interpretation, Spirometry, Joint Injections',
    'EHR': 'Epic, Cerner, Allscripts, eClinicalWorks',
    'Research': 'Clinical Trials, Statistical Analysis, Protocol Development',
    'Leadership': 'Quality Improvement, Medical Education, Team Leadership'
  },
  certifications: ['Board Certified - Internal Medicine (ABIM)', 'ACLS/BLS Certified', 'Certified Medical Educator', 'Quality Improvement Certification'],
  publications: ['Cardiovascular Risk in Type 2 Diabetes - NEJM 2020', 'Telemedicine Efficacy Study - JAMA 2021'],
  achievements: ['Top Doctor - Boston Magazine 2022', 'MGH Excellence in Teaching Award']
};

export const nurseSample: RoleSampleData = {
  roleId: 'nurse',
  name: 'Sarah Mitchell, RN, BSN',
  title: 'Registered Nurse - ICU',
  email: 'sarah.mitchell.rn@email.com',
  phone: '+1 (212) 890-1234',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/sarahmitchell-rn',
  summary: 'Registered Nurse with 7+ years providing critical care in high-volume ICUs. Expert in ventilator management, hemodynamic monitoring, and patient advocacy. Charge nurse experience with strong leadership and mentoring skills. CCRN certified with passion for evidence-based practice.',
  experience: [
    {
      title: 'ICU Charge Nurse',
      company: 'Mount Sinai Hospital',
      location: 'New York, NY',
      dates: '2020 - Present',
      bullets: [
        'Lead team of 12 nurses in 30-bed Medical ICU with 99% patient satisfaction',
        'Coordinate care for critically ill patients including COVID-19, sepsis, and ARDS',
        'Implemented rapid response protocols reducing code blues by 30%',
        'Precept and mentor 20+ new graduate nurses annually'
      ]
    },
    {
      title: 'ICU Staff Nurse',
      company: 'NYU Langone Health',
      location: 'New York, NY',
      dates: '2016 - 2020',
      bullets: [
        'Provided critical care for 4-6 patients daily in 24-bed Surgical ICU',
        'Managed complex cases including post-cardiac surgery and organ transplants',
        'Participated in multidisciplinary rounds improving care coordination',
        'Served on Unit Practice Council driving quality improvement initiatives'
      ]
    }
  ],
  education: [
    {
      degree: 'Master of Science in Nursing (MSN)',
      school: 'Columbia University School of Nursing',
      dates: '2018 - 2020'
    },
    {
      degree: 'Bachelor of Science in Nursing (BSN)',
      school: 'New York University',
      dates: '2012 - 2016',
      honors: 'Magna Cum Laude'
    }
  ],
  skills: {
    'Clinical': 'Critical Care, Ventilator Management, Hemodynamic Monitoring, CRRT',
    'Procedures': 'IV Insertion, Central Line Care, Arterial Lines, NG Tubes',
    'EHR': 'Epic, Cerner, Meditech',
    'Leadership': 'Charge Nurse, Preceptorship, Quality Improvement',
    'Certifications': 'ACLS, PALS, TNCC, NIH Stroke Scale'
  },
  certifications: ['CCRN (Critical Care Registered Nurse)', 'BLS/ACLS/PALS', 'New York RN License', 'Progressive Care Certified Nurse'],
  achievements: ['Daisy Award for Extraordinary Nursing 2022', 'Mount Sinai Nursing Excellence Award']
};

// ============= ENGINEERING ROLES =============

export const mechanicalEngineerSample: RoleSampleData = {
  roleId: 'mechanical-engineer',
  name: 'Daniel Wright',
  title: 'Senior Mechanical Engineer',
  email: 'daniel.wright@email.com',
  phone: '+1 (313) 234-5678',
  location: 'Detroit, MI',
  linkedin: 'linkedin.com/in/danielwright-mech',
  summary: 'Mechanical Engineer with 8+ years designing innovative products from concept to production. Expert in CAD/CAE, product development, and manufacturing optimization. Led projects reducing costs by $5M+ while improving performance. PE licensed with patents in automotive systems.',
  experience: [
    {
      title: 'Senior Mechanical Engineer',
      company: 'Tesla Motors',
      location: 'Fremont, CA',
      dates: '2019 - Present',
      bullets: [
        'Lead design of battery thermal management systems for Model Y and Cybertruck',
        'Reduced component costs by $3M annually through design optimization',
        'Managed team of 5 engineers delivering 10+ product releases on schedule',
        'Filed 3 patents for novel cooling system designs'
      ]
    },
    {
      title: 'Mechanical Engineer',
      company: 'General Motors',
      location: 'Detroit, MI',
      dates: '2015 - 2019',
      bullets: [
        'Designed powertrain components for next-generation electric vehicles',
        'Performed FEA and CFD analysis reducing testing cycles by 40%',
        'Collaborated with suppliers on DFM improving first-pass yield by 25%',
        'Led DFMEA sessions identifying and mitigating 100+ potential failures'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Mechanical Engineering',
      school: 'University of Michigan',
      dates: '2013 - 2015',
      gpa: '3.9/4.0'
    },
    {
      degree: 'B.S. Mechanical Engineering',
      school: 'Purdue University',
      dates: '2009 - 2013',
      honors: 'Summa Cum Laude'
    }
  ],
  skills: {
    'CAD/CAE': 'CATIA, SolidWorks, NX, AutoCAD, Creo',
    'Analysis': 'ANSYS, Abaqus, NASTRAN, CFD, FEA, Thermal Analysis',
    'Manufacturing': 'GD&T, DFM/DFA, Injection Molding, CNC, 3D Printing',
    'Project': 'Product Development, DFMEA/PFMEA, APQP, Six Sigma',
    'Standards': 'ASME, ISO 9001, IATF 16949'
  },
  projects: [
    {
      name: 'EV Battery Cooling System',
      tech: 'CATIA, ANSYS',
      description: 'Novel thermal management design improving range by 8%'
    },
    {
      name: 'Lightweight Chassis Design',
      tech: 'Topology Optimization',
      description: 'Aluminum chassis reducing weight by 15% while maintaining strength'
    }
  ],
  certifications: ['Professional Engineer (PE) - Michigan', 'Six Sigma Black Belt', 'GD&T Certified - ASME', 'CATIA Certified Professional'],
  achievements: ['3 US Patents in Automotive Cooling', 'GM Chairman\'s Excellence Award 2018']
};

export const civilEngineerSample: RoleSampleData = {
  roleId: 'civil-engineer',
  name: 'Maria Gonzalez',
  title: 'Senior Civil Engineer',
  email: 'maria.gonzalez@email.com',
  phone: '+1 (713) 345-6789',
  location: 'Houston, TX',
  linkedin: 'linkedin.com/in/mariagonzalez-civil',
  summary: 'Civil Engineer with 9+ years delivering infrastructure projects valued at $500M+. Expert in structural design, project management, and sustainable engineering. PE licensed in 5 states with LEED AP credentials. Strong track record of on-time, under-budget delivery.',
  experience: [
    {
      title: 'Senior Civil Engineer',
      company: 'AECOM',
      location: 'Houston, TX',
      dates: '2018 - Present',
      bullets: [
        'Lead structural design for $200M highway interchange project',
        'Manage team of 8 engineers across 5 concurrent infrastructure projects',
        'Implemented BIM workflows reducing design conflicts by 35%',
        'Achieved LEED Gold certification for municipal building project'
      ]
    },
    {
      title: 'Civil Engineer',
      company: 'Jacobs Engineering',
      location: 'Dallas, TX',
      dates: '2014 - 2018',
      bullets: [
        'Designed drainage systems for 50+ commercial and residential developments',
        'Performed structural analysis for bridge rehabilitation projects',
        'Coordinated with DOT agencies ensuring regulatory compliance',
        'Mentored 5 junior engineers on design standards and best practices'
      ]
    }
  ],
  education: [
    {
      degree: 'M.S. Civil Engineering (Structural)',
      school: 'Texas A&M University',
      dates: '2012 - 2014',
      gpa: '3.85/4.0'
    },
    {
      degree: 'B.S. Civil Engineering',
      school: 'Rice University',
      dates: '2008 - 2012',
      honors: 'Dean\'s List'
    }
  ],
  skills: {
    'Structural': 'Concrete Design, Steel Design, Foundation Engineering',
    'Software': 'AutoCAD Civil 3D, Revit, SAP2000, STAAD Pro, MicroStation',
    'Analysis': 'Structural Analysis, Geotechnical, Hydrology, Drainage',
    'Management': 'Project Management, Cost Estimation, Scheduling',
    'Sustainability': 'LEED, Sustainable Design, Stormwater Management'
  },
  projects: [
    {
      name: 'I-45 Highway Expansion',
      tech: 'Civil 3D, Revit',
      description: '$200M highway project with 5 new interchanges'
    },
    {
      name: 'Flood Control System',
      tech: 'HEC-RAS, HEC-HMS',
      description: 'Regional drainage protecting 10K+ properties'
    }
  ],
  certifications: ['Professional Engineer (PE) - TX, CA, FL, NY, GA', 'LEED AP BD+C', 'PMP', 'Envision Sustainability Professional'],
  achievements: ['ASCE Texas Young Engineer of the Year 2021', 'Engineering News-Record Top 20 Under 40']
};

// ============= EDUCATION ROLES =============

export const teacherSample: RoleSampleData = {
  roleId: 'teacher',
  name: 'Emily Johnson',
  title: 'High School Mathematics Teacher',
  email: 'emily.johnson@email.com',
  phone: '+1 (312) 456-7890',
  location: 'Chicago, IL',
  linkedin: 'linkedin.com/in/emilyjohnson-educator',
  summary: 'Mathematics Teacher with 8+ years inspiring students to excel in algebra, geometry, and calculus. Expert in differentiated instruction and data-driven teaching. Increased AP Calculus pass rates from 65% to 92%. Passionate about making math accessible and engaging for all learners.',
  experience: [
    {
      title: 'Mathematics Teacher & Department Chair',
      company: 'Lincoln Park High School',
      location: 'Chicago, IL',
      dates: '2018 - Present',
      bullets: [
        'Lead mathematics department of 12 teachers serving 1,500+ students',
        'Increased AP Calculus pass rate from 65% to 92% over 3 years',
        'Developed curriculum aligned with Common Core and ACT preparation',
        'Implemented peer tutoring program improving struggling student performance by 40%'
      ]
    },
    {
      title: 'Mathematics Teacher',
      company: 'Whitney Young Magnet High School',
      location: 'Chicago, IL',
      dates: '2015 - 2018',
      bullets: [
        'Taught Algebra II, Pre-Calculus, and AP Statistics to 120+ students annually',
        'Created interactive lessons using technology increasing engagement by 35%',
        'Sponsored Math Club qualifying for state competition 3 consecutive years',
        'Collaborated with special education team on inclusive teaching strategies'
      ]
    }
  ],
  education: [
    {
      degree: 'M.Ed. Curriculum & Instruction',
      school: 'University of Illinois at Chicago',
      dates: '2017 - 2019'
    },
    {
      degree: 'B.S. Mathematics Education',
      school: 'University of Illinois Urbana-Champaign',
      dates: '2011 - 2015',
      honors: 'Bronze Tablet (Top 3% of Class)'
    }
  ],
  skills: {
    'Instruction': 'Differentiated Instruction, Formative Assessment, Curriculum Design',
    'Technology': 'Google Classroom, Canvas, Desmos, GeoGebra, Khan Academy',
    'Assessment': 'Data Analysis, Standardized Testing, Rubric Development',
    'Classroom': 'Classroom Management, Student Engagement, Parent Communication',
    'Leadership': 'Department Management, Mentoring, Professional Development'
  },
  certifications: ['Illinois Professional Educator License', 'AP Calculus Certified', 'Google Certified Educator Level 2', 'National Board Certified Teacher'],
  achievements: ['CPS Teacher of the Year Finalist 2022', 'Golden Apple Award Nominee']
};

export const fresherSample: RoleSampleData = {
  roleId: 'fresher',
  name: 'Rahul Kumar',
  title: 'Computer Science Graduate',
  email: 'rahul.kumar@email.com',
  phone: '+91 87654 32109',
  location: 'Bangalore, India',
  linkedin: 'linkedin.com/in/rahulkumar-cs',
  github: 'github.com/rahulkumar-dev',
  summary: 'Recent Computer Science graduate with strong foundation in software development, data structures, and algorithms. Completed 3 internships at tech companies. Built 10+ projects including web applications and mobile apps. Eager to contribute and grow in a dynamic tech environment.',
  experience: [
    {
      title: 'Software Engineering Intern',
      company: 'Microsoft India',
      location: 'Hyderabad, India',
      dates: 'May 2023 - Aug 2023',
      bullets: [
        'Developed features for Azure DevOps used by 1M+ developers',
        'Built automated testing framework increasing code coverage by 20%',
        'Collaborated with senior engineers on CI/CD pipeline improvements',
        'Received pre-placement offer based on performance'
      ]
    },
    {
      title: 'Web Development Intern',
      company: 'Flipkart',
      location: 'Bangalore, India',
      dates: 'May 2022 - Jul 2022',
      bullets: [
        'Built React components for seller dashboard serving 100K+ merchants',
        'Optimized page load time by 30% through code splitting',
        'Wrote unit tests achieving 85% code coverage',
        'Participated in agile ceremonies and code reviews'
      ]
    }
  ],
  education: [
    {
      degree: 'B.Tech Computer Science & Engineering',
      school: 'Indian Institute of Technology (IIT) Delhi',
      dates: '2020 - 2024',
      gpa: '8.9/10 CGPA',
      honors: 'Dean\'s List All Semesters, Merit Scholarship'
    }
  ],
  skills: {
    'Languages': 'Python, Java, JavaScript, C++, SQL',
    'Web Development': 'React, Node.js, Express, HTML/CSS, REST APIs',
    'Databases': 'MySQL, MongoDB, PostgreSQL, Redis',
    'Tools': 'Git, Docker, AWS (Basic), Jenkins, JIRA',
    'Core CS': 'Data Structures, Algorithms, OOP, DBMS, OS'
  },
  projects: [
    {
      name: 'E-Commerce Platform',
      tech: 'React, Node.js, MongoDB',
      description: 'Full-stack e-commerce with auth, cart, and payments - 500+ GitHub stars',
      link: 'github.com/rahulkumar/ecommerce'
    },
    {
      name: 'Competitive Programming Solutions',
      tech: 'C++, Python',
      description: '500+ solved problems on LeetCode (Top 5%), CodeForces (Expert Rating)'
    },
    {
      name: 'AI Chatbot',
      tech: 'Python, Flask, OpenAI',
      description: 'Customer support chatbot with 90% query resolution rate'
    }
  ],
  certifications: ['AWS Cloud Practitioner', 'Google Data Analytics', 'HackerRank Problem Solving (Gold)', 'Meta Frontend Developer Certificate'],
  achievements: ['Smart India Hackathon Finalist 2023', 'ACM-ICPC Regionals Qualifier', 'Open Source Contributor - 50+ PRs Merged']
};

// ============= LEGAL ROLES =============

export const lawyerSample: RoleSampleData = {
  roleId: 'lawyer',
  name: 'Katherine Reynolds, Esq.',
  title: 'Corporate Attorney',
  email: 'katherine.reynolds@email.com',
  phone: '+1 (212) 567-8901',
  location: 'New York, NY',
  linkedin: 'linkedin.com/in/katherinereynolds-law',
  summary: 'Corporate Attorney with 9+ years advising Fortune 500 companies on M&A, securities, and corporate governance. Led transactions valued at $10B+. Expert in cross-border deals and regulatory compliance. Former Supreme Court law clerk with strong litigation background.',
  experience: [
    {
      title: 'Partner - Corporate',
      company: 'Davis Polk & Wardwell',
      location: 'New York, NY',
      dates: '2020 - Present',
      bullets: [
        'Lead counsel on $5B+ M&A transactions for tech and healthcare clients',
        'Advise Fortune 500 boards on corporate governance and fiduciary duties',
        'Managed IPO and securities offerings raising $2B+ in capital',
        'Supervise team of 15 associates across multiple practice areas'
      ]
    },
    {
      title: 'Associate - Corporate',
      company: 'Sullivan & Cromwell',
      location: 'New York, NY',
      dates: '2015 - 2020',
      bullets: [
        'Executed cross-border M&A deals across 20+ jurisdictions',
        'Drafted and negotiated complex commercial agreements',
        'Conducted due diligence for private equity transactions',
        'Provided SEC compliance advice for public company clients'
      ]
    }
  ],
  education: [
    {
      degree: 'Juris Doctor (JD)',
      school: 'Yale Law School',
      dates: '2012 - 2015',
      honors: 'Yale Law Journal, Order of the Coif'
    },
    {
      degree: 'B.A. Political Science',
      school: 'Princeton University',
      dates: '2008 - 2012',
      gpa: 'Summa Cum Laude'
    }
  ],
  skills: {
    'Practice Areas': 'M&A, Securities, Corporate Governance, Private Equity',
    'Transactions': 'Due Diligence, Contract Negotiation, Regulatory Filings',
    'Compliance': 'SEC Regulations, Delaware Corporate Law, Antitrust',
    'Legal Tech': 'Westlaw, LexisNexis, Document Review Platforms',
    'Languages': 'English (Native), Spanish (Fluent), French (Conversational)'
  },
  certifications: ['Bar Admission: NY, DC, CA', 'Securities Law Certification', 'Corporate Governance Certificate'],
  publications: ['Cross-Border M&A in the Digital Age - Harvard Law Review 2021'],
  achievements: ['Chambers USA Ranked Attorney', 'American Lawyer Rising Star', 'Supreme Court Law Clerk (2015-2016)']
};

// ============= MASTER ROLE MAPPING =============

export const roleSampleDataMap: Record<string, RoleSampleData> = {
  'data-scientist': dataScienceSample,
  'data-engineer': dataEngineerSample,
  'data-analyst': dataAnalystSample,
  'ai-engineer': aiEngineerSample,
  'ml-engineer': mlEngineerSample,
  'software-engineer': softwareEngineerSample,
  'frontend-developer': frontendDeveloperSample,
  'backend-developer': backendDeveloperSample,
  'fullstack-developer': fullstackDeveloperSample,
  'web-developer': fullstackDeveloperSample,
  'cybersecurity-analyst': cyberSecurityAnalystSample,
  'ui-designer': uiDesignerSample,
  'ux-designer': uiDesignerSample,
  'ux-researcher': uxResearcherSample,
  'graphic-designer': graphicDesignerSample,
  'product-manager': productManagerSample,
  'business-analyst': businessAnalystSample,
  'marketing-executive': marketingManagerSample,
  'digital-marketing-manager': marketingManagerSample,
  'finance-analyst': financeAnalystSample,
  'chartered-accountant': charteredAccountantSample,
  'hr-manager': hrManagerSample,
  'recruiter': hrManagerSample,
  'doctor': doctorSample,
  'nurse': nurseSample,
  'mechanical-engineer': mechanicalEngineerSample,
  'civil-engineer': civilEngineerSample,
  'electrical-engineer': mechanicalEngineerSample,
  'teacher': teacherSample,
  'professor': teacherSample,
  'fresher': fresherSample,
  'student': fresherSample,
  'intern': fresherSample,
  'graduate': fresherSample,
  'lawyer': lawyerSample,
  'attorney': lawyerSample,
};

// Default sample if role not found
export const defaultSample = softwareEngineerSample;

// Get sample data for a role (with fallback)
export const getSampleDataForRole = (roleId: string): RoleSampleData => {
  return roleSampleDataMap[roleId] || defaultSample;
};

// Get sample data with experience level adjustments
export const getSampleDataForRoleLevel = (
  roleId: string, 
  level: 'fresher' | 'intermediate' | 'experienced'
): RoleSampleData => {
  const baseSample = getSampleDataForRole(roleId);
  
  if (level === 'fresher') {
    return {
      ...baseSample,
      title: baseSample.title.replace('Senior ', '').replace('Lead ', ''),
      experience: baseSample.experience.slice(0, 1).map(exp => ({
        ...exp,
        title: exp.title.replace('Senior ', '').replace('Lead ', '')
      })),
      certifications: baseSample.certifications.slice(0, 2)
    };
  }
  
  if (level === 'intermediate') {
    return {
      ...baseSample,
      title: baseSample.title.replace('Senior ', ''),
      experience: baseSample.experience.slice(0, 2)
    };
  }
  
  return baseSample;
};
