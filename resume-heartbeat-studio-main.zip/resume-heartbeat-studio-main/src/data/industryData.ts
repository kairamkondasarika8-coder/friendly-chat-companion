// Comprehensive industry and role data for dynamic resume template generation
// Based on global hiring standards (US, UK, Canada, Europe, India)

export interface RoleData {
  id: string;
  title: string;
  aliases: string[]; // Alternative search terms
  industry: string;
  category: 'technical' | 'creative' | 'business' | 'healthcare' | 'education' | 'legal' | 'engineering' | 'science' | 'hospitality' | 'other';
  experienceLevels: ('fresher' | 'intermediate' | 'experienced')[];
  sections: {
    order: string[];
    required: string[];
    optional: string[];
  };
  skills: {
    technical: string[];
    soft: string[];
    tools: string[];
    certifications: string[];
  };
  keywords: string[]; // ATS keywords
  projectTypes: string[];
  achievementFormats: string[];
}

export interface IndustryInfo {
  id: string;
  name: string;
  icon: string;
  roles: string[];
  primaryColors: string[];
  layoutPreference: 'one-column' | 'two-column' | 'sidebar-left' | 'sidebar-right';
}

// ============= INDUSTRY DEFINITIONS =============

export const industries: IndustryInfo[] = [
  {
    id: 'technology',
    name: 'Technology & IT',
    icon: '💻',
    roles: ['software-engineer', 'data-scientist', 'data-analyst', 'ai-engineer', 'ml-engineer', 'web-developer', 'frontend-developer', 'backend-developer', 'fullstack-developer', 'devops-engineer', 'cloud-architect', 'cybersecurity-analyst', 'mobile-developer', 'qa-engineer', 'database-admin', 'system-admin', 'network-engineer', 'tech-lead', 'cto', 'it-manager'],
    primaryColors: ['#1e3a5f', '#0d9488', '#4338ca', '#2c5282'],
    layoutPreference: 'two-column'
  },
  {
    id: 'design',
    name: 'Design & Creative',
    icon: '🎨',
    roles: ['ui-designer', 'ux-researcher', 'ux-designer', 'graphic-designer', 'product-designer', 'visual-designer', 'motion-designer', 'animator', 'game-designer', 'fashion-designer', 'interior-designer', 'art-director', 'creative-director', 'video-editor', 'photographer', 'illustrator', '3d-artist'],
    primaryColors: ['#7c3aed', '#f97316', '#e11d48', '#0d9488'],
    layoutPreference: 'sidebar-left'
  },
  {
    id: 'business',
    name: 'Business & Management',
    icon: '📊',
    roles: ['product-manager', 'project-manager', 'business-analyst', 'management-consultant', 'operations-manager', 'strategy-consultant', 'mba-graduate', 'entrepreneur', 'startup-founder', 'ceo', 'coo', 'supply-chain-analyst', 'logistics-manager', 'business-development'],
    primaryColors: ['#1e3a5f', '#374151', '#0f2847', '#115e59'],
    layoutPreference: 'two-column'
  },
  {
    id: 'marketing',
    name: 'Marketing & Sales',
    icon: '📈',
    roles: ['marketing-executive', 'digital-marketing-manager', 'content-writer', 'seo-specialist', 'social-media-manager', 'brand-manager', 'sales-executive', 'sales-manager', 'account-executive', 'pr-specialist', 'copywriter', 'marketing-analyst', 'growth-hacker', 'email-marketer'],
    primaryColors: ['#c2410c', '#881337', '#7f1d1d', '#0d9488'],
    layoutPreference: 'sidebar-right'
  },
  {
    id: 'finance',
    name: 'Finance & Accounting',
    icon: '💰',
    roles: ['finance-analyst', 'chartered-accountant', 'financial-advisor', 'investment-banker', 'auditor', 'tax-consultant', 'cfo', 'controller', 'risk-analyst', 'portfolio-manager', 'actuary', 'bookkeeper', 'credit-analyst', 'treasury-analyst'],
    primaryColors: ['#1a365d', '#0f2847', '#1e3a5f', '#166534'],
    layoutPreference: 'one-column'
  },
  {
    id: 'healthcare',
    name: 'Healthcare & Medical',
    icon: '🏥',
    roles: ['doctor', 'nurse', 'pharmacist', 'medical-researcher', 'lab-technician', 'biotech-analyst', 'clinical-researcher', 'radiologist', 'surgeon', 'dentist', 'physical-therapist', 'veterinarian', 'paramedic', 'healthcare-admin', 'medical-coder'],
    primaryColors: ['#0d9488', '#115e59', '#166534', '#1e3a5f'],
    layoutPreference: 'two-column'
  },
  {
    id: 'education',
    name: 'Education & Research',
    icon: '📚',
    roles: ['teacher', 'professor', 'research-scholar', 'scientist', 'academic-researcher', 'librarian', 'education-consultant', 'curriculum-developer', 'training-manager', 'principal', 'dean', 'tutor', 'instructional-designer'],
    primaryColors: ['#1a365d', '#4b5563', '#1a1a1a', '#115e59'],
    layoutPreference: 'one-column'
  },
  {
    id: 'engineering',
    name: 'Engineering',
    icon: '⚙️',
    roles: ['mechanical-engineer', 'civil-engineer', 'electrical-engineer', 'chemical-engineer', 'aerospace-engineer', 'structural-engineer', 'environmental-engineer', 'industrial-engineer', 'manufacturing-engineer', 'quality-engineer', 'robotics-engineer', 'automation-engineer', 'architect'],
    primaryColors: ['#374151', '#1e3a5f', '#4b5563', '#b45309'],
    layoutPreference: 'two-column'
  },
  {
    id: 'legal',
    name: 'Legal & Compliance',
    icon: '⚖️',
    roles: ['lawyer', 'attorney', 'paralegal', 'legal-counsel', 'compliance-officer', 'contract-manager', 'corporate-lawyer', 'litigation-attorney', 'patent-attorney', 'judge', 'legal-analyst'],
    primaryColors: ['#000000', '#1a1a1a', '#374151', '#7f1d1d'],
    layoutPreference: 'one-column'
  },
  {
    id: 'hr',
    name: 'Human Resources',
    icon: '👥',
    roles: ['hr-manager', 'recruiter', 'talent-acquisition', 'hr-generalist', 'hr-business-partner', 'compensation-analyst', 'training-specialist', 'employee-relations', 'chro', 'people-ops'],
    primaryColors: ['#0d9488', '#6d28d9', '#1e3a5f', '#059669'],
    layoutPreference: 'two-column'
  },
  {
    id: 'hospitality',
    name: 'Hospitality & Tourism',
    icon: '🏨',
    roles: ['hotel-manager', 'chef', 'restaurant-manager', 'event-planner', 'travel-agent', 'front-desk-manager', 'housekeeping-manager', 'concierge', 'sommelier', 'barista', 'tourism-officer'],
    primaryColors: ['#b45309', '#881337', '#0d9488', '#1e3a5f'],
    layoutPreference: 'sidebar-left'
  },
  {
    id: 'media',
    name: 'Media & Journalism',
    icon: '📰',
    roles: ['journalist', 'reporter', 'news-anchor', 'editor', 'producer', 'documentary-filmmaker', 'podcast-host', 'media-analyst', 'content-creator', 'blogger', 'vlogger'],
    primaryColors: ['#1a1a1a', '#7f1d1d', '#4338ca', '#374151'],
    layoutPreference: 'two-column'
  },
  {
    id: 'government',
    name: 'Government & Public Sector',
    icon: '🏛️',
    roles: ['government-job-aspirant', 'public-administrator', 'policy-analyst', 'civil-servant', 'diplomat', 'social-worker', 'ngo-manager', 'urban-planner'],
    primaryColors: ['#1e3a5f', '#374151', '#1a1a1a', '#0f2847'],
    layoutPreference: 'one-column'
  },
  {
    id: 'aviation',
    name: 'Aviation & Transportation',
    icon: '✈️',
    roles: ['aviation-crew', 'pilot', 'flight-attendant', 'air-traffic-controller', 'airport-manager', 'airline-operations', 'ground-staff'],
    primaryColors: ['#1e3a5f', '#0f2847', '#374151', '#0d9488'],
    layoutPreference: 'two-column'
  },
  {
    id: 'entry-level',
    name: 'Entry Level & Students',
    icon: '🎓',
    roles: ['fresher', 'student', 'intern', 'graduate', 'apprentice', 'trainee', 'career-changer'],
    primaryColors: ['#4338ca', '#0d9488', '#1e3a5f', '#6d28d9'],
    layoutPreference: 'one-column'
  },
  {
    id: 'freelance',
    name: 'Freelance & Consulting',
    icon: '💼',
    roles: ['freelancer', 'consultant', 'independent-contractor', 'gig-worker', 'self-employed', 'solopreneur'],
    primaryColors: ['#6d28d9', '#0d9488', '#f97316', '#1e3a5f'],
    layoutPreference: 'sidebar-right'
  }
];

// ============= COMPREHENSIVE ROLE DATA =============

export const roleDatabase: RoleData[] = [
  // =========== TECHNOLOGY & IT ===========
  {
    id: 'software-engineer',
    title: 'Software Engineer',
    aliases: ['software developer', 'sde', 'programmer', 'coder', 'application developer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'publications', 'open-source']
    },
    skills: {
      technical: ['Data Structures', 'Algorithms', 'System Design', 'OOP', 'RESTful APIs', 'Microservices', 'Testing', 'CI/CD', 'Version Control'],
      soft: ['Problem Solving', 'Team Collaboration', 'Communication', 'Agile Methodology', 'Code Review'],
      tools: ['Git', 'GitHub', 'Docker', 'Kubernetes', 'Jenkins', 'JIRA', 'VS Code', 'IntelliJ'],
      certifications: ['AWS Certified Developer', 'Google Cloud Professional', 'Azure Developer Associate', 'Kubernetes Certified']
    },
    keywords: ['software development', 'full-stack', 'backend', 'frontend', 'API', 'scalable', 'production', 'deployment', 'agile', 'scrum'],
    projectTypes: ['Web Application', 'API Development', 'Microservices', 'Open Source Contribution', 'Mobile App'],
    achievementFormats: ['Developed X feature that improved Y by Z%', 'Led team of X developers', 'Reduced latency by X%', 'Deployed to X users']
  },
  {
    id: 'data-scientist',
    title: 'Data Scientist',
    aliases: ['data science', 'ml scientist', 'research scientist', 'analytics scientist'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'publications', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'publications', 'certifications', 'kaggle-competitions']
    },
    skills: {
      technical: ['Machine Learning', 'Deep Learning', 'Statistical Analysis', 'Data Mining', 'NLP', 'Computer Vision', 'A/B Testing', 'Feature Engineering'],
      soft: ['Analytical Thinking', 'Business Acumen', 'Storytelling', 'Research', 'Experimentation'],
      tools: ['Python', 'R', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Pandas', 'NumPy', 'Jupyter', 'SQL', 'Spark', 'Tableau'],
      certifications: ['AWS ML Specialty', 'Google ML Engineer', 'IBM Data Science', 'TensorFlow Developer']
    },
    keywords: ['machine learning', 'predictive modeling', 'data analysis', 'statistical modeling', 'deep learning', 'neural networks', 'model deployment'],
    projectTypes: ['Predictive Model', 'NLP Pipeline', 'Recommendation System', 'Computer Vision', 'Time Series Forecasting'],
    achievementFormats: ['Built model achieving X% accuracy', 'Improved prediction by X%', 'Processed X TB of data', 'Reduced churn by X%']
  },
  {
    id: 'data-analyst',
    title: 'Data Analyst',
    aliases: ['business analyst', 'analytics professional', 'bi analyst', 'reporting analyst'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['SQL', 'Data Visualization', 'Statistical Analysis', 'ETL', 'Data Modeling', 'Reporting', 'Dashboard Development'],
      soft: ['Critical Thinking', 'Attention to Detail', 'Communication', 'Business Intelligence', 'Problem Solving'],
      tools: ['Excel', 'Tableau', 'Power BI', 'Looker', 'SQL Server', 'PostgreSQL', 'Python', 'R', 'Google Analytics'],
      certifications: ['Google Data Analytics', 'Tableau Desktop Specialist', 'Microsoft Power BI', 'SQL Certification']
    },
    keywords: ['data analysis', 'business intelligence', 'reporting', 'dashboards', 'KPIs', 'metrics', 'insights', 'visualization'],
    projectTypes: ['Dashboard Development', 'Reporting Automation', 'Data Pipeline', 'KPI Tracking', 'Market Analysis'],
    achievementFormats: ['Created dashboard tracking X metrics', 'Automated reporting saving X hours', 'Identified insights leading to X% improvement']
  },
  {
    id: 'ai-engineer',
    title: 'AI Engineer',
    aliases: ['artificial intelligence engineer', 'ai developer', 'ai specialist', 'ai ml engineer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'publications', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'publications', 'certifications', 'patents']
    },
    skills: {
      technical: ['Deep Learning', 'Neural Networks', 'LLMs', 'Transformers', 'MLOps', 'Model Optimization', 'Reinforcement Learning', 'Prompt Engineering'],
      soft: ['Research', 'Innovation', 'Problem Solving', 'Technical Writing', 'Collaboration'],
      tools: ['PyTorch', 'TensorFlow', 'Hugging Face', 'LangChain', 'OpenAI API', 'AWS SageMaker', 'MLflow', 'Weights & Biases', 'CUDA'],
      certifications: ['AWS ML Specialty', 'Google ML Professional', 'NVIDIA Deep Learning', 'DeepLearning.AI']
    },
    keywords: ['artificial intelligence', 'deep learning', 'LLM', 'generative AI', 'transformer', 'neural network', 'model training', 'inference'],
    projectTypes: ['LLM Application', 'Computer Vision System', 'NLP Model', 'Generative AI', 'AI Chatbot'],
    achievementFormats: ['Deployed AI model with X inference time', 'Built LLM application serving X users', 'Improved model accuracy by X%']
  },
  {
    id: 'ml-engineer',
    title: 'Machine Learning Engineer',
    aliases: ['ml developer', 'machine learning developer', 'applied ml engineer', 'mlops engineer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'publications']
    },
    skills: {
      technical: ['Machine Learning', 'Model Deployment', 'MLOps', 'Feature Engineering', 'Model Monitoring', 'A/B Testing', 'Distributed Computing'],
      soft: ['Problem Solving', 'Collaboration', 'Communication', 'Research', 'Optimization'],
      tools: ['Python', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Kubeflow', 'MLflow', 'Airflow', 'Docker', 'Kubernetes', 'Spark'],
      certifications: ['AWS ML Specialty', 'Google ML Engineer', 'MLOps Certification', 'Kubernetes Certified']
    },
    keywords: ['machine learning', 'model deployment', 'MLOps', 'production ML', 'scalable ML', 'feature store', 'model serving'],
    projectTypes: ['ML Pipeline', 'Model Serving System', 'Feature Store', 'Real-time Inference', 'Batch Processing'],
    achievementFormats: ['Deployed X models to production', 'Reduced inference latency by X%', 'Built pipeline processing X requests/sec']
  },
  {
    id: 'web-developer',
    title: 'Web Developer',
    aliases: ['web dev', 'website developer', 'web programmer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'portfolio']
    },
    skills: {
      technical: ['HTML5', 'CSS3', 'JavaScript', 'Responsive Design', 'Web Accessibility', 'SEO', 'Performance Optimization'],
      soft: ['Creativity', 'Attention to Detail', 'User Focus', 'Problem Solving', 'Communication'],
      tools: ['React', 'Vue.js', 'Angular', 'Node.js', 'WordPress', 'Figma', 'Git', 'Chrome DevTools'],
      certifications: ['AWS Cloud Practitioner', 'Google Web Developer', 'Meta Front-End Developer']
    },
    keywords: ['web development', 'responsive', 'cross-browser', 'SEO', 'accessibility', 'performance', 'UI/UX'],
    projectTypes: ['Corporate Website', 'E-commerce Site', 'Web Application', 'Landing Page', 'Portfolio Site'],
    achievementFormats: ['Built website with X visitors/month', 'Improved page speed by X%', 'Increased conversion by X%']
  },
  {
    id: 'frontend-developer',
    title: 'Frontend Developer',
    aliases: ['front-end developer', 'ui developer', 'client-side developer', 'react developer', 'vue developer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'portfolio']
    },
    skills: {
      technical: ['JavaScript', 'TypeScript', 'React', 'Vue.js', 'Angular', 'State Management', 'Testing', 'Performance Optimization', 'CSS-in-JS'],
      soft: ['UI Sensibility', 'Attention to Detail', 'Collaboration', 'User Empathy', 'Problem Solving'],
      tools: ['React', 'Redux', 'Next.js', 'Vite', 'Webpack', 'Jest', 'Cypress', 'Storybook', 'Tailwind CSS', 'Figma'],
      certifications: ['Meta Front-End Developer', 'React Developer Certification', 'JavaScript Certification']
    },
    keywords: ['frontend', 'React', 'JavaScript', 'TypeScript', 'UI', 'responsive', 'component', 'state management', 'SPA'],
    projectTypes: ['SPA', 'Component Library', 'Dashboard', 'Mobile-first Website', 'PWA'],
    achievementFormats: ['Built X components used across Y projects', 'Reduced bundle size by X%', 'Improved Core Web Vitals by X%']
  },
  {
    id: 'backend-developer',
    title: 'Backend Developer',
    aliases: ['back-end developer', 'server-side developer', 'api developer', 'node developer', 'java developer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['API Design', 'Database Design', 'Microservices', 'Authentication', 'Caching', 'Message Queues', 'Scalability'],
      soft: ['System Thinking', 'Problem Solving', 'Security Mindset', 'Performance Focus', 'Collaboration'],
      tools: ['Node.js', 'Python', 'Java', 'Go', 'PostgreSQL', 'MongoDB', 'Redis', 'RabbitMQ', 'Docker', 'AWS'],
      certifications: ['AWS Developer', 'Node.js Certification', 'MongoDB Certification', 'Kubernetes Certified']
    },
    keywords: ['backend', 'API', 'microservices', 'database', 'scalable', 'REST', 'GraphQL', 'server-side'],
    projectTypes: ['API Development', 'Microservices', 'Database Optimization', 'Authentication System', 'Real-time System'],
    achievementFormats: ['Built API handling X requests/sec', 'Reduced response time by X%', 'Designed system for X concurrent users']
  },
  {
    id: 'fullstack-developer',
    title: 'Full Stack Developer',
    aliases: ['full-stack developer', 'fullstack engineer', 'full stack engineer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['Frontend Development', 'Backend Development', 'Database Management', 'API Design', 'DevOps', 'Testing'],
      soft: ['Versatility', 'Problem Solving', 'Time Management', 'Communication', 'Ownership'],
      tools: ['React', 'Node.js', 'PostgreSQL', 'MongoDB', 'Docker', 'AWS', 'Git', 'TypeScript'],
      certifications: ['AWS Developer', 'Meta Full Stack Developer', 'MongoDB Certification']
    },
    keywords: ['full-stack', 'end-to-end', 'frontend', 'backend', 'database', 'deployment', 'API'],
    projectTypes: ['Full-stack Application', 'End-to-end Feature', 'MVP Development', 'SaaS Product'],
    achievementFormats: ['Built end-to-end feature for X users', 'Owned full product lifecycle', 'Reduced development time by X%']
  },
  {
    id: 'devops-engineer',
    title: 'DevOps Engineer',
    aliases: ['devops', 'site reliability engineer', 'sre', 'platform engineer', 'infrastructure engineer'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['CI/CD', 'Infrastructure as Code', 'Container Orchestration', 'Monitoring', 'Automation', 'Cloud Architecture', 'Security'],
      soft: ['Automation Mindset', 'Problem Solving', 'Collaboration', 'On-call Management', 'Documentation'],
      tools: ['Kubernetes', 'Docker', 'Terraform', 'Ansible', 'Jenkins', 'GitLab CI', 'AWS', 'GCP', 'Prometheus', 'Grafana'],
      certifications: ['AWS DevOps Professional', 'CKA', 'CKAD', 'HashiCorp Terraform', 'Linux Foundation Certified']
    },
    keywords: ['DevOps', 'CI/CD', 'automation', 'infrastructure', 'Kubernetes', 'cloud', 'SRE', 'reliability'],
    projectTypes: ['CI/CD Pipeline', 'Kubernetes Cluster', 'Monitoring Stack', 'Infrastructure Automation', 'Disaster Recovery'],
    achievementFormats: ['Reduced deployment time by X%', 'Achieved X% uptime', 'Automated X% of manual processes']
  },
  {
    id: 'cybersecurity-analyst',
    title: 'Cybersecurity Analyst',
    aliases: ['security analyst', 'information security', 'infosec', 'security engineer', 'soc analyst'],
    industry: 'Technology',
    category: 'technical',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'certifications', 'experience', 'projects', 'education'],
      required: ['summary', 'skills', 'certifications', 'experience', 'education'],
      optional: ['projects', 'publications']
    },
    skills: {
      technical: ['Threat Analysis', 'Incident Response', 'Penetration Testing', 'SIEM', 'Network Security', 'Vulnerability Assessment', 'Forensics'],
      soft: ['Analytical Thinking', 'Attention to Detail', 'Communication', 'Continuous Learning', 'Crisis Management'],
      tools: ['Splunk', 'Wireshark', 'Nessus', 'Metasploit', 'Burp Suite', 'OWASP ZAP', 'AWS Security', 'Crowdstrike'],
      certifications: ['CISSP', 'CEH', 'CompTIA Security+', 'OSCP', 'CISM', 'AWS Security Specialty']
    },
    keywords: ['cybersecurity', 'security', 'threat', 'vulnerability', 'incident response', 'penetration testing', 'compliance'],
    projectTypes: ['Security Audit', 'Penetration Test', 'Incident Response', 'Security Automation', 'Compliance Implementation'],
    achievementFormats: ['Identified X vulnerabilities', 'Reduced incident response time by X%', 'Achieved X compliance certification']
  },

  // =========== DESIGN & CREATIVE ===========
  {
    id: 'ui-designer',
    title: 'UI Designer',
    aliases: ['user interface designer', 'visual designer', 'ui artist'],
    industry: 'Design',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'certifications', 'awards']
    },
    skills: {
      technical: ['Visual Design', 'Typography', 'Color Theory', 'Layout Design', 'Design Systems', 'Responsive Design', 'Prototyping'],
      soft: ['Creativity', 'Attention to Detail', 'Communication', 'Collaboration', 'User Empathy'],
      tools: ['Figma', 'Sketch', 'Adobe XD', 'Illustrator', 'Photoshop', 'InVision', 'Zeplin', 'Principle'],
      certifications: ['Google UX Design', 'Adobe Certified', 'Interaction Design Foundation']
    },
    keywords: ['UI design', 'visual design', 'interface', 'design system', 'prototyping', 'mockups', 'wireframes'],
    projectTypes: ['App Interface', 'Design System', 'Website Design', 'Icon Set', 'Brand Guidelines'],
    achievementFormats: ['Designed interface used by X users', 'Created design system with X components', 'Improved user engagement by X%']
  },
  {
    id: 'ux-researcher',
    title: 'UX Researcher',
    aliases: ['user researcher', 'user experience researcher', 'design researcher'],
    industry: 'Design',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'publications']
    },
    skills: {
      technical: ['User Interviews', 'Usability Testing', 'Survey Design', 'Data Analysis', 'Persona Development', 'Journey Mapping', 'A/B Testing'],
      soft: ['Empathy', 'Active Listening', 'Critical Thinking', 'Storytelling', 'Collaboration'],
      tools: ['UserTesting', 'Hotjar', 'Optimal Workshop', 'Dovetail', 'Miro', 'Google Analytics', 'Figma', 'Maze'],
      certifications: ['UXPA Certification', 'Google UX Design', 'Nielsen Norman Group', 'Interaction Design Foundation']
    },
    keywords: ['user research', 'usability testing', 'user interviews', 'insights', 'data-driven', 'user-centered'],
    projectTypes: ['User Study', 'Usability Test', 'Competitive Analysis', 'Persona Development', 'Journey Mapping'],
    achievementFormats: ['Conducted X user interviews', 'Identified insights that improved X by Y%', 'Reduced user errors by X%']
  },
  {
    id: 'graphic-designer',
    title: 'Graphic Designer',
    aliases: ['visual designer', 'creative designer', 'brand designer'],
    industry: 'Design',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'certifications', 'awards']
    },
    skills: {
      technical: ['Typography', 'Color Theory', 'Layout Design', 'Branding', 'Print Design', 'Digital Design', 'Illustration'],
      soft: ['Creativity', 'Attention to Detail', 'Time Management', 'Client Communication', 'Trend Awareness'],
      tools: ['Adobe Photoshop', 'Illustrator', 'InDesign', 'Figma', 'Canva', 'After Effects', 'Procreate'],
      certifications: ['Adobe Certified Professional', 'Graphic Design Specialization', 'Brand Design Certificate']
    },
    keywords: ['graphic design', 'branding', 'visual identity', 'print', 'digital', 'layout', 'typography'],
    projectTypes: ['Brand Identity', 'Marketing Collateral', 'Social Media Graphics', 'Print Design', 'Packaging'],
    achievementFormats: ['Designed brand identity for X clients', 'Created X marketing assets', 'Won X design awards']
  },
  {
    id: 'video-editor',
    title: 'Video Editor',
    aliases: ['film editor', 'post production editor', 'video producer'],
    industry: 'Media',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'awards', 'certifications']
    },
    skills: {
      technical: ['Video Editing', 'Color Grading', 'Motion Graphics', 'Sound Design', 'Storytelling', 'Compositing'],
      soft: ['Creativity', 'Attention to Detail', 'Time Management', 'Collaboration', 'Deadline Management'],
      tools: ['Adobe Premiere Pro', 'Final Cut Pro', 'DaVinci Resolve', 'After Effects', 'Audition', 'Cinema 4D'],
      certifications: ['Adobe Certified', 'Avid Certified', 'DaVinci Resolve Certified']
    },
    keywords: ['video editing', 'post-production', 'color grading', 'motion graphics', 'storytelling'],
    projectTypes: ['Commercial', 'Documentary', 'Music Video', 'Social Content', 'Corporate Video'],
    achievementFormats: ['Edited X videos with Y total views', 'Delivered X projects on deadline', 'Won X video awards']
  },

  // =========== BUSINESS & MANAGEMENT ===========
  {
    id: 'product-manager',
    title: 'Product Manager',
    aliases: ['pm', 'product owner', 'product lead', 'apm', 'associate product manager'],
    industry: 'Business',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['Product Strategy', 'Roadmapping', 'User Research', 'Data Analysis', 'A/B Testing', 'Agile/Scrum', 'PRD Writing'],
      soft: ['Leadership', 'Communication', 'Stakeholder Management', 'Prioritization', 'Decision Making'],
      tools: ['Jira', 'Confluence', 'Figma', 'Amplitude', 'Mixpanel', 'SQL', 'Notion', 'Miro'],
      certifications: ['Certified Scrum Product Owner', 'Product Management Certificate', 'Google PM Certificate']
    },
    keywords: ['product management', 'roadmap', 'user-centric', 'data-driven', 'stakeholder', 'MVP', 'product-market fit'],
    projectTypes: ['Product Launch', 'Feature Development', 'User Research', 'Growth Experiment', 'Platform Strategy'],
    achievementFormats: ['Launched product with X users', 'Increased metric by X%', 'Led cross-functional team of X people']
  },
  {
    id: 'project-manager',
    title: 'Project Manager',
    aliases: ['program manager', 'pmp', 'scrum master', 'delivery manager'],
    industry: 'Business',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'projects', 'education'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['certifications', 'projects']
    },
    skills: {
      technical: ['Project Planning', 'Risk Management', 'Budget Management', 'Agile/Scrum', 'Waterfall', 'Resource Allocation', 'Reporting'],
      soft: ['Leadership', 'Communication', 'Problem Solving', 'Negotiation', 'Conflict Resolution'],
      tools: ['Jira', 'Asana', 'MS Project', 'Monday.com', 'Smartsheet', 'Confluence', 'Slack', 'Trello'],
      certifications: ['PMP', 'CSM', 'PRINCE2', 'Agile Certified Practitioner', 'Six Sigma']
    },
    keywords: ['project management', 'delivery', 'on-time', 'on-budget', 'stakeholder', 'agile', 'waterfall', 'risk management'],
    projectTypes: ['Software Delivery', 'Process Improvement', 'System Implementation', 'Team Management', 'Budget Management'],
    achievementFormats: ['Delivered X projects on time and budget', 'Managed budget of $X', 'Led team of X members']
  },
  {
    id: 'business-analyst',
    title: 'Business Analyst',
    aliases: ['ba', 'requirements analyst', 'systems analyst', 'functional analyst'],
    industry: 'Business',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['Requirements Gathering', 'Process Mapping', 'Data Analysis', 'SQL', 'Documentation', 'UAT', 'Gap Analysis'],
      soft: ['Communication', 'Stakeholder Management', 'Problem Solving', 'Critical Thinking', 'Facilitation'],
      tools: ['Excel', 'Visio', 'JIRA', 'Confluence', 'SQL', 'Tableau', 'Power BI', 'Lucidchart'],
      certifications: ['CBAP', 'PMI-PBA', 'CCBA', 'Agile BA Certification']
    },
    keywords: ['business analysis', 'requirements', 'process improvement', 'stakeholder', 'documentation', 'UAT'],
    projectTypes: ['Requirements Documentation', 'Process Improvement', 'System Implementation', 'Gap Analysis', 'User Stories'],
    achievementFormats: ['Gathered requirements for X projects', 'Improved process efficiency by X%', 'Facilitated X stakeholder workshops']
  },
  {
    id: 'mba-graduate',
    title: 'MBA Graduate',
    aliases: ['mba', 'business graduate', 'management graduate'],
    industry: 'Business',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate'],
    sections: {
      order: ['summary', 'education', 'experience', 'skills', 'projects', 'extracurriculars', 'certifications'],
      required: ['summary', 'education', 'experience', 'skills'],
      optional: ['projects', 'extracurriculars', 'certifications']
    },
    skills: {
      technical: ['Financial Analysis', 'Strategic Planning', 'Market Research', 'Business Strategy', 'Operations', 'Data Analysis'],
      soft: ['Leadership', 'Communication', 'Teamwork', 'Problem Solving', 'Presentation'],
      tools: ['Excel', 'PowerPoint', 'Tableau', 'SQL', 'SAP', 'Salesforce'],
      certifications: ['CFA', 'Six Sigma', 'Google Analytics', 'PMP']
    },
    keywords: ['MBA', 'business strategy', 'leadership', 'management', 'finance', 'operations', 'consulting'],
    projectTypes: ['Case Competition', 'Consulting Project', 'Business Plan', 'Market Analysis', 'Strategy Presentation'],
    achievementFormats: ['Consulted for X company', 'Won X case competition', 'Led team of X in project']
  },
  {
    id: 'entrepreneur',
    title: 'Entrepreneur',
    aliases: ['founder', 'startup founder', 'co-founder', 'business owner'],
    industry: 'Business',
    category: 'business',
    experienceLevels: ['intermediate', 'experienced'],
    sections: {
      order: ['summary', 'experience', 'skills', 'achievements', 'education', 'projects'],
      required: ['summary', 'experience', 'skills', 'education'],
      optional: ['achievements', 'projects', 'press', 'awards']
    },
    skills: {
      technical: ['Business Development', 'Fundraising', 'Product Development', 'Financial Management', 'Marketing', 'Sales'],
      soft: ['Leadership', 'Vision', 'Resilience', 'Networking', 'Decision Making', 'Risk Management'],
      tools: ['CRM', 'Analytics', 'Financial Modeling', 'Pitch Decks', 'Legal Docs'],
      certifications: ['Y Combinator', 'Startup School', 'Founder Institute']
    },
    keywords: ['entrepreneur', 'founder', 'startup', 'scaling', 'fundraising', 'product-market fit', 'growth'],
    projectTypes: ['Company Building', 'Fundraising', 'Product Launch', 'Team Building', 'Market Expansion'],
    achievementFormats: ['Founded company with X revenue', 'Raised $X in funding', 'Grew team to X employees']
  },

  // =========== MARKETING & SALES ===========
  {
    id: 'marketing-executive',
    title: 'Marketing Executive',
    aliases: ['marketing manager', 'marketing specialist', 'brand manager', 'marketing coordinator'],
    industry: 'Marketing',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['Digital Marketing', 'Content Strategy', 'SEO/SEM', 'Social Media', 'Email Marketing', 'Analytics', 'Campaign Management'],
      soft: ['Creativity', 'Communication', 'Data Analysis', 'Project Management', 'Collaboration'],
      tools: ['Google Analytics', 'HubSpot', 'Mailchimp', 'Hootsuite', 'SEMrush', 'Canva', 'Meta Ads', 'Google Ads'],
      certifications: ['Google Ads', 'HubSpot Inbound', 'Meta Blueprint', 'Google Analytics', 'SEMrush']
    },
    keywords: ['marketing', 'digital marketing', 'brand', 'campaigns', 'ROI', 'lead generation', 'content'],
    projectTypes: ['Marketing Campaign', 'Brand Launch', 'Content Strategy', 'Lead Generation', 'Social Media Strategy'],
    achievementFormats: ['Increased leads by X%', 'Managed budget of $X', 'Grew social following by X%']
  },
  {
    id: 'content-writer',
    title: 'Content Writer',
    aliases: ['copywriter', 'content creator', 'content strategist', 'blogger', 'technical writer'],
    industry: 'Marketing',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'certifications', 'publications']
    },
    skills: {
      technical: ['Content Writing', 'SEO Writing', 'Copywriting', 'Editing', 'Research', 'CMS Management', 'Social Media'],
      soft: ['Creativity', 'Attention to Detail', 'Time Management', 'Adaptability', 'Communication'],
      tools: ['WordPress', 'Google Docs', 'Grammarly', 'SEMrush', 'Ahrefs', 'Canva', 'Notion'],
      certifications: ['Google Analytics', 'HubSpot Content Marketing', 'SEO Certification']
    },
    keywords: ['content', 'writing', 'copywriting', 'SEO', 'blog', 'editorial', 'storytelling'],
    projectTypes: ['Blog Posts', 'Website Copy', 'White Papers', 'Case Studies', 'Social Content'],
    achievementFormats: ['Wrote X articles with Y total views', 'Increased organic traffic by X%', 'Published in X publications']
  },
  {
    id: 'sales-executive',
    title: 'Sales Executive',
    aliases: ['sales manager', 'account executive', 'business development', 'sales representative'],
    industry: 'Marketing',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'achievements', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['achievements', 'certifications']
    },
    skills: {
      technical: ['Sales Strategy', 'Lead Generation', 'CRM Management', 'Pipeline Management', 'Negotiation', 'Closing', 'Cold Calling'],
      soft: ['Communication', 'Persuasion', 'Relationship Building', 'Resilience', 'Goal Orientation'],
      tools: ['Salesforce', 'HubSpot', 'LinkedIn Sales Navigator', 'ZoomInfo', 'Outreach', 'Gong'],
      certifications: ['Salesforce Certification', 'HubSpot Sales', 'SPIN Selling', 'Challenger Sales']
    },
    keywords: ['sales', 'revenue', 'quota', 'pipeline', 'closing', 'B2B', 'B2C', 'account management'],
    projectTypes: ['Territory Management', 'Account Growth', 'New Business', 'Enterprise Sales', 'Channel Sales'],
    achievementFormats: ['Exceeded quota by X%', 'Generated $X in revenue', 'Closed X deals worth $Y']
  },

  // =========== FINANCE & ACCOUNTING ===========
  {
    id: 'finance-analyst',
    title: 'Finance Analyst',
    aliases: ['financial analyst', 'fp&a analyst', 'investment analyst', 'equity analyst'],
    industry: 'Finance',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'education', 'certifications', 'projects'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['certifications', 'projects']
    },
    skills: {
      technical: ['Financial Modeling', 'Valuation', 'Budgeting', 'Forecasting', 'Financial Reporting', 'Variance Analysis', 'Excel'],
      soft: ['Analytical Thinking', 'Attention to Detail', 'Communication', 'Problem Solving', 'Presentation'],
      tools: ['Excel', 'Bloomberg', 'FactSet', 'SAP', 'Oracle', 'Tableau', 'Python', 'SQL'],
      certifications: ['CFA', 'CPA', 'FRM', 'Financial Modeling Certification']
    },
    keywords: ['financial analysis', 'valuation', 'modeling', 'forecasting', 'budgeting', 'P&L', 'ROI'],
    projectTypes: ['Financial Model', 'Valuation', 'Budget Planning', 'Investment Analysis', 'Due Diligence'],
    achievementFormats: ['Built model saving $X', 'Managed budget of $X', 'Improved forecast accuracy by X%']
  },
  {
    id: 'chartered-accountant',
    title: 'Chartered Accountant',
    aliases: ['ca', 'cpa', 'accountant', 'auditor', 'tax accountant'],
    industry: 'Finance',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'education', 'projects'],
      required: ['summary', 'certifications', 'skills', 'experience', 'education'],
      optional: ['projects']
    },
    skills: {
      technical: ['Accounting', 'Auditing', 'Taxation', 'Financial Reporting', 'Compliance', 'GAAP/IFRS', 'Internal Controls'],
      soft: ['Integrity', 'Attention to Detail', 'Analytical Thinking', 'Communication', 'Ethics'],
      tools: ['Tally', 'QuickBooks', 'SAP', 'Excel', 'Oracle', 'AuditBoard'],
      certifications: ['CA', 'CPA', 'ACCA', 'CMA', 'CIA']
    },
    keywords: ['accounting', 'audit', 'tax', 'compliance', 'financial statements', 'GAAP', 'IFRS'],
    projectTypes: ['Audit Engagement', 'Tax Filing', 'Financial Reporting', 'Compliance Review', 'Internal Audit'],
    achievementFormats: ['Managed X audits', 'Saved $X in taxes', 'Ensured X compliance']
  },

  // =========== HEALTHCARE & MEDICAL ===========
  {
    id: 'doctor',
    title: 'Doctor',
    aliases: ['physician', 'md', 'medical doctor', 'surgeon', 'specialist'],
    industry: 'Healthcare',
    category: 'healthcare',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'education', 'certifications', 'experience', 'skills', 'research', 'publications'],
      required: ['summary', 'education', 'certifications', 'experience', 'skills'],
      optional: ['research', 'publications', 'awards']
    },
    skills: {
      technical: ['Patient Care', 'Diagnosis', 'Treatment Planning', 'Medical Procedures', 'Electronic Health Records', 'Clinical Research'],
      soft: ['Empathy', 'Communication', 'Decision Making', 'Leadership', 'Stress Management'],
      tools: ['EHR Systems', 'EPIC', 'Medical Imaging', 'Diagnostic Equipment'],
      certifications: ['MD', 'Board Certification', 'USMLE', 'Medical License']
    },
    keywords: ['medicine', 'patient care', 'diagnosis', 'treatment', 'clinical', 'healthcare'],
    projectTypes: ['Clinical Research', 'Patient Care', 'Medical Procedures', 'Health Programs'],
    achievementFormats: ['Treated X patients', 'Published X research papers', 'Led X medical team']
  },
  {
    id: 'nurse',
    title: 'Nurse',
    aliases: ['registered nurse', 'rn', 'nursing', 'clinical nurse', 'nurse practitioner'],
    industry: 'Healthcare',
    category: 'healthcare',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'education', 'awards'],
      required: ['summary', 'certifications', 'skills', 'experience', 'education'],
      optional: ['awards', 'volunteer']
    },
    skills: {
      technical: ['Patient Care', 'Medication Administration', 'Vital Signs', 'IV Therapy', 'Wound Care', 'Emergency Response'],
      soft: ['Compassion', 'Communication', 'Critical Thinking', 'Stress Management', 'Teamwork'],
      tools: ['EHR', 'Medical Equipment', 'Patient Monitoring Systems'],
      certifications: ['RN', 'BSN', 'BLS', 'ACLS', 'PALS', 'Specialty Certification']
    },
    keywords: ['nursing', 'patient care', 'clinical', 'healthcare', 'medical', 'bedside'],
    projectTypes: ['Patient Care', 'Quality Improvement', 'Training', 'Emergency Response'],
    achievementFormats: ['Cared for X patients daily', 'Improved patient satisfaction by X%', 'Trained X nurses']
  },
  {
    id: 'pharmacist',
    title: 'Pharmacist',
    aliases: ['clinical pharmacist', 'pharmacy manager', 'pharm d'],
    industry: 'Healthcare',
    category: 'healthcare',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'education'],
      required: ['summary', 'certifications', 'skills', 'experience', 'education'],
      optional: ['research', 'publications']
    },
    skills: {
      technical: ['Medication Dispensing', 'Drug Interactions', 'Patient Counseling', 'Inventory Management', 'Compounding', 'Clinical Pharmacy'],
      soft: ['Attention to Detail', 'Communication', 'Customer Service', 'Problem Solving', 'Ethics'],
      tools: ['Pharmacy Management Systems', 'EHR', 'Drug Databases'],
      certifications: ['PharmD', 'State License', 'Board Certification', 'Immunization Certified']
    },
    keywords: ['pharmacy', 'medication', 'dispensing', 'clinical', 'patient counseling'],
    projectTypes: ['Medication Management', 'Patient Education', 'Inventory Optimization', 'Clinical Programs'],
    achievementFormats: ['Managed X prescriptions daily', 'Reduced medication errors by X%', 'Counseled X patients']
  },

  // =========== EDUCATION & RESEARCH ===========
  {
    id: 'teacher',
    title: 'Teacher',
    aliases: ['educator', 'instructor', 'school teacher', 'high school teacher', 'elementary teacher'],
    industry: 'Education',
    category: 'education',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'education', 'achievements'],
      required: ['summary', 'certifications', 'skills', 'experience', 'education'],
      optional: ['achievements', 'extracurriculars']
    },
    skills: {
      technical: ['Curriculum Development', 'Lesson Planning', 'Classroom Management', 'Assessment', 'Educational Technology', 'Differentiated Instruction'],
      soft: ['Communication', 'Patience', 'Creativity', 'Adaptability', 'Leadership'],
      tools: ['Google Classroom', 'Zoom', 'Canvas', 'PowerPoint', 'Educational Apps'],
      certifications: ['Teaching License', 'State Certification', 'Subject Certification']
    },
    keywords: ['teaching', 'education', 'curriculum', 'classroom', 'student', 'learning'],
    projectTypes: ['Curriculum Development', 'Student Programs', 'Extracurricular Activities', 'Parent Engagement'],
    achievementFormats: ['Improved student scores by X%', 'Taught X students', 'Developed X new curriculum']
  },
  {
    id: 'professor',
    title: 'Professor',
    aliases: ['academic', 'faculty', 'lecturer', 'assistant professor', 'associate professor'],
    industry: 'Education',
    category: 'education',
    experienceLevels: ['intermediate', 'experienced'],
    sections: {
      order: ['summary', 'education', 'experience', 'publications', 'research', 'skills', 'awards'],
      required: ['summary', 'education', 'experience', 'publications', 'skills'],
      optional: ['research', 'awards', 'grants', 'conferences']
    },
    skills: {
      technical: ['Research Methodology', 'Academic Writing', 'Grant Writing', 'Curriculum Design', 'Student Mentoring', 'Peer Review'],
      soft: ['Critical Thinking', 'Communication', 'Leadership', 'Mentorship', 'Collaboration'],
      tools: ['SPSS', 'R', 'LaTeX', 'Research Databases', 'LMS'],
      certifications: ['PhD', 'Postdoctoral', 'Tenure']
    },
    keywords: ['academic', 'research', 'publications', 'teaching', 'grants', 'peer-reviewed'],
    projectTypes: ['Research Project', 'Grant Proposal', 'Publication', 'Curriculum Development', 'Student Supervision'],
    achievementFormats: ['Published X papers', 'Secured $X in grants', 'Supervised X PhD students']
  },
  {
    id: 'research-scholar',
    title: 'Research Scholar',
    aliases: ['researcher', 'phd student', 'doctoral candidate', 'research assistant'],
    industry: 'Education',
    category: 'education',
    experienceLevels: ['fresher', 'intermediate'],
    sections: {
      order: ['summary', 'education', 'research', 'publications', 'skills', 'experience', 'awards'],
      required: ['summary', 'education', 'research', 'skills'],
      optional: ['publications', 'experience', 'awards', 'conferences']
    },
    skills: {
      technical: ['Research Methods', 'Data Analysis', 'Academic Writing', 'Literature Review', 'Statistical Analysis', 'Lab Techniques'],
      soft: ['Critical Thinking', 'Persistence', 'Time Management', 'Collaboration', 'Presentation'],
      tools: ['SPSS', 'R', 'Python', 'MATLAB', 'LaTeX', 'Reference Managers'],
      certifications: ['Research Ethics', 'Statistical Methods', 'Lab Safety']
    },
    keywords: ['research', 'academic', 'thesis', 'dissertation', 'publications', 'methodology'],
    projectTypes: ['Thesis Research', 'Lab Experiments', 'Data Collection', 'Literature Review', 'Conference Presentation'],
    achievementFormats: ['Published X papers', 'Presented at X conferences', 'Completed X research projects']
  },

  // =========== ENGINEERING ===========
  {
    id: 'mechanical-engineer',
    title: 'Mechanical Engineer',
    aliases: ['mech engineer', 'design engineer', 'manufacturing engineer', 'automotive engineer'],
    industry: 'Engineering',
    category: 'engineering',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'patents']
    },
    skills: {
      technical: ['CAD Design', 'FEA', 'Thermodynamics', 'Manufacturing Processes', 'Material Science', 'Quality Control', 'GD&T'],
      soft: ['Problem Solving', 'Analytical Thinking', 'Teamwork', 'Project Management', 'Communication'],
      tools: ['AutoCAD', 'SolidWorks', 'CATIA', 'ANSYS', 'MATLAB', 'Creo', 'NX'],
      certifications: ['PE License', 'Six Sigma', 'PMP', 'GD&T Certification']
    },
    keywords: ['mechanical engineering', 'design', 'manufacturing', 'CAD', 'prototyping', 'testing'],
    projectTypes: ['Product Design', 'Manufacturing Process', 'Testing Protocol', 'Prototype Development', 'Cost Reduction'],
    achievementFormats: ['Designed X products', 'Reduced manufacturing cost by X%', 'Led team of X engineers']
  },
  {
    id: 'civil-engineer',
    title: 'Civil Engineer',
    aliases: ['structural engineer', 'construction engineer', 'site engineer', 'infrastructure engineer'],
    industry: 'Engineering',
    category: 'engineering',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications']
    },
    skills: {
      technical: ['Structural Analysis', 'Construction Management', 'Site Supervision', 'Quantity Surveying', 'Geotechnical', 'Environmental'],
      soft: ['Project Management', 'Problem Solving', 'Communication', 'Leadership', 'Safety Awareness'],
      tools: ['AutoCAD', 'STAAD Pro', 'Revit', 'Primavera', 'ETABS', 'Civil 3D'],
      certifications: ['PE License', 'PMP', 'LEED', 'Safety Certification']
    },
    keywords: ['civil engineering', 'construction', 'structural', 'infrastructure', 'project management'],
    projectTypes: ['Building Construction', 'Infrastructure Project', 'Structural Design', 'Site Supervision', 'Quantity Estimation'],
    achievementFormats: ['Managed projects worth $X', 'Supervised X construction sites', 'Completed X projects on time']
  },
  {
    id: 'electrical-engineer',
    title: 'Electrical Engineer',
    aliases: ['electronics engineer', 'power engineer', 'control engineer', 'ee'],
    industry: 'Engineering',
    category: 'engineering',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'projects', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['projects', 'certifications', 'patents']
    },
    skills: {
      technical: ['Circuit Design', 'Power Systems', 'PLC Programming', 'Control Systems', 'Electronics', 'Signal Processing', 'Embedded Systems'],
      soft: ['Analytical Thinking', 'Problem Solving', 'Attention to Detail', 'Teamwork', 'Documentation'],
      tools: ['MATLAB', 'Simulink', 'PSpice', 'LabVIEW', 'AutoCAD Electrical', 'ETAP', 'PLC Software'],
      certifications: ['PE License', 'PLC Certification', 'Control Systems Certification']
    },
    keywords: ['electrical engineering', 'power', 'electronics', 'control systems', 'circuits', 'automation'],
    projectTypes: ['Power System Design', 'Control System', 'Circuit Design', 'Automation Project', 'Testing'],
    achievementFormats: ['Designed systems for X MW', 'Reduced energy consumption by X%', 'Automated X processes']
  },
  {
    id: 'architect',
    title: 'Architect',
    aliases: ['architectural designer', 'building architect', 'design architect', 'project architect'],
    industry: 'Engineering',
    category: 'engineering',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'certifications'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'certifications', 'awards']
    },
    skills: {
      technical: ['Architectural Design', 'Building Codes', '3D Modeling', 'Construction Documents', 'Sustainable Design', 'Space Planning'],
      soft: ['Creativity', 'Communication', 'Project Management', 'Client Relations', 'Visualization'],
      tools: ['AutoCAD', 'Revit', 'SketchUp', 'Rhino', '3ds Max', 'V-Ray', 'Lumion', 'Photoshop'],
      certifications: ['Architecture License', 'LEED AP', 'AIA Membership']
    },
    keywords: ['architecture', 'design', 'building', 'sustainable', 'construction', 'visualization'],
    projectTypes: ['Building Design', 'Renovation', 'Interior Design', 'Master Planning', 'Sustainable Building'],
    achievementFormats: ['Designed X sq ft building', 'Won X design competitions', 'Led X projects']
  },

  // =========== LEGAL ===========
  {
    id: 'lawyer',
    title: 'Lawyer',
    aliases: ['attorney', 'advocate', 'legal counsel', 'solicitor', 'barrister'],
    industry: 'Legal',
    category: 'legal',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'education', 'certifications', 'experience', 'skills', 'publications'],
      required: ['summary', 'education', 'certifications', 'experience', 'skills'],
      optional: ['publications', 'cases', 'awards']
    },
    skills: {
      technical: ['Legal Research', 'Contract Drafting', 'Litigation', 'Negotiation', 'Legal Writing', 'Case Analysis', 'Compliance'],
      soft: ['Analytical Thinking', 'Communication', 'Advocacy', 'Ethics', 'Attention to Detail'],
      tools: ['Westlaw', 'LexisNexis', 'Legal Document Management', 'E-Discovery Tools'],
      certifications: ['Bar Admission', 'LLB', 'JD', 'Specialization Certifications']
    },
    keywords: ['legal', 'law', 'litigation', 'contracts', 'compliance', 'advocacy', 'counsel'],
    projectTypes: ['Litigation', 'Contract Review', 'Legal Opinion', 'Compliance Audit', 'Due Diligence'],
    achievementFormats: ['Won X cases', 'Drafted X contracts', 'Advised X clients']
  },

  // =========== HR ===========
  {
    id: 'hr-manager',
    title: 'HR Manager',
    aliases: ['human resources manager', 'hr director', 'people manager', 'hr head'],
    industry: 'Human Resources',
    category: 'business',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'certifications', 'education', 'achievements'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['certifications', 'achievements']
    },
    skills: {
      technical: ['Recruitment', 'Employee Relations', 'Performance Management', 'Compensation & Benefits', 'HRIS', 'Labor Law', 'Training'],
      soft: ['Communication', 'Conflict Resolution', 'Leadership', 'Empathy', 'Negotiation'],
      tools: ['Workday', 'SAP SuccessFactors', 'BambooHR', 'LinkedIn Recruiter', 'ATS Systems'],
      certifications: ['SHRM-CP', 'SHRM-SCP', 'PHR', 'SPHR']
    },
    keywords: ['human resources', 'recruitment', 'employee relations', 'talent management', 'HR strategy'],
    projectTypes: ['Recruitment Drive', 'Training Program', 'Performance Review', 'Policy Development', 'Employee Engagement'],
    achievementFormats: ['Hired X employees', 'Reduced turnover by X%', 'Implemented X HR programs']
  },

  // =========== HOSPITALITY ===========
  {
    id: 'hotel-manager',
    title: 'Hotel Manager',
    aliases: ['hospitality manager', 'front office manager', 'general manager hotel'],
    industry: 'Hospitality',
    category: 'hospitality',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'education', 'certifications', 'achievements'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['certifications', 'achievements']
    },
    skills: {
      technical: ['Operations Management', 'Revenue Management', 'Guest Relations', 'Staff Management', 'Budget Management', 'Quality Control'],
      soft: ['Leadership', 'Customer Service', 'Problem Solving', 'Communication', 'Multitasking'],
      tools: ['Opera PMS', 'Micros', 'Revenue Management Systems', 'Booking Platforms'],
      certifications: ['Hospitality Management Degree', 'AHLEI Certifications', 'Food Safety']
    },
    keywords: ['hospitality', 'hotel management', 'guest experience', 'operations', 'revenue'],
    projectTypes: ['Operations Improvement', 'Guest Satisfaction', 'Revenue Optimization', 'Staff Training', 'Quality Improvement'],
    achievementFormats: ['Managed X room hotel', 'Improved guest satisfaction by X%', 'Increased revenue by X%']
  },
  {
    id: 'chef',
    title: 'Chef',
    aliases: ['executive chef', 'head chef', 'culinary artist', 'cook', 'sous chef'],
    industry: 'Hospitality',
    category: 'hospitality',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'certifications', 'education', 'achievements'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['certifications', 'achievements', 'awards']
    },
    skills: {
      technical: ['Culinary Arts', 'Menu Development', 'Food Safety', 'Kitchen Management', 'Cost Control', 'Food Presentation'],
      soft: ['Creativity', 'Leadership', 'Time Management', 'Attention to Detail', 'Stress Management'],
      tools: ['Kitchen Equipment', 'Inventory Systems', 'Recipe Management'],
      certifications: ['Culinary Degree', 'ServSafe', 'Food Handler', 'Sommelier']
    },
    keywords: ['culinary', 'chef', 'cuisine', 'menu', 'kitchen', 'food service'],
    projectTypes: ['Menu Development', 'Kitchen Setup', 'Staff Training', 'Cost Optimization', 'Special Events'],
    achievementFormats: ['Managed X covers daily', 'Reduced food cost by X%', 'Created X signature dishes']
  },

  // =========== ENTRY LEVEL ===========
  {
    id: 'fresher',
    title: 'Fresher',
    aliases: ['fresh graduate', 'entry level', 'new graduate', 'graduate fresher', 'campus hire'],
    industry: 'Entry Level',
    category: 'other',
    experienceLevels: ['fresher'],
    sections: {
      order: ['summary', 'education', 'skills', 'projects', 'extracurriculars', 'certifications'],
      required: ['summary', 'education', 'skills'],
      optional: ['projects', 'extracurriculars', 'certifications', 'internships']
    },
    skills: {
      technical: ['Academic Knowledge', 'Technical Skills', 'Research', 'Computer Skills', 'Laboratory Skills'],
      soft: ['Eager to Learn', 'Adaptability', 'Teamwork', 'Communication', 'Time Management'],
      tools: ['MS Office', 'Google Suite', 'Programming Languages', 'Design Tools'],
      certifications: ['Academic Certificates', 'Online Courses', 'Workshops']
    },
    keywords: ['fresher', 'graduate', 'entry-level', 'eager to learn', 'quick learner', 'trainable'],
    projectTypes: ['Academic Project', 'Internship', 'Personal Project', 'Research Project', 'Hackathon'],
    achievementFormats: ['Achieved X GPA', 'Completed X projects', 'Won X competitions']
  },
  {
    id: 'student',
    title: 'Student',
    aliases: ['college student', 'university student', 'undergraduate', 'postgraduate'],
    industry: 'Entry Level',
    category: 'other',
    experienceLevels: ['fresher'],
    sections: {
      order: ['summary', 'education', 'skills', 'projects', 'extracurriculars', 'internships'],
      required: ['summary', 'education', 'skills'],
      optional: ['projects', 'extracurriculars', 'internships', 'volunteer']
    },
    skills: {
      technical: ['Academic Skills', 'Research', 'Computer Literacy', 'Subject Knowledge'],
      soft: ['Learning Ability', 'Time Management', 'Teamwork', 'Communication', 'Leadership'],
      tools: ['MS Office', 'Google Suite', 'Study Tools', 'Presentation Software'],
      certifications: ['Academic Certificates', 'Online Courses', 'Skill Certificates']
    },
    keywords: ['student', 'academic', 'learning', 'coursework', 'extracurricular'],
    projectTypes: ['Class Project', 'Research Paper', 'Group Project', 'Lab Work', 'Competition'],
    achievementFormats: ['Maintained X GPA', 'Led X student organization', 'Won X academic award']
  },
  {
    id: 'freelancer',
    title: 'Freelancer',
    aliases: ['independent contractor', 'consultant', 'self-employed', 'gig worker'],
    industry: 'Freelance',
    category: 'other',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'testimonials'],
      required: ['summary', 'skills', 'experience'],
      optional: ['portfolio', 'education', 'testimonials', 'certifications']
    },
    skills: {
      technical: ['Domain Expertise', 'Project Management', 'Client Communication', 'Time Tracking', 'Invoicing'],
      soft: ['Self-Discipline', 'Time Management', 'Communication', 'Negotiation', 'Adaptability'],
      tools: ['Project Management Tools', 'Communication Tools', 'Time Tracking', 'Invoicing Software'],
      certifications: ['Professional Certifications', 'Skill Certifications']
    },
    keywords: ['freelance', 'independent', 'consultant', 'contract', 'self-employed'],
    projectTypes: ['Client Projects', 'Consulting Engagements', 'Contract Work', 'Retainer Clients'],
    achievementFormats: ['Completed X projects', 'Worked with X clients', 'Maintained X% satisfaction rate']
  },

  // =========== MEDIA & JOURNALISM ===========
  {
    id: 'journalist',
    title: 'Journalist',
    aliases: ['reporter', 'correspondent', 'news writer', 'editor'],
    industry: 'Media',
    category: 'creative',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'skills', 'experience', 'portfolio', 'education', 'awards'],
      required: ['summary', 'skills', 'experience', 'education'],
      optional: ['portfolio', 'awards', 'publications']
    },
    skills: {
      technical: ['Investigative Reporting', 'News Writing', 'Interviewing', 'Fact-Checking', 'Editing', 'Multimedia Journalism'],
      soft: ['Curiosity', 'Ethics', 'Communication', 'Deadline Management', 'Critical Thinking'],
      tools: ['CMS', 'Audio/Video Equipment', 'Social Media', 'Research Databases'],
      certifications: ['Journalism Degree', 'Press Card', 'Specialized Training']
    },
    keywords: ['journalism', 'reporting', 'news', 'investigative', 'editorial', 'media'],
    projectTypes: ['News Story', 'Investigation', 'Feature Article', 'Documentary', 'Podcast'],
    achievementFormats: ['Published X stories', 'Won X journalism awards', 'Covered X major events']
  },

  // =========== GOVERNMENT ===========
  {
    id: 'government-job-aspirant',
    title: 'Government Job Aspirant',
    aliases: ['civil services', 'government employee', 'public sector', 'upsc aspirant'],
    industry: 'Government',
    category: 'other',
    experienceLevels: ['fresher', 'intermediate'],
    sections: {
      order: ['summary', 'education', 'skills', 'experience', 'extracurriculars', 'achievements'],
      required: ['summary', 'education', 'skills'],
      optional: ['experience', 'extracurriculars', 'achievements', 'certifications']
    },
    skills: {
      technical: ['Public Administration', 'Policy Analysis', 'Research', 'Documentation', 'Data Analysis'],
      soft: ['Integrity', 'Communication', 'Leadership', 'Public Speaking', 'Ethics'],
      tools: ['MS Office', 'Government Portals', 'Research Tools'],
      certifications: ['Civil Services Exams', 'Government Certifications', 'Public Administration Courses']
    },
    keywords: ['government', 'public sector', 'civil services', 'administration', 'policy'],
    projectTypes: ['Policy Research', 'Community Service', 'Administrative Projects', 'Public Programs'],
    achievementFormats: ['Cleared X exam', 'Ranked X in competition', 'Served X community members']
  },

  // =========== AVIATION ===========
  {
    id: 'aviation-crew',
    title: 'Aviation Crew',
    aliases: ['flight attendant', 'cabin crew', 'air hostess', 'steward'],
    industry: 'Aviation',
    category: 'hospitality',
    experienceLevels: ['fresher', 'intermediate', 'experienced'],
    sections: {
      order: ['summary', 'certifications', 'skills', 'experience', 'education', 'languages'],
      required: ['summary', 'certifications', 'skills', 'experience', 'education'],
      optional: ['languages', 'awards']
    },
    skills: {
      technical: ['Safety Procedures', 'Emergency Response', 'Customer Service', 'First Aid', 'Service Excellence'],
      soft: ['Communication', 'Patience', 'Cultural Sensitivity', 'Stress Management', 'Teamwork'],
      tools: ['Cabin Equipment', 'Safety Equipment', 'Service Systems'],
      certifications: ['Cabin Crew Training', 'First Aid', 'Safety Certification', 'Airline-Specific Training']
    },
    keywords: ['aviation', 'cabin crew', 'flight attendant', 'customer service', 'safety', 'hospitality'],
    projectTypes: ['Safety Training', 'Service Excellence', 'Emergency Drills', 'Customer Care'],
    achievementFormats: ['Served X passengers', 'Maintained X% customer satisfaction', 'Completed X flight hours']
  }
];

// ============= HELPER FUNCTIONS =============

export function searchRoles(query: string): RoleData[] {
  const searchTerm = query.toLowerCase().trim();
  
  if (!searchTerm) return [];
  
  return roleDatabase.filter(role => {
    const matchesTitle = role.title.toLowerCase().includes(searchTerm);
    const matchesAliases = role.aliases.some(alias => alias.toLowerCase().includes(searchTerm));
    const matchesIndustry = role.industry.toLowerCase().includes(searchTerm);
    const matchesKeywords = role.keywords.some(keyword => keyword.toLowerCase().includes(searchTerm));
    
    return matchesTitle || matchesAliases || matchesIndustry || matchesKeywords;
  });
}

export function getRoleById(id: string): RoleData | undefined {
  return roleDatabase.find(role => role.id === id);
}

export function getIndustryById(id: string): IndustryInfo | undefined {
  return industries.find(industry => industry.id === id);
}

export function getRolesByIndustry(industryId: string): RoleData[] {
  const industry = getIndustryById(industryId);
  if (!industry) return [];
  
  return roleDatabase.filter(role => 
    industry.roles.includes(role.id)
  );
}

export function getAllRoles(): RoleData[] {
  return roleDatabase;
}

export function getPopularRoles(): RoleData[] {
  const popularIds = [
    'software-engineer', 'data-scientist', 'product-manager', 
    'ui-designer', 'marketing-executive', 'mba-graduate',
    'frontend-developer', 'data-analyst', 'hr-manager'
  ];
  
  return popularIds
    .map(id => getRoleById(id))
    .filter((role): role is RoleData => role !== undefined);
}

export function getSuggestedRoles(query: string): RoleData[] {
  if (!query.trim()) {
    return getPopularRoles();
  }
  
  const searchResults = searchRoles(query);
  
  if (searchResults.length === 0) {
    return getPopularRoles();
  }
  
  return searchResults.slice(0, 10);
}
