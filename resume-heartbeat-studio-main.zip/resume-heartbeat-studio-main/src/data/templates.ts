export interface Template {
  id: string;
  name: string;
  category: 'modern' | 'classic' | 'creative' | 'minimal' | 'professional';
  layout: 'one-column' | 'two-column' | 'sidebar-left' | 'sidebar-right';
  hasPhoto: boolean;
  colors: string[]; // Available color options
  defaultColor: string;
  description: string;
  popular?: boolean;
  new?: boolean;
  industry?: string;
}

// ATS-Friendly color palette - professional colors that work well with ATS systems
export const atsColors = {
  // Navy blues - most professional
  navy: '#1e3a5f',
  darkNavy: '#0f2847',
  deepBlue: '#1a365d',
  professionalBlue: '#2c5282',
  royalBlue: '#3b5998',
  
  // Teal & Green accents
  teal: '#0d9488',
  deepTeal: '#115e59',
  forestGreen: '#166534',
  emerald: '#059669',
  
  // Warm professional tones
  burgundy: '#7f1d1d',
  wine: '#881337',
  rust: '#c2410c',
  terracotta: '#b45309',
  
  // Classic dark tones
  black: '#000000',
  charcoal: '#1a1a1a',
  darkGray: '#374151',
  slate: '#475569',
  graphite: '#4b5563',
  
  // Purple tones
  purple: '#6d28d9',
  plum: '#7c3aed',
  indigo: '#4338ca',
  
  // Coral & Pink
  coral: '#f97316',
  rose: '#e11d48',
};

// All available color options for templates
export const colorOptions = [
  { name: 'Navy', color: atsColors.navy },
  { name: 'Deep Blue', color: atsColors.deepBlue },
  { name: 'Royal Blue', color: atsColors.royalBlue },
  { name: 'Teal', color: atsColors.teal },
  { name: 'Emerald', color: atsColors.emerald },
  { name: 'Forest', color: atsColors.forestGreen },
  { name: 'Burgundy', color: atsColors.burgundy },
  { name: 'Wine', color: atsColors.wine },
  { name: 'Terracotta', color: atsColors.terracotta },
  { name: 'Purple', color: atsColors.purple },
  { name: 'Indigo', color: atsColors.indigo },
  { name: 'Charcoal', color: atsColors.charcoal },
  { name: 'Slate', color: atsColors.slate },
  { name: 'Rose', color: atsColors.rose },
];

export const templates: Template[] = [
  // MODERN TEMPLATES - Clean with contemporary layouts
  { id: 'modern-1', name: 'Executive Modern', category: 'modern', layout: 'two-column', hasPhoto: true, colors: [atsColors.navy, atsColors.teal, atsColors.charcoal, atsColors.purple], defaultColor: atsColors.navy, description: 'Clean professional design with navy accents, perfect for executives', popular: true, industry: 'Business' },
  { id: 'modern-2', name: 'Tech Professional', category: 'modern', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.deepBlue, atsColors.teal, atsColors.slate, atsColors.indigo], defaultColor: atsColors.deepBlue, description: 'Ideal for tech professionals with a clean blue theme', industry: 'Technology' },
  { id: 'modern-3', name: 'Corporate Clean', category: 'modern', layout: 'two-column', hasPhoto: false, colors: [atsColors.professionalBlue, atsColors.charcoal, atsColors.navy], defaultColor: atsColors.professionalBlue, description: 'Corporate-ready design with professional blue tones', industry: 'Corporate' },
  { id: 'modern-4', name: 'Business Sharp', category: 'modern', layout: 'one-column', hasPhoto: false, colors: [atsColors.slate, atsColors.navy, atsColors.charcoal], defaultColor: atsColors.slate, description: 'Sharp modern layout for business professionals', industry: 'Business' },
  { id: 'modern-5', name: 'Digital Expert', category: 'modern', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.darkNavy, atsColors.teal, atsColors.purple], defaultColor: atsColors.darkNavy, description: 'Perfect for digital marketing and IT professionals', industry: 'Marketing' },
  { id: 'modern-6', name: 'Innovation', category: 'modern', layout: 'two-column', hasPhoto: true, colors: [atsColors.deepTeal, atsColors.emerald, atsColors.navy], defaultColor: atsColors.deepTeal, description: 'Modern design for innovative thinkers', industry: 'Startup' },
  { id: 'modern-7', name: 'Growth Leader', category: 'modern', layout: 'sidebar-left', hasPhoto: false, colors: [atsColors.forestGreen, atsColors.teal, atsColors.charcoal], defaultColor: atsColors.forestGreen, description: 'Professional green for sustainability and growth roles', industry: 'Sustainability' },
  { id: 'modern-8', name: 'Premium Modern', category: 'modern', layout: 'two-column', hasPhoto: true, colors: [atsColors.charcoal, atsColors.navy, atsColors.burgundy], defaultColor: atsColors.charcoal, description: 'Premium dark theme for senior positions', new: true, industry: 'Executive' },
  { id: 'modern-9', name: 'Digital Native', category: 'modern', layout: 'one-column', hasPhoto: false, colors: [atsColors.royalBlue, atsColors.indigo, atsColors.teal], defaultColor: atsColors.royalBlue, description: 'Digital-first design approach', industry: 'Tech' },
  { id: 'modern-10', name: 'Startup Ready', category: 'modern', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.teal, atsColors.purple, atsColors.coral], defaultColor: atsColors.teal, description: 'Perfect for startup environments', industry: 'Startup' },
  
  // CLASSIC TEMPLATES - Timeless professional designs
  { id: 'classic-1', name: 'Traditional', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.black, atsColors.charcoal, atsColors.darkGray], defaultColor: atsColors.black, description: 'Timeless black design for any industry', popular: true, industry: 'General' },
  { id: 'classic-2', name: 'Executive Suite', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.darkGray, atsColors.charcoal, atsColors.navy], defaultColor: atsColors.darkGray, description: 'Professional look for C-level executives', industry: 'Executive' },
  { id: 'classic-3', name: 'Academic Pro', category: 'classic', layout: 'one-column', hasPhoto: true, colors: [atsColors.charcoal, atsColors.navy, atsColors.forestGreen], defaultColor: atsColors.charcoal, description: 'Perfect for academic and research positions', industry: 'Academic' },
  { id: 'classic-4', name: 'Legal Standard', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.black, atsColors.charcoal, atsColors.darkGray], defaultColor: atsColors.black, description: 'Conservative design for legal professionals', industry: 'Legal' },
  { id: 'classic-5', name: 'Finance Elite', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.darkNavy, atsColors.charcoal, atsColors.black], defaultColor: atsColors.darkNavy, description: 'Banking and finance industry standard', industry: 'Finance' },
  { id: 'classic-6', name: 'Corporate Legacy', category: 'classic', layout: 'two-column', hasPhoto: false, colors: [atsColors.darkGray, atsColors.navy, atsColors.charcoal], defaultColor: atsColors.darkGray, description: 'Traditional corporate format', industry: 'Corporate' },
  { id: 'classic-7', name: 'Formal Executive', category: 'classic', layout: 'one-column', hasPhoto: true, colors: [atsColors.graphite, atsColors.charcoal, atsColors.navy], defaultColor: atsColors.graphite, description: 'Highly formal structure for senior roles', industry: 'Executive' },
  { id: 'classic-8', name: 'Heritage Pro', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.burgundy, atsColors.charcoal, atsColors.navy], defaultColor: atsColors.burgundy, description: 'Classic with a touch of elegance', industry: 'General' },
  { id: 'classic-9', name: 'Investment Pro', category: 'classic', layout: 'one-column', hasPhoto: false, colors: [atsColors.navy, atsColors.black, atsColors.charcoal], defaultColor: atsColors.navy, description: 'Banking and investment standard', industry: 'Finance' },
  { id: 'classic-10', name: 'Healthcare Pro', category: 'classic', layout: 'two-column', hasPhoto: true, colors: [atsColors.teal, atsColors.navy, atsColors.forestGreen], defaultColor: atsColors.teal, description: 'Healthcare professional resume', industry: 'Healthcare' },
  
  // CREATIVE TEMPLATES - Still ATS-friendly with colorful styling
  { id: 'creative-1', name: 'Design Lead', category: 'creative', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.coral, atsColors.purple, atsColors.teal, atsColors.rose], defaultColor: atsColors.coral, description: 'For design professionals maintaining ATS compatibility', popular: true, industry: 'Design' },
  { id: 'creative-2', name: 'Art Director', category: 'creative', layout: 'two-column', hasPhoto: true, colors: [atsColors.charcoal, atsColors.coral, atsColors.purple], defaultColor: atsColors.charcoal, description: 'Creative yet professional for art roles', industry: 'Art' },
  { id: 'creative-3', name: 'Brand Strategist', category: 'creative', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.purple, atsColors.teal, atsColors.rose], defaultColor: atsColors.purple, description: 'For brand and creative strategists', industry: 'Marketing' },
  { id: 'creative-4', name: 'UX Designer', category: 'creative', layout: 'two-column', hasPhoto: true, colors: [atsColors.indigo, atsColors.teal, atsColors.purple], defaultColor: atsColors.indigo, description: 'Clean design for UX/UI professionals', industry: 'UX/UI' },
  { id: 'creative-5', name: 'Creative Director', category: 'creative', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.burgundy, atsColors.wine, atsColors.charcoal], defaultColor: atsColors.burgundy, description: 'Bold yet ATS-compatible design', industry: 'Creative' },
  { id: 'creative-6', name: 'Motion Artist', category: 'creative', layout: 'two-column', hasPhoto: true, colors: [atsColors.plum, atsColors.indigo, atsColors.coral], defaultColor: atsColors.plum, description: 'For motion graphics professionals', industry: 'Animation' },
  { id: 'creative-7', name: 'Innovation Lead', category: 'creative', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.teal, atsColors.emerald, atsColors.purple], defaultColor: atsColors.teal, description: 'Modern creative with teal accents', new: true, industry: 'Innovation' },
  { id: 'creative-8', name: 'Visual Designer', category: 'creative', layout: 'two-column', hasPhoto: true, colors: [atsColors.rose, atsColors.coral, atsColors.purple], defaultColor: atsColors.rose, description: 'Visual design with professional appeal', industry: 'Design' },
  { id: 'creative-9', name: 'Marketing Lead', category: 'creative', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.terracotta, atsColors.burgundy, atsColors.coral], defaultColor: atsColors.terracotta, description: 'Marketing professional design', industry: 'Marketing' },
  { id: 'creative-10', name: 'Content Creator', category: 'creative', layout: 'two-column', hasPhoto: true, colors: [atsColors.purple, atsColors.indigo, atsColors.teal], defaultColor: atsColors.purple, description: 'Content creator showcase', industry: 'Content' },
  
  // MINIMAL TEMPLATES - Maximum whitespace, minimal design
  { id: 'minimal-1', name: 'Clean Slate', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.darkGray, atsColors.charcoal, atsColors.slate], defaultColor: atsColors.darkGray, description: 'Ultra-clean minimalist design', popular: true, industry: 'General' },
  { id: 'minimal-2', name: 'Simple Pro', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.slate, atsColors.charcoal, atsColors.navy], defaultColor: atsColors.slate, description: 'No-frills professional appearance', industry: 'General' },
  { id: 'minimal-3', name: 'Zen Resume', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.graphite, atsColors.charcoal, atsColors.darkGray], defaultColor: atsColors.graphite, description: 'Peaceful and organized layout', industry: 'General' },
  { id: 'minimal-4', name: 'Essential', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.charcoal, atsColors.darkGray, atsColors.black], defaultColor: atsColors.charcoal, description: 'Back to basics approach', industry: 'General' },
  { id: 'minimal-5', name: 'Light Focus', category: 'minimal', layout: 'two-column', hasPhoto: false, colors: [atsColors.slate, atsColors.navy, atsColors.teal], defaultColor: atsColors.slate, description: 'Light and airy professional design', industry: 'General' },
  { id: 'minimal-6', name: 'Content First', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.charcoal, atsColors.graphite, atsColors.slate], defaultColor: atsColors.charcoal, description: 'Content-focused minimal layout', industry: 'General' },
  { id: 'minimal-7', name: 'Subtle Style', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.darkGray, atsColors.slate, atsColors.charcoal], defaultColor: atsColors.darkGray, description: 'Understated elegance', industry: 'General' },
  { id: 'minimal-8', name: 'Pure Clean', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.black, atsColors.charcoal, atsColors.darkGray], defaultColor: atsColors.black, description: 'Maximum whitespace, pure content', industry: 'General' },
  { id: 'minimal-9', name: 'Mono Design', category: 'minimal', layout: 'one-column', hasPhoto: false, colors: [atsColors.black, atsColors.charcoal], defaultColor: atsColors.black, description: 'Monochrome minimalism', industry: 'General' },
  { id: 'minimal-10', name: 'Whitespace', category: 'minimal', layout: 'two-column', hasPhoto: false, colors: [atsColors.charcoal, atsColors.slate, atsColors.navy], defaultColor: atsColors.charcoal, description: 'Clean white space design', industry: 'General' },
  
  // PROFESSIONAL TEMPLATES - Industry-standard designs
  { id: 'professional-1', name: 'Corporate Pro', category: 'professional', layout: 'two-column', hasPhoto: true, colors: [atsColors.navy, atsColors.charcoal, atsColors.teal], defaultColor: atsColors.navy, description: 'Industry-standard professional design', popular: true, industry: 'Corporate' },
  { id: 'professional-2', name: 'Business Expert', category: 'professional', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.teal, atsColors.navy, atsColors.forestGreen], defaultColor: atsColors.teal, description: 'Perfect for business professionals', industry: 'Business' },
  { id: 'professional-3', name: 'Senior Manager', category: 'professional', layout: 'two-column', hasPhoto: true, colors: [atsColors.professionalBlue, atsColors.navy, atsColors.charcoal], defaultColor: atsColors.professionalBlue, description: 'Designed for management roles', industry: 'Management' },
  { id: 'professional-4', name: 'Consultant Elite', category: 'professional', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.deepBlue, atsColors.teal, atsColors.charcoal], defaultColor: atsColors.deepBlue, description: 'Ideal for consultants', industry: 'Consulting' },
  { id: 'professional-5', name: 'Director Level', category: 'professional', layout: 'two-column', hasPhoto: true, colors: [atsColors.darkNavy, atsColors.burgundy, atsColors.charcoal], defaultColor: atsColors.darkNavy, description: 'Executive director resume', industry: 'Executive' },
  { id: 'professional-6', name: 'Senior Expert', category: 'professional', layout: 'sidebar-left', hasPhoto: false, colors: [atsColors.slate, atsColors.navy, atsColors.teal], defaultColor: atsColors.slate, description: 'For senior professionals', industry: 'General' },
  { id: 'professional-7', name: 'Enterprise Grade', category: 'professional', layout: 'two-column', hasPhoto: true, colors: [atsColors.charcoal, atsColors.navy, atsColors.teal], defaultColor: atsColors.charcoal, description: 'Enterprise-level professionalism', industry: 'Enterprise' },
  { id: 'professional-8', name: 'Industry Expert', category: 'professional', layout: 'sidebar-right', hasPhoto: true, colors: [atsColors.forestGreen, atsColors.teal, atsColors.navy], defaultColor: atsColors.forestGreen, description: 'Showcase your expertise', new: true, industry: 'General' },
  { id: 'professional-9', name: 'HR Specialist', category: 'professional', layout: 'two-column', hasPhoto: true, colors: [atsColors.teal, atsColors.navy, atsColors.purple], defaultColor: atsColors.teal, description: 'Human resources specialist', industry: 'HR' },
  { id: 'professional-10', name: 'Sales Executive', category: 'professional', layout: 'sidebar-left', hasPhoto: true, colors: [atsColors.burgundy, atsColors.navy, atsColors.terracotta], defaultColor: atsColors.burgundy, description: 'Sales professional template', industry: 'Sales' },
];

export const categories = [
  { id: 'all', name: 'All Templates', count: templates.length },
  { id: 'modern', name: 'Modern', count: templates.filter(t => t.category === 'modern').length },
  { id: 'classic', name: 'Classic', count: templates.filter(t => t.category === 'classic').length },
  { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
  { id: 'minimal', name: 'Minimal', count: templates.filter(t => t.category === 'minimal').length },
  { id: 'professional', name: 'Professional', count: templates.filter(t => t.category === 'professional').length },
];

export const layoutFilters = [
  { id: 'all', name: 'All Layouts' },
  { id: 'one-column', name: 'Single Column' },
  { id: 'two-column', name: 'Two Column' },
  { id: 'sidebar-left', name: 'Left Sidebar' },
  { id: 'sidebar-right', name: 'Right Sidebar' },
];

export const photoFilters = [
  { id: 'all', name: 'All' },
  { id: 'with-photo', name: 'With Photo' },
  { id: 'without-photo', name: 'Without Photo' },
];
