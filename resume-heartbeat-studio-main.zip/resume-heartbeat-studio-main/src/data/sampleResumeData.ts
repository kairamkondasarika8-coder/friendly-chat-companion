// Sample resume data for template previews - ATS-friendly content
export const sampleResumeData = {
  name: "Alex Johnson",
  title: "Senior Software Engineer",
  email: "alex.johnson@email.com",
  phone: "+1 (555) 123-4567",
  location: "San Francisco, CA",
  linkedin: "linkedin.com/in/alexjohnson",
  github: "github.com/alexjohnson",
  summary: "Results-driven Software Engineer with 6+ years of experience building scalable web applications. Proficient in React, Node.js, and cloud technologies. Led teams to deliver projects 20% faster.",
  experience: [
    {
      title: "Senior Software Engineer",
      company: "Tech Corp Inc.",
      location: "San Francisco, CA",
      dates: "2021 - Present",
      bullets: [
        "Led development of microservices handling 1M+ daily requests",
        "Reduced application load time by 40% through optimization",
        "Mentored team of 5 junior developers",
      ],
    },
    {
      title: "Software Engineer",
      company: "StartupXYZ",
      location: "Austin, TX",
      dates: "2018 - 2021",
      bullets: [
        "Built React-based dashboard used by 50K+ users",
        "Implemented CI/CD pipeline reducing deploy time by 60%",
        "Collaborated with product team on feature specifications",
      ],
    },
  ],
  education: [
    {
      degree: "B.S. Computer Science",
      school: "University of California, Berkeley",
      dates: "2014 - 2018",
      gpa: "3.8/4.0",
    },
  ],
  skills: {
    "Languages": "JavaScript, TypeScript, Python, SQL",
    "Frameworks": "React, Node.js, Express, Next.js",
    "Tools": "Git, Docker, AWS, PostgreSQL",
  },
  projects: [
    {
      name: "E-Commerce Platform",
      tech: "React, Node.js, MongoDB",
      description: "Full-stack platform with 10K+ monthly users",
    },
  ],
  certifications: ["AWS Solutions Architect", "Google Cloud Professional"],
};

// Different sample personas for variety in template previews
export const samplePersonas = [
  {
    name: "Sarah Mitchell",
    title: "Product Manager",
    summary: "Strategic Product Manager with 5+ years driving product vision and roadmap. Increased user retention by 35% through data-driven feature prioritization.",
    skills: { "Core": "Product Strategy, Roadmapping, Analytics", "Tools": "Jira, Figma, Amplitude, SQL" },
  },
  {
    name: "Michael Chen",
    title: "Data Scientist",
    summary: "Data Scientist specializing in ML and predictive analytics. Built models that improved customer targeting by 45% and reduced churn by 20%.",
    skills: { "Languages": "Python, R, SQL", "ML/AI": "TensorFlow, PyTorch, Scikit-learn" },
  },
  {
    name: "Emily Rodriguez",
    title: "UX Designer",
    summary: "User-centered UX Designer with 4+ years creating intuitive digital experiences. Redesigned checkout flow increasing conversions by 28%.",
    skills: { "Design": "Figma, Sketch, Adobe XD", "Research": "User Testing, A/B Testing, Analytics" },
  },
  {
    name: "James Wilson",
    title: "Marketing Director",
    summary: "Results-oriented Marketing Director with expertise in growth strategies. Scaled user acquisition 3x while reducing CAC by 40%.",
    skills: { "Marketing": "SEO, SEM, Content Strategy", "Tools": "HubSpot, Google Analytics, Salesforce" },
  },
  {
    name: "David Park",
    title: "Full Stack Developer",
    summary: "Versatile Full Stack Developer building scalable applications. Delivered 15+ projects on time with high code quality standards.",
    skills: { "Frontend": "React, Vue, TypeScript", "Backend": "Node.js, Python, PostgreSQL" },
  },
];
