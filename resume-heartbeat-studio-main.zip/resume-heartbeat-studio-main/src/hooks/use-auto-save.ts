// Auto-save hook that provides Canva-like auto-save functionality
import { useEffect, useRef, useCallback, useState } from 'react';
import { useResumeStore } from '@/stores/resumeStore';
import { toast } from '@/hooks/use-toast';

interface AutoSaveState {
  lastSaved: Date | null;
  isSaving: boolean;
  hasUnsavedChanges: boolean;
}

export function useAutoSave(debounceMs: number = 2000) {
  const { resumeData } = useResumeStore();
  const [autoSaveState, setAutoSaveState] = useState<AutoSaveState>({
    lastSaved: null,
    isSaving: false,
    hasUnsavedChanges: false,
  });
  
  const previousDataRef = useRef<string>('');
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasInitializedRef = useRef(false);

  // Serialize data for comparison
  const serializedData = JSON.stringify(resumeData);

  // Check for changes and trigger auto-save
  useEffect(() => {
    // Skip the first render
    if (!hasInitializedRef.current) {
      hasInitializedRef.current = true;
      previousDataRef.current = serializedData;
      return;
    }

    // Check if data has changed
    if (serializedData !== previousDataRef.current) {
      setAutoSaveState(prev => ({ ...prev, hasUnsavedChanges: true }));
      
      // Clear previous timeout
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
      
      // Set new timeout for save
      saveTimeoutRef.current = setTimeout(() => {
        setAutoSaveState(prev => ({ ...prev, isSaving: true }));
        
        // The actual saving happens through Zustand's persist middleware
        // We just need to update our state to reflect this
        setTimeout(() => {
          previousDataRef.current = serializedData;
          setAutoSaveState({
            lastSaved: new Date(),
            isSaving: false,
            hasUnsavedChanges: false,
          });
        }, 300);
      }, debounceMs);
    }

    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, [serializedData, debounceMs]);

  // Format last saved time
  const getLastSavedText = useCallback(() => {
    if (!autoSaveState.lastSaved) return 'Not saved yet';
    
    const now = new Date();
    const diff = now.getTime() - autoSaveState.lastSaved.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    
    if (seconds < 5) return 'Just saved';
    if (seconds < 60) return `Saved ${seconds}s ago`;
    if (minutes < 60) return `Saved ${minutes}m ago`;
    
    return `Saved at ${autoSaveState.lastSaved.toLocaleTimeString()}`;
  }, [autoSaveState.lastSaved]);

  return {
    ...autoSaveState,
    getLastSavedText,
  };
}

// Hook to restore resume from localStorage on mount
export function useResumeRestore() {
  const { resumeData, hasExistingResume } = useResumeStore();
  const [isRestored, setIsRestored] = useState(false);
  const [showRestorePrompt, setShowRestorePrompt] = useState(false);

  useEffect(() => {
    // Check if there's existing resume data
    const hasData = hasExistingResume();
    
    if (hasData && !isRestored) {
      setShowRestorePrompt(true);
    }
    
    setIsRestored(true);
  }, [hasExistingResume, isRestored]);

  const dismissRestorePrompt = useCallback(() => {
    setShowRestorePrompt(false);
  }, []);

  return {
    hasExistingResume: hasExistingResume(),
    resumeData,
    showRestorePrompt,
    dismissRestorePrompt,
  };
}

export default useAutoSave;
