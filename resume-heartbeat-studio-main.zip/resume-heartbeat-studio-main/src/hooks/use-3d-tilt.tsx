import { useRef, useState, useCallback, MouseEvent } from "react";

interface TiltValues {
  rotateX: number;
  rotateY: number;
  x: number;
  y: number;
}

interface Use3DTiltOptions {
  maxTilt?: number;
  maxMove?: number;
  scale?: number;
  perspective?: number;
  transitionSpeed?: number;
}

export const use3DTilt = (options: Use3DTiltOptions = {}) => {
  const {
    maxTilt = 10,
    maxMove = 5,
    scale = 1.02,
    perspective = 1000,
    transitionSpeed = 400,
  } = options;

  const ref = useRef<HTMLDivElement>(null);
  const [tiltValues, setTiltValues] = useState<TiltValues>({
    rotateX: 0,
    rotateY: 0,
    x: 0,
    y: 0,
  });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = useCallback(
    (e: MouseEvent<HTMLDivElement>) => {
      if (!ref.current) return;

      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const mouseX = e.clientX - centerX;
      const mouseY = e.clientY - centerY;

      const rotateX = (mouseY / (rect.height / 2)) * -maxTilt;
      const rotateY = (mouseX / (rect.width / 2)) * maxTilt;
      const moveX = (mouseX / (rect.width / 2)) * maxMove;
      const moveY = (mouseY / (rect.height / 2)) * maxMove;

      setTiltValues({
        rotateX,
        rotateY,
        x: moveX,
        y: moveY,
      });
    },
    [maxTilt, maxMove]
  );

  const handleMouseEnter = useCallback(() => {
    setIsHovered(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
    setTiltValues({ rotateX: 0, rotateY: 0, x: 0, y: 0 });
  }, []);

  const style = {
    transform: isHovered
      ? `perspective(${perspective}px) rotateX(${tiltValues.rotateX}deg) rotateY(${tiltValues.rotateY}deg) translateX(${tiltValues.x}px) translateY(${tiltValues.y}px) scale(${scale})`
      : `perspective(${perspective}px) rotateX(0deg) rotateY(0deg) translateX(0px) translateY(0px) scale(1)`,
    transition: `transform ${transitionSpeed}ms cubic-bezier(0.03, 0.98, 0.52, 0.99)`,
    transformStyle: "preserve-3d" as const,
  };

  return {
    ref,
    style,
    handlers: {
      onMouseMove: handleMouseMove,
      onMouseEnter: handleMouseEnter,
      onMouseLeave: handleMouseLeave,
    },
  };
};
