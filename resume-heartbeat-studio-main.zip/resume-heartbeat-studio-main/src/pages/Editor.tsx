import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Download, 
  FileText, 
  Trash2, 
  Plus, 
  ChevronDown,
  User,
  Briefcase,
  GraduationCap,
  Code,
  FolderGit2,
  Eye,
  EyeOff,
  Award,
  Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { toast } from "@/hooks/use-toast";
import Header from "@/components/layout/Header";
import ResumePreview from "@/components/resume/ResumePreview";
import ATSScoreCard from "@/components/resume/ATSScoreCard";
import AutoSaveIndicator from "@/components/editor/AutoSaveIndicator";
import Tilt3DCard from "@/components/3d/Tilt3DCard";
import Background3DElements from "@/components/3d/Background3DElements";
import { useResumeStore, Education, Experience, Skill, Project, Certification, Extracurricular } from "@/stores/resumeStore";
import { templates } from "@/data/templates";

const Editor = () => {
  const {
    resumeData,
    setPersonalInfo,
    addEducation,
    updateEducation,
    removeEducation,
    addExperience,
    updateExperience,
    removeExperience,
    addSkill,
    removeSkill,
    addProject,
    updateProject,
    removeProject,
    addCertification,
    updateCertification,
    removeCertification,
    addExtracurricular,
    updateExtracurricular,
    removeExtracurricular,
    setSelectedTemplate,
    resetResume,
  } = useResumeStore();

  const [showPreview, setShowPreview] = useState(true);
  const [activeSection, setActiveSection] = useState<string>("personal");

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const handleDownloadPDF = async () => {
    try {
      const html2pdf = (await import("html2pdf.js")).default;
      const element = document.getElementById("resume-preview");
      if (!element) return;

      const opt = {
        margin: 0.5,
        filename: `${resumeData.personalInfo.fullName || "resume"}.pdf`,
        image: { type: "jpeg" as const, quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: "in" as const, format: "letter" as const, orientation: "portrait" as const },
      };

      await html2pdf().set(opt).from(element).save();
      toast({
        title: "PDF Downloaded!",
        description: "Your resume has been saved as a PDF.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "There was an error downloading your resume.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadWord = () => {
    const element = document.getElementById("resume-preview");
    if (!element) return;

    const header = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' 
            xmlns:w='urn:schemas-microsoft-com:office:word' 
            xmlns='http://www.w3.org/TR/REC-html40'>
      <head><meta charset='utf-8'><title>Resume</title></head><body>
    `;
    const footer = "</body></html>";
    const sourceHTML = header + element.innerHTML + footer;

    const blob = new Blob(["\ufeff", sourceHTML], {
      type: "application/msword",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${resumeData.personalInfo.fullName || "resume"}.doc`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Word Document Downloaded!",
      description: "Your resume has been saved as a Word document.",
    });
  };

  const handleReset = () => {
    if (confirm("Are you sure you want to reset your resume? This cannot be undone.")) {
      resetResume();
      toast({
        title: "Resume Reset",
        description: "Your resume has been cleared.",
      });
    }
  };

  const sections = [
    { id: "personal", label: "Personal Info", icon: User },
    { id: "experience", label: "Experience", icon: Briefcase },
    { id: "education", label: "Education", icon: GraduationCap },
    { id: "skills", label: "Skills", icon: Code },
    { id: "projects", label: "Projects", icon: FolderGit2 },
    { id: "certifications", label: "Certifications", icon: Award },
    { id: "extracurriculars", label: "Activities", icon: Activity },
  ];

  return (
    <div className="min-h-screen bg-background relative">
      <Background3DElements variant="subtle" />
      <Header />
      
      <main className="pt-20 md:pt-24">
        <div className="container-wide py-6">
          {/* Top Bar */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-wrap items-center justify-between gap-4 mb-6"
          >
            <div className="flex items-center gap-4">
              <h1 className="font-display text-2xl font-bold text-foreground">
                Resume Editor
              </h1>
              <AutoSaveIndicator />
              <Select
                value={resumeData.selectedTemplate}
                onValueChange={setSelectedTemplate}
              >
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent className="bg-popover">
                  {templates.slice(0, 20).map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPreview(!showPreview)}
                className="md:hidden"
              >
                {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleReset}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Reset
              </Button>
              <Button variant="outline" size="sm" onClick={handleDownloadWord}>
                <FileText className="w-4 h-4 mr-2" />
                Word
              </Button>
              <Button className="btn-primary" size="sm" onClick={handleDownloadPDF}>
                <Download className="w-4 h-4 mr-2" />
                PDF
              </Button>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Editor Panel */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              {/* Section Navigation */}
              <div className="flex gap-2 overflow-x-auto pb-2">
                {sections.map((section) => (
                  <Button
                    key={section.id}
                    variant={activeSection === section.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setActiveSection(section.id)}
                    className={activeSection === section.id ? "bg-primary" : ""}
                  >
                    <section.icon className="w-4 h-4 mr-2" />
                    {section.label}
                  </Button>
                ))}
              </div>

              {/* Personal Info Section */}
              {activeSection === "personal" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Personal Information
                  </h2>
                  
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        value={resumeData.personalInfo.fullName}
                        onChange={(e) => setPersonalInfo({ fullName: e.target.value })}
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={resumeData.personalInfo.email}
                        onChange={(e) => setPersonalInfo({ email: e.target.value })}
                        placeholder="john@example.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={resumeData.personalInfo.phone}
                        onChange={(e) => setPersonalInfo({ phone: e.target.value })}
                        placeholder="+91 93465 28513"
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={resumeData.personalInfo.location}
                        onChange={(e) => setPersonalInfo({ location: e.target.value })}
                        placeholder="Hyderabad, Telangana, India"
                      />
                    </div>
                    <div>
                      <Label htmlFor="linkedin">LinkedIn</Label>
                      <Input
                        id="linkedin"
                        value={resumeData.personalInfo.linkedin}
                        onChange={(e) => setPersonalInfo({ linkedin: e.target.value })}
                        placeholder="linkedin.com/in/johndoe"
                      />
                    </div>
                    <div>
                      <Label htmlFor="github">GitHub</Label>
                      <Input
                        id="github"
                        value={resumeData.personalInfo.github || ''}
                        onChange={(e) => setPersonalInfo({ github: e.target.value })}
                        placeholder="github.com/johndoe"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <Label htmlFor="website">Portfolio Website</Label>
                      <Input
                        id="website"
                        value={resumeData.personalInfo.website}
                        onChange={(e) => setPersonalInfo({ website: e.target.value })}
                        placeholder="johndoe.com"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="summary">Professional Summary / Profile</Label>
                    <Textarea
                      id="summary"
                      value={resumeData.personalInfo.summary}
                      onChange={(e) => setPersonalInfo({ summary: e.target.value })}
                      placeholder="Motivated and detail-oriented professional with a strong foundation in..."
                      rows={4}
                    />
                  </div>
                </div>
              )}

              {/* Experience Section */}
              {activeSection === "experience" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <Briefcase className="w-5 h-5 text-primary" />
                      Work Experience
                    </h2>
                    <Button
                      size="sm"
                      onClick={() =>
                        addExperience({
                          id: generateId(),
                          company: "",
                          position: "",
                          location: "",
                          startDate: "",
                          endDate: "",
                          current: false,
                          description: "",
                        })
                      }
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {resumeData.experience.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">
                      No experience added yet. Click "Add" to get started.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.experience.map((exp, index) => (
                        <Collapsible key={exp.id} defaultOpen={index === 0}>
                          <div className="border border-border rounded-lg overflow-hidden">
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                              <span className="font-medium">
                                {exp.position || exp.company || `Experience ${index + 1}`}
                              </span>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeExperience(exp.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                                <ChevronDown className="w-4 h-4" />
                              </div>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-4 pt-0 space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <div>
                                  <Label>Job Title *</Label>
                                  <Input
                                    value={exp.position}
                                    onChange={(e) => updateExperience(exp.id, { position: e.target.value })}
                                    placeholder="Software Engineer"
                                  />
                                </div>
                                <div>
                                  <Label>Company *</Label>
                                  <Input
                                    value={exp.company}
                                    onChange={(e) => updateExperience(exp.id, { company: e.target.value })}
                                    placeholder="Google"
                                  />
                                </div>
                                <div>
                                  <Label>Location</Label>
                                  <Input
                                    value={exp.location}
                                    onChange={(e) => updateExperience(exp.id, { location: e.target.value })}
                                    placeholder="San Francisco, CA"
                                  />
                                </div>
                                <div className="flex gap-2">
                                  <div className="flex-1">
                                    <Label>Start Date</Label>
                                    <Input
                                      value={exp.startDate}
                                      onChange={(e) => updateExperience(exp.id, { startDate: e.target.value })}
                                      placeholder="Jan 2020"
                                    />
                                  </div>
                                  <div className="flex-1">
                                    <Label>End Date</Label>
                                    <Input
                                      value={exp.endDate}
                                      onChange={(e) => updateExperience(exp.id, { endDate: e.target.value })}
                                      placeholder="Present"
                                      disabled={exp.current}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Checkbox
                                  id={`current-${exp.id}`}
                                  checked={exp.current}
                                  onCheckedChange={(checked) =>
                                    updateExperience(exp.id, { current: checked as boolean })
                                  }
                                />
                                <Label htmlFor={`current-${exp.id}`} className="text-sm cursor-pointer">
                                  I currently work here
                                </Label>
                              </div>
                              <div>
                                <Label>Description (use bullet points with each on new line)</Label>
                                <Textarea
                                  value={exp.description}
                                  onChange={(e) => updateExperience(exp.id, { description: e.target.value })}
                                  placeholder="• Developed and maintained web applications&#10;• Led a team of 5 engineers..."
                                  rows={4}
                                />
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Education Section */}
              {activeSection === "education" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-primary" />
                      Education
                    </h2>
                    <Button
                      size="sm"
                      onClick={() =>
                        addEducation({
                          id: generateId(),
                          school: "",
                          degree: "",
                          field: "",
                          startDate: "",
                          endDate: "",
                          gpa: "",
                          description: "",
                        })
                      }
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {resumeData.education.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">
                      No education added yet. Click "Add" to get started.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.education.map((edu, index) => (
                        <Collapsible key={edu.id} defaultOpen={index === 0}>
                          <div className="border border-border rounded-lg overflow-hidden">
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                              <span className="font-medium">
                                {edu.school || edu.degree || `Education ${index + 1}`}
                              </span>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeEducation(edu.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                                <ChevronDown className="w-4 h-4" />
                              </div>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-4 pt-0 space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <div>
                                  <Label>School/University *</Label>
                                  <Input
                                    value={edu.school}
                                    onChange={(e) => updateEducation(edu.id, { school: e.target.value })}
                                    placeholder="AMS Arts & Science College for Women"
                                  />
                                </div>
                                <div>
                                  <Label>Degree</Label>
                                  <Input
                                    value={edu.degree}
                                    onChange={(e) => updateEducation(edu.id, { degree: e.target.value })}
                                    placeholder="B.Sc. Honours"
                                  />
                                </div>
                                <div>
                                  <Label>Field of Study</Label>
                                  <Input
                                    value={edu.field}
                                    onChange={(e) => updateEducation(edu.id, { field: e.target.value })}
                                    placeholder="Computer Science"
                                  />
                                </div>
                                <div>
                                  <Label>CGPA/GPA</Label>
                                  <Input
                                    value={edu.gpa || ""}
                                    onChange={(e) => updateEducation(edu.id, { gpa: e.target.value })}
                                    placeholder="8.7 / 10"
                                  />
                                </div>
                                <div>
                                  <Label>Start Date</Label>
                                  <Input
                                    value={edu.startDate}
                                    onChange={(e) => updateEducation(edu.id, { startDate: e.target.value })}
                                    placeholder="June 2023"
                                  />
                                </div>
                                <div>
                                  <Label>End Date</Label>
                                  <Input
                                    value={edu.endDate}
                                    onChange={(e) => updateEducation(edu.id, { endDate: e.target.value })}
                                    placeholder="April 2027"
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>Description (coursework, achievements - each on new line)</Label>
                                <Textarea
                                  value={edu.description || ""}
                                  onChange={(e) => updateEducation(edu.id, { description: e.target.value })}
                                  placeholder="• Four-year degree covering Programming, Data Structures, Algorithms..."
                                  rows={3}
                                />
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Skills Section */}
              {activeSection === "skills" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <Code className="w-5 h-5 text-primary" />
                      Technical Skills
                    </h2>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    Add skills with optional categories (e.g., "Programming: Python" or just "Python")
                  </p>

                  <div className="flex gap-2">
                    <Input
                      id="newSkill"
                      placeholder="Category: Skill (e.g., Programming: Python)"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          const input = e.target as HTMLInputElement;
                          if (input.value.trim()) {
                            const parts = input.value.split(':');
                            const category = parts.length > 1 ? parts[0].trim() : 'Skills';
                            const name = parts.length > 1 ? parts[1].trim() : input.value.trim();
                            addSkill({
                              id: generateId(),
                              name: name,
                              level: "intermediate",
                              category: category,
                            });
                            input.value = "";
                          }
                        }
                      }}
                    />
                    <Button
                      onClick={() => {
                        const input = document.getElementById("newSkill") as HTMLInputElement;
                        if (input.value.trim()) {
                          const parts = input.value.split(':');
                          const category = parts.length > 1 ? parts[0].trim() : 'Skills';
                          const name = parts.length > 1 ? parts[1].trim() : input.value.trim();
                          addSkill({
                            id: generateId(),
                            name: name,
                            level: "intermediate",
                            category: category,
                          });
                          input.value = "";
                        }
                      }}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {resumeData.skills.map((skill) => (
                      <span
                        key={skill.id}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm group"
                      >
                        {skill.category && skill.category !== 'Skills' && (
                          <span className="text-xs text-muted-foreground">{skill.category}:</span>
                        )}
                        {skill.name}
                        <button
                          onClick={() => removeSkill(skill.id)}
                          className="ml-1 opacity-50 hover:opacity-100 transition-opacity"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>

                  {resumeData.skills.length === 0 && (
                    <p className="text-muted-foreground text-center py-4">
                      Add skills to showcase your expertise
                    </p>
                  )}
                </div>
              )}

              {/* Projects Section */}
              {activeSection === "projects" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <FolderGit2 className="w-5 h-5 text-primary" />
                      Projects
                    </h2>
                    <Button
                      size="sm"
                      onClick={() =>
                        addProject({
                          id: generateId(),
                          name: "",
                          description: "",
                          technologies: "",
                          link: "",
                        })
                      }
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {resumeData.projects.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">
                      No projects added yet. Click "Add" to get started.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.projects.map((project, index) => (
                        <Collapsible key={project.id} defaultOpen={index === 0}>
                          <div className="border border-border rounded-lg overflow-hidden">
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                              <span className="font-medium">
                                {project.name || `Project ${index + 1}`}
                              </span>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeProject(project.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                                <ChevronDown className="w-4 h-4" />
                              </div>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-4 pt-0 space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <div>
                                  <Label>Project Name *</Label>
                                  <Input
                                    value={project.name}
                                    onChange={(e) => updateProject(project.id, { name: e.target.value })}
                                    placeholder="Online Resume Builder"
                                  />
                                </div>
                                <div>
                                  <Label>Technologies Used</Label>
                                  <Input
                                    value={project.technologies}
                                    onChange={(e) => updateProject(project.id, { technologies: e.target.value })}
                                    placeholder="Python, Selenium, HTML, CSS, JavaScript"
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>Link (optional)</Label>
                                <Input
                                  value={project.link || ""}
                                  onChange={(e) => updateProject(project.id, { link: e.target.value })}
                                  placeholder="github.com/username/project"
                                />
                              </div>
                              <div>
                                <Label>Description (bullet points, each on new line)</Label>
                                <Textarea
                                  value={project.description}
                                  onChange={(e) => updateProject(project.id, { description: e.target.value })}
                                  placeholder="• Developed an online resume builder using Python and Selenium&#10;• Designed customizable resume templates..."
                                  rows={4}
                                />
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Certifications Section */}
              {activeSection === "certifications" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <Award className="w-5 h-5 text-primary" />
                      Certifications
                    </h2>
                    <Button
                      size="sm"
                      onClick={() =>
                        addCertification({
                          id: generateId(),
                          name: "",
                          issuer: "",
                          date: "",
                          description: "",
                        })
                      }
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {(!resumeData.certifications || resumeData.certifications.length === 0) ? (
                    <p className="text-muted-foreground text-center py-8">
                      No certifications added yet. Click "Add" to get started.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.certifications.map((cert, index) => (
                        <Collapsible key={cert.id} defaultOpen={index === 0}>
                          <div className="border border-border rounded-lg overflow-hidden">
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                              <span className="font-medium">
                                {cert.name || `Certification ${index + 1}`}
                              </span>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeCertification(cert.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                                <ChevronDown className="w-4 h-4" />
                              </div>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-4 pt-0 space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <div>
                                  <Label>Certification Name *</Label>
                                  <Input
                                    value={cert.name}
                                    onChange={(e) => updateCertification(cert.id, { name: e.target.value })}
                                    placeholder="AWS Certification"
                                  />
                                </div>
                                <div>
                                  <Label>Issuer</Label>
                                  <Input
                                    value={cert.issuer}
                                    onChange={(e) => updateCertification(cert.id, { issuer: e.target.value })}
                                    placeholder="Amazon Web Services"
                                  />
                                </div>
                                <div>
                                  <Label>Issue Date</Label>
                                  <Input
                                    value={cert.date}
                                    onChange={(e) => updateCertification(cert.id, { date: e.target.value })}
                                    placeholder="2025"
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>Description (optional)</Label>
                                <Textarea
                                  value={cert.description || ""}
                                  onChange={(e) => updateCertification(cert.id, { description: e.target.value })}
                                  placeholder="Completed AWS training and certification."
                                  rows={2}
                                />
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Extracurricular Activities Section */}
              {activeSection === "extracurriculars" && (
                <div className="card-elevated rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
                      <Activity className="w-5 h-5 text-primary" />
                      Leadership / Extracurricular
                    </h2>
                    <Button
                      size="sm"
                      onClick={() =>
                        addExtracurricular({
                          id: generateId(),
                          title: "",
                          organization: "",
                          startDate: "",
                          endDate: "",
                          description: "",
                        })
                      }
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {(!resumeData.extracurriculars || resumeData.extracurriculars.length === 0) ? (
                    <p className="text-muted-foreground text-center py-8">
                      No activities added yet. Click "Add" to get started.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.extracurriculars.map((activity, index) => (
                        <Collapsible key={activity.id} defaultOpen={index === 0}>
                          <div className="border border-border rounded-lg overflow-hidden">
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                              <span className="font-medium">
                                {activity.title || `Activity ${index + 1}`}
                              </span>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeExtracurricular(activity.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                                <ChevronDown className="w-4 h-4" />
                              </div>
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-4 pt-0 space-y-3">
                              <div className="grid sm:grid-cols-2 gap-3">
                                <div>
                                  <Label>Title/Role *</Label>
                                  <Input
                                    value={activity.title}
                                    onChange={(e) => updateExtracurricular(activity.id, { title: e.target.value })}
                                    placeholder="NSS Volunteer"
                                  />
                                </div>
                                <div>
                                  <Label>Organization</Label>
                                  <Input
                                    value={activity.organization}
                                    onChange={(e) => updateExtracurricular(activity.id, { organization: e.target.value })}
                                    placeholder="National Service Scheme"
                                  />
                                </div>
                                <div>
                                  <Label>Start Date</Label>
                                  <Input
                                    value={activity.startDate}
                                    onChange={(e) => updateExtracurricular(activity.id, { startDate: e.target.value })}
                                    placeholder="Spring 2023"
                                  />
                                </div>
                                <div>
                                  <Label>End Date</Label>
                                  <Input
                                    value={activity.endDate}
                                    onChange={(e) => updateExtracurricular(activity.id, { endDate: e.target.value })}
                                    placeholder="Present"
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>Description</Label>
                                <Textarea
                                  value={activity.description || ""}
                                  onChange={(e) => updateExtracurricular(activity.id, { description: e.target.value })}
                                  placeholder="Participated in community service activities, organizing events, and promoting teamwork."
                                  rows={2}
                                />
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ATS Score Card */}
              <ATSScoreCard data={resumeData} />
            </motion.div>

            {/* Preview Panel */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`${showPreview ? "block" : "hidden"} lg:block`}
            >
              <div className="sticky top-24">
                <Tilt3DCard
                  className="card-elevated rounded-2xl p-4 overflow-auto max-h-[calc(100vh-120px)]"
                  maxTilt={3}
                  scale={1.01}
                  glareEnabled={false}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-display text-lg font-semibold text-foreground">
                      Live Preview
                    </h2>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={handleDownloadWord}>
                        <FileText className="w-4 h-4 mr-1" />
                        Word
                      </Button>
                      <Button className="btn-primary" size="sm" onClick={handleDownloadPDF}>
                        <Download className="w-4 h-4 mr-1" />
                        PDF
                      </Button>
                    </div>
                  </div>
                  <div className="border border-border rounded-lg overflow-hidden">
                    <ResumePreview data={resumeData} />
                  </div>
                </Tilt3DCard>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Editor;
