import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { 
  FileText, 
  Download, 
  CheckCircle, 
  Star, 
  Zap, 
  Shield, 
  ArrowRight,
  Sparkles,
  Layout,
  Award,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HeroResumePreview from "@/components/home/HeroResumePreview";
import Tilt3DCard from "@/components/3d/Tilt3DCard";
import Background3DElements from "@/components/3d/Background3DElements";
import { useResumeStore } from "@/stores/resumeStore";
import heroIllustration from "@/assets/hero-illustration.png";

const Index = () => {
  const hasExistingResume = useResumeStore((state) => state.hasExistingResume);

  const features = [
    {
      icon: Layout,
      title: "100+ ATS Templates",
      description: "Professional templates optimized to pass Applicant Tracking Systems across every industry.",
    },
    {
      icon: Zap,
      title: "Real-Time Preview",
      description: "See changes instantly as you build your perfect resume with live editing.",
    },
    {
      icon: Award,
      title: "ATS Score Checker",
      description: "Get instant feedback on how well your resume will perform with recruiters.",
    },
    {
      icon: Download,
      title: "Multiple Formats",
      description: "Download your resume as PDF or Word document instantly, ready to apply.",
    },
    {
      icon: Shield,
      title: "100% Free Forever",
      description: "No hidden fees, no subscriptions. Completely free to use for everyone.",
    },
    {
      icon: Sparkles,
      title: "Role-Specific Designs",
      description: "Templates adapt automatically based on your job role and experience level.",
    },
  ];

  const testimonials = [
    {
      name: "Sarah Mitchell",
      role: "Software Engineer",
      company: "Google",
      image: "SM",
      content: "This resume builder helped me land my dream job at Google. The ATS optimization feature is incredible!",
      rating: 5,
    },
    {
      name: "James Chen",
      role: "Product Manager",
      company: "Microsoft",
      image: "JC",
      content: "I've tried many resume builders, but this one stands out. Clean templates and super easy to use.",
      rating: 5,
    },
    {
      name: "Emily Rodriguez",
      role: "Marketing Director",
      company: "Netflix",
      image: "ER",
      content: "The real-time preview saved me so much time. Got multiple interview calls within a week!",
      rating: 5,
    },
    {
      name: "Michael Park",
      role: "Data Scientist",
      company: "Amazon",
      image: "MP",
      content: "The ATS score feature helped me understand what recruiters look for. Highly recommend!",
      rating: 5,
    },
  ];

  const stats = [
    { value: "100+", label: "Professional Templates" },
    { value: "500K+", label: "Resumes Created" },
    { value: "98%", label: "ATS Pass Rate" },
    { value: "Free", label: "Forever" },
  ];

  return (
    <div className="min-h-screen bg-background relative">
      <Background3DElements variant="colorful" />
      <Header />
      
      {/* Hero Section - Clean & Professional */}
      <section className="relative pt-28 md:pt-36 pb-16 md:pb-24 overflow-hidden">
        {/* Subtle background gradient */}
        <div className="absolute inset-0 bg-gradient-hero" />
        <motion.div
          className="absolute top-20 -left-32 w-[500px] h-[500px] rounded-full opacity-20 blur-[100px]"
          style={{ background: "hsl(var(--primary) / 0.3)" }}
          animate={{ scale: [1, 1.15, 1], x: [0, 30, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute -bottom-20 -right-32 w-[400px] h-[400px] rounded-full opacity-15 blur-[80px]"
          style={{ background: "hsl(var(--accent) / 0.3)" }}
          animate={{ scale: [1.1, 1, 1.1], x: [0, -20, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />
        
        <div className="container-wide relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left: Text Content */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center lg:text-left"
            >
              <motion.div 
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 border border-primary/20"
                animate={{ scale: [1, 1.02, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Sparkles className="w-4 h-4" />
                100% Free Resume Builder
              </motion.div>
              
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
                Build a Professional{" "}
                <br className="hidden sm:block" />
                Resume in Just{" "}
                <span className="text-gradient">2 Minutes</span>
              </h1>
              
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                ATS-friendly. Interview-getting templates. Instant export to PDF. 
                Trusted by thousands of job seekers worldwide.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to="/editor">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button className="btn-accent text-base md:text-lg px-8 py-6 w-full sm:w-auto uppercase tracking-wider font-bold">
                      Create My Resume
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </motion.div>
                </Link>
                <Link to="/templates">
                  <Button variant="outline" className="text-base md:text-lg px-8 py-6 w-full sm:w-auto border-2 hover:bg-primary/5">
                    View Templates
                  </Button>
                </Link>
              </div>
              
              {/* Trust indicators */}
              <div className="flex items-center gap-6 mt-8 justify-center lg:justify-start">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4 text-primary" />
                  <span className="font-semibold text-foreground">Trusted by 5,00,000+</span> users
                </div>
              </div>
              
              <div className="flex items-center gap-5 mt-4 justify-center lg:justify-start text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  No signup required
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Instant download
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  ATS-optimized
                </span>
              </div>
            </motion.div>
            
            {/* Right: Hero Illustration */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="relative flex justify-center"
            >
              <img 
                src={heroIllustration} 
                alt="Professional resume builder illustration" 
                className="w-full max-w-lg lg:max-w-xl drop-shadow-2xl"
              />
              
              {/* Floating ATS Badge */}
              <motion.div
                className="absolute -top-2 right-4 lg:right-0 z-10"
                animate={{ y: [-5, 5, -5] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="bg-accent text-accent-foreground px-4 py-2 rounded-full text-sm font-bold shadow-xl">
                  ATS Score: 95%
                </div>
              </motion.div>

              {/* Floating Download Card */}
              <motion.div
                className="absolute -bottom-2 left-4 lg:left-0 z-10"
                animate={{ y: [-6, 6, -6] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              >
                <div className="bg-card rounded-xl shadow-xl border border-border p-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center">
                      <Download className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-xs text-foreground">Download Ready</p>
                      <p className="text-[10px] text-muted-foreground">PDF & Word</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-foreground relative overflow-hidden">
        <div className="container-wide relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="font-display text-3xl md:text-4xl font-bold text-primary mb-1">
                  {stat.value}
                </div>
                <div className="text-background/70 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Resume Showcase - Single Prominent Resume */}
      <section className="section-padding relative overflow-hidden">
        <div className="container-wide">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Premium Resume That{" "}
              <span className="text-gradient">Gets You Hired</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our professionally designed templates are crafted to impress recruiters and pass ATS systems.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="flex justify-center"
          >
            <div className="w-full max-w-md">
              <HeroResumePreview />
            </div>
          </motion.div>

          <div className="text-center mt-10">
            <Link to="/templates">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button className="btn-primary text-lg px-8 py-6">
                  Browse All 100+ Templates
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-muted/50 relative overflow-hidden">
        <div className="container-wide">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Everything You Need to{" "}
              <span className="text-gradient">Land Your Dream Job</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our powerful features help you create resumes that stand out and get past ATS filters.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Tilt3DCard
                  className="card-elevated rounded-2xl p-6 cursor-pointer h-full"
                  maxTilt={8}
                  scale={1.03}
                >
                  <div className="group">
                    <motion.div 
                      className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors"
                      whileHover={{ rotateZ: 10, scale: 1.1 }}
                    >
                      <feature.icon className="w-6 h-6 text-primary" />
                    </motion.div>
                    <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </div>
                </Tilt3DCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="section-padding relative overflow-hidden">
        <div className="container-wide relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Create Your Resume in{" "}
              <span className="text-gradient">3 Simple Steps</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "1", title: "Choose a Template", desc: "Browse 100+ professional templates and pick the one that fits your style and role." },
              { step: "2", title: "Fill In Your Details", desc: "Add your experience, education, skills, and achievements with our easy editor." },
              { step: "3", title: "Download & Apply", desc: "Get your ATS-optimized resume in PDF or Word format and start applying." },
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.15 }}
                viewport={{ once: true }}
                className="relative text-center"
              >
                <motion.div 
                  className="w-16 h-16 rounded-full bg-gradient-primary text-primary-foreground font-display text-2xl font-bold flex items-center justify-center mx-auto mb-6 shadow-glow"
                  whileHover={{ scale: 1.1, rotateY: 180 }}
                  transition={{ duration: 0.5 }}
                >
                  {item.step}
                </motion.div>
                {index < 2 && (
                  <div className="hidden md:block absolute top-8 left-[60%] w-[80%] h-0.5 bg-border" />
                )}
                <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                  {item.title}
                </h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/editor">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button className="btn-accent text-lg px-8 py-6">
                  Start Building Now
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="section-padding bg-muted/50 relative overflow-hidden">
        <div className="container-wide">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Loved by{" "}
              <span className="text-gradient">500,000+ Job Seekers</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              See what our users have to say about their experience.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Tilt3DCard className="card-elevated rounded-2xl p-6 h-full" maxTilt={6} scale={1.02}>
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="text-foreground mb-6 text-sm leading-relaxed">
                    "{testimonial.content}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-sm">
                      {testimonial.image}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {testimonial.role} at {testimonial.company}
                      </p>
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-primary relative overflow-hidden">
        <motion.div
          className="absolute top-10 left-10 w-24 h-24 border-2 border-primary-foreground/20 rounded-lg"
          animate={{ rotateZ: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute bottom-10 right-10 w-32 h-32 border-2 border-primary-foreground/20 rounded-full"
          animate={{ rotateZ: -360 }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        />
        
        <div className="container-narrow text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
              Ready to Build Your Perfect Resume?
            </h2>
            <p className="text-lg text-primary-foreground/80 mb-8 max-w-xl mx-auto">
              Join thousands of job seekers who landed their dream jobs with our free resume builder.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/editor">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-background text-foreground hover:bg-background/90 text-lg px-8 py-6">
                    Create Your Resume
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
              </Link>
              <Link to="/templates">
                <Button variant="outline" className="border-2 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 text-lg px-8 py-6">
                  Browse Templates
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
