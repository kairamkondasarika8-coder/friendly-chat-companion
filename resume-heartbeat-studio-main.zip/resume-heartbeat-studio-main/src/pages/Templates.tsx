import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Sparkles, Grid3X3, Users, GraduationCap, Briefcase, Star, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import TemplatePreview from "@/components/templates/TemplatePreview";
import RoleSearchBar from "@/components/templates/RoleSearchBar";
import HorizontalTemplateScroll from "@/components/templates/HorizontalTemplateScroll";
import SkillSuggestionPanel from "@/components/templates/SkillSuggestionPanel";
import TemplateFilterSidebar, { type FilterState } from "@/components/templates/TemplateFilterSidebar";
import TemplateCarousel from "@/components/templates/TemplateCarousel";
import Background3DElements from "@/components/3d/Background3DElements";
import { templates } from "@/data/templates";
import { useResumeStore } from "@/stores/resumeStore";
import type { RoleData } from "@/data/industryData";
import { Badge } from "@/components/ui/badge";

const occupationToIndustry: Record<string, string[]> = {
  'Management & Executive': ['Executive', 'Business', 'Corporate'],
  'Business & Finance': ['Finance', 'Business', 'Corporate'],
  'Retail & Sales': ['Sales', 'Business'],
  'Healthcare & Medical': ['Healthcare'],
  'Computer & Technology': ['Technology', 'Tech', 'Startup'],
  'Education & Library': ['Academic'],
  'Arts & Entertainment': ['Art', 'Animation', 'Creative', 'Design', 'Content'],
  'Architecture & Engineering': ['Engineering'],
  'Science': ['Science'],
  'Legal': ['Legal'],
  'Construction & Trade': ['Engineering'],
  'Food & Beverage': ['General'],
  'Transportation': ['General'],
  'Manufacturing & Production': ['General'],
  'Personal Care & Service': ['General'],
  'Community & Social Service': ['General'],
  'Public Safety': ['General'],
  'Agriculture & Natural Resources': ['General'],
  'Military': ['General'],
  'Office & Administrative Support': ['Corporate', 'General'],
};

const Templates = () => {
  const [selectedRole, setSelectedRole] = useState<RoleData | null>(null);
  const [viewMode, setViewMode] = useState<'role' | 'all'>('role');
  const [filters, setFilters] = useState<FilterState>({ headshot: [], columns: [], style: [], occupation: [] });
  const navigate = useNavigate();
  const { setSelectedTemplate, resumeData } = useResumeStore();

  const filteredTemplates = templates.filter((template) => {
    // Headshot filter
    if (filters.headshot.length > 0) {
      const hasPhoto = template.hasPhoto;
      if (filters.headshot.includes('with-photo') && !hasPhoto) return false;
      if (filters.headshot.includes('without-photo') && hasPhoto) return false;
    }
    // Columns filter
    if (filters.columns.length > 0) {
      const isSidebar = template.layout === 'sidebar-left' || template.layout === 'sidebar-right';
      const match = 
        (filters.columns.includes('one-column') && template.layout === 'one-column') ||
        (filters.columns.includes('two-column') && template.layout === 'two-column') ||
        (filters.columns.includes('sidebar') && isSidebar);
      if (!match) return false;
    }
    // Style filter
    if (filters.style.length > 0) {
      if (!filters.style.includes(template.category)) return false;
    }
    // Occupation filter
    if (filters.occupation.length > 0) {
      const matchingIndustries = filters.occupation.flatMap(occ => occupationToIndustry[occ] || []);
      if (!matchingIndustries.some(ind => template.industry?.toLowerCase().includes(ind.toLowerCase()))) return false;
    }
    return true;
  });

  const handleSelectTemplate = (templateId: string, color?: string) => {
    setSelectedTemplate(templateId);
    navigate("/editor");
  };

  const handleRoleSelect = (role: RoleData | null) => {
    setSelectedRole(role);
    if (role) setViewMode('role');
  };

  const hasActiveFilters = filters.headshot.length > 0 || filters.columns.length > 0 || filters.style.length > 0 || filters.occupation.length > 0;

  return (
    <div className="min-h-screen bg-background relative">
      <Background3DElements variant="subtle" />
      <Header />
      
      <main className="pt-24 md:pt-32 pb-16">
        <div className="container-wide">
          {/* Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-4">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">100+ Professional Templates</span>
            </div>
            <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Find the <span className="text-gradient">Perfect Resume</span> for Your Role
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Search by job role to get customized templates with realistic content, 
              industry-specific layouts, and AI-powered skill suggestions.
            </p>
            <div className="flex justify-center gap-8 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-foreground">100+</div>
                <div className="text-xs text-muted-foreground">Templates</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-foreground">50+</div>
                <div className="text-xs text-muted-foreground">Job Roles</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-foreground">16</div>
                <div className="text-xs text-muted-foreground">Industries</div>
              </div>
            </div>
          </motion.div>

          {/* Role Search Bar */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="flex justify-center mb-8">
            <RoleSearchBar onRoleSelect={handleRoleSelect} selectedRole={selectedRole} />
          </motion.div>

          {/* View Toggle */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="flex items-center justify-center gap-2 mb-8">
            <Button variant={viewMode === 'role' ? 'default' : 'outline'} size="sm" onClick={() => setViewMode('role')} className="gap-2">
              <Sparkles className="w-4 h-4" />Role-Based Search
            </Button>
            <Button variant={viewMode === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setViewMode('all')} className="gap-2">
              <Grid3X3 className="w-4 h-4" />Browse All Templates
            </Button>
          </motion.div>

          {/* Role-Based View */}
          {viewMode === 'role' && selectedRole && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="space-y-8">
              <div className="flex flex-col lg:flex-row gap-6">
                <div className="flex-1 space-y-8">
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-2xl p-6 border">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 bg-primary/20 rounded-xl flex items-center justify-center">
                        <Award className="w-7 h-7 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h2 className="text-2xl font-bold text-foreground mb-1">{selectedRole.title} Templates</h2>
                        <p className="text-muted-foreground text-sm mb-4">
                          Professional resumes designed specifically for {selectedRole.title} roles. All templates are ATS-optimized.
                        </p>
                        <div className="flex flex-wrap gap-3">
                          <div className="flex items-center gap-1.5 text-xs bg-background/80 px-3 py-1.5 rounded-full border">
                            <Award className="w-3.5 h-3.5 text-primary" /><span>ATS-Friendly</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-xs bg-background/80 px-3 py-1.5 rounded-full border">
                            <Users className="w-3.5 h-3.5 text-primary" /><span>{selectedRole.experienceLevels.length} Levels</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-xs bg-background/80 px-3 py-1.5 rounded-full border">
                            <Briefcase className="w-3.5 h-3.5 text-primary" /><span>{selectedRole.industry}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {selectedRole.experienceLevels.map((level, index) => (
                    <motion.div key={level} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + index * 0.1 }}>
                      <HorizontalTemplateScroll role={selectedRole} level={level} onSelectTemplate={handleSelectTemplate} selectedTemplateId={resumeData.selectedTemplate} />
                    </motion.div>
                  ))}
                </div>
                <div className="lg:w-[320px] flex-shrink-0">
                  <div className="lg:sticky lg:top-24">
                    <SkillSuggestionPanel role={selectedRole} />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* No Role Selected */}
          {viewMode === 'role' && !selectedRole && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-16">
              <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Search for Your Dream Role</h3>
              <p className="text-muted-foreground max-w-md mx-auto mb-6">
                Enter a job title like "Data Scientist", "Software Engineer", or "Marketing Manager" to get personalized templates.
              </p>
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                {['Data Scientist', 'Frontend Developer', 'Product Manager', 'Nurse', 'Teacher'].map((r) => (
                  <Badge key={r} variant="outline" className="cursor-pointer hover:bg-primary/10">{r}</Badge>
                ))}
              </div>
              <Button variant="outline" onClick={() => setViewMode('all')} className="gap-2">
                <Grid3X3 className="w-4 h-4" />Browse All Templates Instead
              </Button>
            </motion.div>
          )}

          {/* Browse All View with Sidebar Filters + Horizontal Carousel */}
          {viewMode === 'all' && (
            <div className="flex gap-6">
              {/* Left Sidebar Filters */}
              <div className="hidden lg:block w-[260px] flex-shrink-0">
                <TemplateFilterSidebar filters={filters} onFiltersChange={setFilters} />
              </div>

              {/* Main Content */}
              <div className="flex-1 min-w-0">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Showing {filteredTemplates.length} of {templates.length} templates
                  </span>
                  {hasActiveFilters && (
                    <Button variant="ghost" size="sm" onClick={() => setFilters({ headshot: [], columns: [], style: [], occupation: [] })} className="text-xs">
                      Clear all filters
                    </Button>
                  )}
                </div>

                {/* Horizontal Sliding Carousel */}
                <TemplateCarousel
                  filteredTemplates={filteredTemplates}
                  selectedTemplateId={resumeData.selectedTemplate}
                  onSelectTemplate={handleSelectTemplate}
                />

                {filteredTemplates.length === 0 && (
                  <div className="text-center py-16">
                    <p className="text-lg text-muted-foreground mb-4">No templates found matching your criteria.</p>
                    <Button variant="outline" onClick={() => setFilters({ headshot: [], columns: [], style: [], occupation: [] })}>
                      Clear Filters
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Templates;
