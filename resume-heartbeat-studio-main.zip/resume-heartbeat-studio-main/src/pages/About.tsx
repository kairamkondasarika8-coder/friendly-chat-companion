import { motion } from "framer-motion";
import { Heart, Target, Users, Award, Shield, Zap, Mail, Phone, MapPin, Github, Linkedin } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import FloatingShapes from "@/components/3d/FloatingShapes";
import Background3DElements from "@/components/3d/Background3DElements";
import Tilt3DCard from "@/components/3d/Tilt3DCard";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "User-First Approach",
      description: "Every feature we build starts with your success in mind. We're here to help you land your dream job.",
    },
    {
      icon: Shield,
      title: "100% Free Forever",
      description: "We believe everyone deserves access to professional resume tools, regardless of their financial situation.",
    },
    {
      icon: Zap,
      title: "Simplicity",
      description: "Creating a resume shouldn't be complicated. We've made it as easy as filling out a simple form.",
    },
    {
      icon: Target,
      title: "ATS Optimization",
      description: "Our templates are designed to pass Applicant Tracking Systems, giving you the best chance at getting noticed.",
    },
  ];

  const founder = {
    name: "Omkari Kasula",
    role: "Founder & Developer",
    initials: "OK",
    email: "omkarikasula@gmail.com",
    phone: "+91 93465 28513",
    location: "Hyderabad, Telangana, India",
    bio: "Passionate developer and creator of this resume builder. Dedicated to helping job seekers create professional, ATS-friendly resumes that land interviews.",
  };

  return (
    <div className="min-h-screen bg-background relative">
      <Background3DElements variant="subtle" />
      <Header />
      
      <main className="pt-24 md:pt-32">
        {/* Hero Section */}
        <section className="section-padding bg-gradient-hero relative overflow-hidden">
          <FloatingShapes />
          <div className="container-narrow text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
                Helping You Land Your{" "}
                <span className="text-gradient">Dream Job</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We built ResumePro because we believe everyone deserves access to professional tools 
                that can transform their career. Our mission is simple: make job hunting easier for everyone.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="section-padding">
          <div className="container-wide">
            <div className="grid md:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="card-elevated rounded-2xl p-8"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                  <Target className="w-7 h-7 text-primary" />
                </div>
                <h2 className="font-display text-2xl font-bold text-foreground mb-4">
                  Our Mission
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  To democratize access to professional resume-building tools. We want to eliminate the 
                  barriers that prevent talented individuals from showcasing their skills effectively. 
                  Whether you're a recent graduate or a seasoned professional, you deserve a resume 
                  that represents you at your best.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="card-elevated rounded-2xl p-8"
              >
                <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center mb-6">
                  <Award className="w-7 h-7 text-accent" />
                </div>
                <h2 className="font-display text-2xl font-bold text-foreground mb-4">
                  Our Vision
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  A world where job seekers can focus on what matters—preparing for interviews and 
                  growing their careers—without stressing over resume formatting or ATS compatibility. 
                  We envision a future where your skills and experience speak louder than design limitations.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section className="section-padding bg-muted/50">
          <div className="container-wide">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                What Makes Us <span className="text-gradient">Different</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Our values guide everything we do, from product decisions to how we support our users.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Tilt3DCard
                    className="card-elevated rounded-2xl p-6 text-center h-full"
                    maxTilt={8}
                    scale={1.03}
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <value.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                      {value.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {value.description}
                    </p>
                  </Tilt3DCard>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Founder Section */}
        <section className="section-padding">
          <div className="container-wide">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                Meet the <span className="text-gradient">Creator</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The passionate developer behind this free resume builder.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-2xl mx-auto"
            >
              <div className="card-elevated rounded-3xl p-8 md:p-10 text-center">
                <motion.div 
                  className="w-32 h-32 rounded-full bg-gradient-primary flex items-center justify-center mx-auto mb-6 text-primary-foreground font-display text-4xl font-bold shadow-glow"
                  animate={{ 
                    rotateY: [0, 10, 0, -10, 0],
                    scale: [1, 1.02, 1]
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                >
                  {founder.initials}
                </motion.div>
                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  {founder.name}
                </h3>
                <p className="text-lg text-primary font-medium mb-4">{founder.role}</p>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {founder.bio}
                </p>
                
                <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                  <a 
                    href={`mailto:${founder.email}`}
                    className="flex items-center gap-2 hover:text-primary transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    {founder.email}
                  </a>
                  <span className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    {founder.phone}
                  </span>
                  <span className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {founder.location}
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="section-padding bg-gradient-primary">
          <div className="container-wide">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { value: "100K+", label: "Resumes Created" },
                { value: "50+", label: "Templates" },
                { value: "98%", label: "ATS Pass Rate" },
                { value: "4.9★", label: "User Rating" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="font-display text-4xl md:text-5xl font-bold text-primary-foreground mb-2">
                    {stat.value}
                  </div>
                  <div className="text-primary-foreground/80">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
