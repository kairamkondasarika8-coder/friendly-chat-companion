import { useMemo } from "react";
import { motion } from "framer-motion";
import { Sparkles, Award, Users, GraduationCap, Briefcase, Star } from "lucide-react";
import { templates, atsColors, type Template } from "@/data/templates";
import { type RoleData, getIndustryById, industries } from "@/data/industryData";
import TemplatePreview from "./TemplatePreview";

interface RoleTemplateGeneratorProps {
  role: RoleData;
  onSelectTemplate: (templateId: string, color?: string) => void;
  selectedTemplateId?: string;
}

interface GeneratedTemplate extends Template {
  roleRelevance: 'high' | 'medium';
  experienceLevel: 'fresher' | 'intermediate' | 'experienced';
  customSections: string[];
  suggestedColor: string;
}

const RoleTemplateGenerator = ({ 
  role, 
  onSelectTemplate,
  selectedTemplateId 
}: RoleTemplateGeneratorProps) => {
  
  // Generate role-specific templates
  const generatedTemplates = useMemo(() => {
    const results: GeneratedTemplate[] = [];
    
    // Get industry info for layout preferences
    const industry = industries.find(i => 
      i.roles.includes(role.id) || 
      i.name.toLowerCase().includes(role.industry.toLowerCase())
    );
    
    const preferredLayout = industry?.layoutPreference || 'two-column';
    const industryColors = industry?.primaryColors || [atsColors.navy, atsColors.teal];
    
    // Filter and enhance templates based on role
    templates.forEach((template) => {
      // Determine relevance score
      let relevanceScore = 0;
      
      // Layout match
      if (template.layout === preferredLayout) relevanceScore += 3;
      if (template.layout.includes('column')) relevanceScore += 1;
      
      // Industry match
      if (template.industry?.toLowerCase().includes(role.industry.toLowerCase())) {
        relevanceScore += 5;
      }
      
      // Category match based on role category
      if (role.category === 'creative' && template.category === 'creative') {
        relevanceScore += 4;
      } else if (role.category === 'technical' && (template.category === 'modern' || template.category === 'professional')) {
        relevanceScore += 3;
      } else if (role.category === 'business' && (template.category === 'professional' || template.category === 'classic')) {
        relevanceScore += 3;
      } else if (role.category === 'healthcare' && (template.category === 'classic' || template.category === 'professional')) {
        relevanceScore += 3;
      } else if (role.category === 'education' && template.category === 'classic') {
        relevanceScore += 3;
      } else if (role.category === 'legal' && template.category === 'classic') {
        relevanceScore += 4;
      }
      
      // Photo preference based on role
      const rolesWithPhoto = ['ui-designer', 'ux-designer', 'graphic-designer', 'hotel-manager', 'chef', 'aviation-crew'];
      const rolesWithoutPhoto = ['software-engineer', 'data-scientist', 'lawyer', 'chartered-accountant', 'government-job-aspirant'];
      
      if (rolesWithPhoto.includes(role.id) && template.hasPhoto) {
        relevanceScore += 2;
      } else if (rolesWithoutPhoto.includes(role.id) && !template.hasPhoto) {
        relevanceScore += 2;
      }
      
      if (relevanceScore >= 3) {
        // Create variants for each experience level
        role.experienceLevels.forEach((level) => {
          const suggestedColor = industryColors[results.length % industryColors.length] || template.defaultColor;
          
          results.push({
            ...template,
            id: `${template.id}-${role.id}-${level}`,
            name: `${template.name} - ${level.charAt(0).toUpperCase() + level.slice(1)}`,
            roleRelevance: relevanceScore >= 5 ? 'high' : 'medium',
            experienceLevel: level,
            customSections: role.sections.order,
            suggestedColor,
            description: `Optimized for ${role.title} (${level.charAt(0).toUpperCase() + level.slice(1)} level) - ${template.description}`,
          });
        });
      }
    });
    
    // Sort by relevance
    return results.sort((a, b) => {
      if (a.roleRelevance === 'high' && b.roleRelevance !== 'high') return -1;
      if (b.roleRelevance === 'high' && a.roleRelevance !== 'high') return 1;
      return 0;
    });
  }, [role]);

  // Group by experience level
  const groupedByLevel = useMemo(() => {
    const groups: Record<string, GeneratedTemplate[]> = {
      fresher: [],
      intermediate: [],
      experienced: [],
    };
    
    generatedTemplates.forEach((template) => {
      if (groups[template.experienceLevel]) {
        groups[template.experienceLevel].push(template);
      }
    });
    
    return groups;
  }, [generatedTemplates]);

  const levelIcons = {
    fresher: GraduationCap,
    intermediate: Briefcase,
    experienced: Star,
  };

  const levelLabels = {
    fresher: "Entry Level / Fresher",
    intermediate: "Mid-Level / Intermediate",
    experienced: "Senior / Experienced",
  };

  return (
    <div className="space-y-8">
      {/* Role Summary Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-2xl p-6 border"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-foreground mb-1">
              Templates for {role.title}
            </h2>
            <p className="text-muted-foreground text-sm mb-4">
              {generatedTemplates.length} customized templates with industry-specific sections, 
              keywords, and layouts optimized for {role.industry} hiring standards.
            </p>
            
            {/* Key Features */}
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-1.5 text-xs bg-background/80 px-2.5 py-1.5 rounded-full">
                <Award className="w-3.5 h-3.5 text-primary" />
                <span>ATS Optimized</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs bg-background/80 px-2.5 py-1.5 rounded-full">
                <Users className="w-3.5 h-3.5 text-primary" />
                <span>{role.experienceLevels.length} Experience Levels</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs bg-background/80 px-2.5 py-1.5 rounded-full">
                <Briefcase className="w-3.5 h-3.5 text-primary" />
                <span>{role.industry} Industry</span>
              </div>
            </div>
          </div>
        </div>

        {/* Skills & Keywords Preview */}
        <div className="mt-4 pt-4 border-t border-primary/10">
          <div className="text-xs font-medium text-muted-foreground mb-2">Key Skills Highlighted:</div>
          <div className="flex flex-wrap gap-1.5">
            {role.skills.technical.slice(0, 6).map((skill) => (
              <span key={skill} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">
                {skill}
              </span>
            ))}
            {role.skills.tools.slice(0, 4).map((tool) => (
              <span key={tool} className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded">
                {tool}
              </span>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Templates by Experience Level */}
      {Object.entries(groupedByLevel).map(([level, levelTemplates]) => {
        if (levelTemplates.length === 0) return null;
        
        const LevelIcon = levelIcons[level as keyof typeof levelIcons];
        
        return (
          <motion.div
            key={level}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-muted rounded-lg flex items-center justify-center">
                <LevelIcon className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">
                  {levelLabels[level as keyof typeof levelLabels]}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {levelTemplates.length} templates
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {levelTemplates.slice(0, 10).map((template, index) => (
                <motion.div
                  key={template.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                >
                  <TemplatePreview
                    template={{
                      ...template,
                      id: template.id.split('-')[0] + '-' + template.id.split('-')[1], // Use original template id for rendering
                    }}
                    index={index}
                    isSelected={selectedTemplateId === template.id}
                    onSelect={() => onSelectTemplate(template.id.split('-')[0] + '-' + template.id.split('-')[1], template.suggestedColor)}
                    roleData={role}
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default RoleTemplateGenerator;
