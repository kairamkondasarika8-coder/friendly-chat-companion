import { useState, useRef, useEffect } from "react";
import { Search, Briefcase, X, TrendingUp } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { searchRoles, getPopularRoles, industries, type RoleData } from "@/data/industryData";
import Tilt3DCard from "@/components/3d/Tilt3DCard";

interface RoleSearchBarProps {
  onRoleSelect: (role: RoleData | null) => void;
  selectedRole: RoleData | null;
}

const RoleSearchBar = ({ onRoleSelect, selectedRole }: RoleSearchBarProps) => {
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [suggestions, setSuggestions] = useState<RoleData[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (query.trim()) {
      const results = searchRoles(query);
      setSuggestions(results.slice(0, 8));
    } else {
      setSuggestions(getPopularRoles());
    }
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelectRole = (role: RoleData) => {
    onRoleSelect(role);
    setQuery(role.title);
    setIsFocused(false);
  };

  const handleClear = () => {
    onRoleSelect(null);
    setQuery("");
    inputRef.current?.focus();
  };

  const getIndustryIcon = (industryName: string) => {
    const industry = industries.find(i => 
      i.name.toLowerCase().includes(industryName.toLowerCase()) ||
      industryName.toLowerCase().includes(i.name.toLowerCase().split(' ')[0])
    );
    return industry?.icon || "💼";
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-2xl">
      <Tilt3DCard
        className="w-full rounded-xl"
        maxTilt={3}
        scale={1.01}
        glareEnabled={false}
      >
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search by job role (e.g., Data Scientist, UI Designer, Nurse...)"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            className="pl-12 pr-12 h-14 text-base border-2 focus:border-primary bg-background/80 backdrop-blur-sm"
          />
          {(query || selectedRole) && (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClear}
              className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </Tilt3DCard>

      {/* Selected Role Badge */}
      {selectedRole && !isFocused && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 flex items-center gap-2"
        >
          <span className="text-sm text-muted-foreground">Showing templates for:</span>
          <span className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
            <span>{getIndustryIcon(selectedRole.industry)}</span>
            {selectedRole.title}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClear}
              className="h-4 w-4 p-0 hover:bg-transparent"
            >
              <X className="w-3 h-3" />
            </Button>
          </span>
        </motion.div>
      )}

      {/* Suggestions Dropdown */}
      <AnimatePresence>
        {isFocused && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 w-full mt-2 bg-background border-2 rounded-xl shadow-xl overflow-hidden"
          >
            {/* Header */}
            <div className="px-4 py-3 bg-muted/50 border-b flex items-center gap-2">
              {query.trim() ? (
                <>
                  <Briefcase className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">
                    {suggestions.length > 0 ? `Found ${suggestions.length} roles` : "No matching roles"}
                  </span>
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">Popular Roles</span>
                </>
              )}
            </div>

            {/* Suggestions List */}
            <div className="max-h-80 overflow-y-auto">
              {suggestions.length > 0 ? (
                suggestions.map((role) => (
                  <button
                    key={role.id}
                    onClick={() => handleSelectRole(role)}
                    className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left group"
                  >
                    <span className="text-lg">{getIndustryIcon(role.industry)}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-foreground group-hover:text-primary transition-colors">
                        {role.title}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {role.industry} • {role.experienceLevels.map(l => l.charAt(0).toUpperCase() + l.slice(1)).join(", ")}
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                      {role.category}
                    </span>
                  </button>
                ))
              ) : (
                <div className="px-4 py-8 text-center text-muted-foreground">
                  <Briefcase className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No roles found for "{query}"</p>
                  <p className="text-xs mt-1">Try a different search term</p>
                </div>
              )}
            </div>

            {/* Browse by Industry */}
            {!query.trim() && (
              <div className="px-4 py-3 bg-muted/30 border-t">
                <div className="text-xs text-muted-foreground mb-2">Browse by Industry</div>
                <div className="flex flex-wrap gap-1.5">
                  {industries.slice(0, 8).map((industry) => (
                    <button
                      key={industry.id}
                      onClick={() => setQuery(industry.name.split(' ')[0])}
                      className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-background hover:bg-primary/10 rounded-md transition-colors"
                    >
                      {industry.icon} {industry.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default RoleSearchBar;
