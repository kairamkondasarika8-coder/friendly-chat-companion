import { useRef, useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { type RoleData } from "@/data/industryData";
import { templates, type Template } from "@/data/templates";
import RoleTemplateCard from "./RoleTemplateCard";

interface HorizontalTemplateScrollProps {
  role: RoleData;
  level: 'fresher' | 'intermediate' | 'experienced';
  onSelectTemplate: (templateId: string, color?: string) => void;
  selectedTemplateId?: string;
}

const HorizontalTemplateScroll = ({
  role,
  level,
  onSelectTemplate,
  selectedTemplateId
}: HorizontalTemplateScrollProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Filter templates based on role
  const filteredTemplates = templates.filter(template => {
    // Match by industry or category
    const industryMatch = template.industry?.toLowerCase().includes(role.industry.toLowerCase());
    const categoryMatch = 
      (role.category === 'technical' && ['modern', 'professional'].includes(template.category)) ||
      (role.category === 'creative' && ['creative', 'modern'].includes(template.category)) ||
      (role.category === 'business' && ['professional', 'classic'].includes(template.category)) ||
      (role.category === 'healthcare' && ['classic', 'professional'].includes(template.category)) ||
      (role.category === 'legal' && ['classic', 'minimal'].includes(template.category)) ||
      (role.category === 'education' && ['classic', 'minimal'].includes(template.category));
    
    return industryMatch || categoryMatch || template.category === 'professional';
  });

  // Ensure we always have at least 10 templates
  const displayTemplates = filteredTemplates.length >= 10 
    ? filteredTemplates 
    : [...filteredTemplates, ...templates.filter(t => !filteredTemplates.includes(t))].slice(0, 15);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const element = scrollRef.current;
    if (element) {
      element.addEventListener('scroll', checkScroll);
      return () => element.removeEventListener('scroll', checkScroll);
    }
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320; // Card width + gap
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const levelLabels = {
    fresher: 'Entry Level',
    intermediate: 'Mid-Level',
    experienced: 'Senior Level'
  };

  return (
    <div className="relative group">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground">{levelLabels[level]}</h3>
          <span className="text-xs text-muted-foreground">
            {displayTemplates.length} templates
          </span>
        </div>
        
        {/* Navigation Arrows */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            className={`h-8 w-8 rounded-full transition-opacity ${
              canScrollLeft ? 'opacity-100' : 'opacity-30 cursor-not-allowed'
            }`}
            onClick={() => scroll('left')}
            disabled={!canScrollLeft}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className={`h-8 w-8 rounded-full transition-opacity ${
              canScrollRight ? 'opacity-100' : 'opacity-30 cursor-not-allowed'
            }`}
            onClick={() => scroll('right')}
            disabled={!canScrollRight}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Scrollable Container */}
      <div className="relative">
        {/* Gradient Overlays */}
        <div className={`absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none transition-opacity ${canScrollLeft ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none transition-opacity ${canScrollRight ? 'opacity-100' : 'opacity-0'}`} />

        {/* Scrollable Area */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-4 px-1"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {displayTemplates.map((template, index) => (
            <motion.div
              key={`${template.id}-${level}-${index}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.03 }}
              className="flex-shrink-0 w-[220px]"
            >
              <RoleTemplateCard
                template={template}
                role={role}
                level={level}
                isSelected={selectedTemplateId === template.id}
                onSelect={() => onSelectTemplate(template.id, template.defaultColor)}
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Mobile Swipe Hint */}
      <div className="text-center text-xs text-muted-foreground mt-2 md:hidden">
        Swipe to see more templates →
      </div>
    </div>
  );
};

export default HorizontalTemplateScroll;
