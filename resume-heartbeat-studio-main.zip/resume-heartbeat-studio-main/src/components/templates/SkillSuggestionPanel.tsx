import { motion } from "framer-motion";
import { Sparkles, CheckCircle, Star, Zap, BookOpen, Wrench } from "lucide-react";
import { type RoleData } from "@/data/industryData";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface SkillSuggestionPanelProps {
  role: RoleData;
}

const SkillSuggestionPanel = ({ role }: SkillSuggestionPanelProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="bg-gradient-to-br from-card via-card to-primary/5 rounded-2xl border shadow-lg overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/20 to-primary/10 px-5 py-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">AI Skill Suggestions</h3>
            <p className="text-xs text-muted-foreground">Recommended for {role.title}</p>
          </div>
        </div>
      </div>

      <ScrollArea className="h-[400px]">
        <div className="p-5 space-y-6">
          {/* Required Technical Skills */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <h4 className="font-medium text-sm text-foreground">Required Skills</h4>
              <Badge variant="secondary" className="text-xs">Must Have</Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {role.skills.technical.slice(0, 8).map((skill, index) => (
                <motion.span
                  key={skill}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-medium border border-emerald-500/20"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  {skill}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Recommended Tools */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Wrench className="w-4 h-4 text-blue-500" />
              <h4 className="font-medium text-sm text-foreground">Recommended Tools</h4>
              <Badge variant="secondary" className="text-xs">Industry Standard</Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {role.skills.tools.slice(0, 10).map((tool, index) => (
                <motion.span
                  key={tool}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + index * 0.05 }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 text-blue-700 dark:text-blue-400 rounded-full text-xs font-medium border border-blue-500/20"
                >
                  <Zap className="w-3 h-3" />
                  {tool}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-4 h-4 text-amber-500" />
              <h4 className="font-medium text-sm text-foreground">Soft Skills</h4>
              <Badge variant="secondary" className="text-xs">Stand Out</Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {role.skills.soft.map((skill, index) => (
                <motion.span
                  key={skill}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 text-amber-700 dark:text-amber-400 rounded-full text-xs font-medium border border-amber-500/20"
                >
                  {skill}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Certifications */}
          {role.skills.certifications.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="w-4 h-4 text-purple-500" />
                <h4 className="font-medium text-sm text-foreground">Certifications</h4>
                <Badge variant="secondary" className="text-xs">Bonus Points</Badge>
              </div>
              <div className="space-y-2">
                {role.skills.certifications.slice(0, 5).map((cert, index) => (
                  <motion.div
                    key={cert}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="flex items-center gap-2 p-2.5 bg-purple-500/5 rounded-lg border border-purple-500/10"
                  >
                    <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-xs text-purple-600 dark:text-purple-400 font-medium">
                      {index + 1}
                    </div>
                    <span className="text-xs text-foreground">{cert}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* ATS Keywords */}
          <div className="pt-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-medium text-muted-foreground">🎯 ATS Keywords to Include</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {role.keywords.slice(0, 12).map((keyword, index) => (
                <span
                  key={keyword}
                  className="px-2 py-1 bg-muted text-muted-foreground rounded text-[10px]"
                >
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>
    </motion.div>
  );
};

export default SkillSuggestionPanel;
