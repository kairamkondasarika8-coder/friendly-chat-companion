import { useState } from "react";
import { Template, colorOptions } from "@/data/templates";
import { sampleResumeData, samplePersonas } from "@/data/sampleResumeData";
import Tilt3DCard from "@/components/3d/Tilt3DCard";
import { Crown, Sparkles, Check, Camera, Columns, AlignLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import type { RoleData } from "@/data/industryData";

interface TemplatePreviewProps {
  template: Template;
  index: number;
  isSelected: boolean;
  onSelect: (templateId: string, color?: string) => void;
  roleData?: RoleData;
}

const TemplatePreview = ({
  template,
  index,
  isSelected,
  onSelect,
  roleData,
}: TemplatePreviewProps) => {
  const [selectedColor, setSelectedColor] = useState(template.defaultColor);
  const [isHovered, setIsHovered] = useState(false);

  // Use different sample data based on template index for variety
  // If roleData is provided, use it to customize the preview
  const persona = samplePersonas[index % samplePersonas.length];
  const sample = {
    ...sampleResumeData,
    name: roleData ? persona.name : persona.name,
    title: roleData ? roleData.title : persona.title,
    summary: roleData ? `Experienced ${roleData.title} with expertise in ${roleData.skills.technical.slice(0, 3).join(', ')}. ${roleData.achievementFormats[0]?.replace('X', '25').replace('Y', '15').replace('Z', '30') || persona.summary}` : persona.summary,
    skills: roleData 
      ? { 
          "Technical": roleData.skills.technical.slice(0, 4).join(', '),
          "Tools": roleData.skills.tools.slice(0, 4).join(', '),
        }
      : persona.skills,
  };

  const accentColor = selectedColor;

  // Layout booleans
  const isSidebarLeft = template.layout === "sidebar-left";
  const isSidebarRight = template.layout === "sidebar-right";
  const isTwoColumn = template.layout === "two-column";
  const isOneColumn = template.layout === "one-column";
  const hasSidebar = isSidebarLeft || isSidebarRight;

  // Render sidebar content
  const renderSidebar = () => (
    <div 
      className="h-full p-2 text-white flex flex-col"
      style={{ backgroundColor: accentColor, width: '35%' }}
    >
      {/* Photo */}
      {template.hasPhoto && (
        <div className="mb-2 flex justify-center">
          <div className="w-10 h-10 rounded-full bg-white/20 border-2 border-white/40 flex items-center justify-center">
            <span className="text-[8px] font-bold text-white/90">
              {sample.name.split(' ').map(n => n[0]).join('')}
            </span>
          </div>
        </div>
      )}
      
      {/* Contact */}
      <div className="mb-2">
        <h3 className="text-[5px] font-bold uppercase tracking-wider mb-1 opacity-80 border-b border-white/30 pb-0.5">Contact</h3>
        <div className="space-y-0.5 text-[4px]">
          <p className="opacity-90 truncate">{sample.email}</p>
          <p className="opacity-90">{sample.phone}</p>
          <p className="opacity-90">{sample.location}</p>
        </div>
      </div>
      
      {/* Skills */}
      <div className="mb-2">
        <h3 className="text-[5px] font-bold uppercase tracking-wider mb-1 opacity-80 border-b border-white/30 pb-0.5">Skills</h3>
        <div className="space-y-0.5">
          {Object.values(sample.skills).slice(0, 2).map((skillSet, i) => (
            <p key={i} className="text-[4px] opacity-80">{skillSet.slice(0, 30)}...</p>
          ))}
        </div>
      </div>
      
      {/* Education */}
      <div>
        <h3 className="text-[5px] font-bold uppercase tracking-wider mb-1 opacity-80 border-b border-white/30 pb-0.5">Education</h3>
        {sample.education.map((edu, i) => (
          <div key={i}>
            <p className="text-[4px] font-semibold opacity-90">{edu.degree}</p>
            <p className="text-[3.5px] opacity-70">{edu.school}</p>
          </div>
        ))}
      </div>
    </div>
  );

  // Render main content
  const renderMainContent = (fullWidth = false) => (
    <div className={`${fullWidth ? 'w-full' : 'flex-1'} p-2 bg-white flex flex-col`}>
      {/* Header with photo for non-sidebar layouts */}
      <div className={`mb-1.5 border-b pb-1 ${template.hasPhoto && !hasSidebar ? 'flex items-center gap-2' : ''}`} style={{ borderColor: accentColor }}>
        {template.hasPhoto && !hasSidebar && (
          <div 
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[6px] font-bold flex-shrink-0"
            style={{ backgroundColor: accentColor }}
          >
            {sample.name.split(' ').map(n => n[0]).join('')}
          </div>
        )}
        <div>
          <h1 
            className="font-bold uppercase tracking-wide"
            style={{ color: accentColor, fontSize: isTwoColumn ? '9px' : '10px' }}
          >
            {sample.name}
          </h1>
          <p className="text-gray-600" style={{ fontSize: '5px' }}>{sample.title}</p>
          {(isOneColumn || isTwoColumn) && !hasSidebar && (
            <div className="flex gap-1.5 text-gray-500 mt-0.5" style={{ fontSize: '3.5px' }}>
              <span>{sample.email}</span>
              <span>•</span>
              <span>{sample.phone}</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Summary */}
      <div className="mb-1.5">
        <h2 
          className="font-bold uppercase mb-0.5 flex items-center gap-1"
          style={{ color: accentColor, fontSize: '5px' }}
        >
          <span className="w-2 h-0.5" style={{ backgroundColor: accentColor }}></span>
          Summary
        </h2>
        <p className="text-gray-700" style={{ fontSize: '4px', lineHeight: 1.4 }}>
          {sample.summary.slice(0, 100)}...
        </p>
      </div>
      
      {/* Experience */}
      <div className="mb-1.5 flex-1">
        <h2 
          className="font-bold uppercase mb-0.5 flex items-center gap-1"
          style={{ color: accentColor, fontSize: '5px' }}
        >
          <span className="w-2 h-0.5" style={{ backgroundColor: accentColor }}></span>
          Experience
        </h2>
        {sample.experience.slice(0, hasSidebar ? 1 : 2).map((exp, i) => (
          <div key={i} className="mb-1 relative pl-1.5 border-l" style={{ borderColor: `${accentColor}40` }}>
            <div className="absolute -left-[2px] top-0 w-1 h-1 rounded-full" style={{ backgroundColor: accentColor }}></div>
            <div className="flex justify-between">
              <span className="font-bold text-gray-900" style={{ fontSize: '4.5px' }}>{exp.title}</span>
              <span className="text-gray-500" style={{ fontSize: '3.5px' }}>{exp.dates}</span>
            </div>
            <p className="text-gray-600" style={{ fontSize: '3.5px' }}>{exp.company}</p>
            <ul className="text-gray-700" style={{ fontSize: '3.5px' }}>
              {exp.bullets.slice(0, 2).map((bullet, j) => (
                <li key={j} className="flex gap-0.5">
                  <span>•</span>
                  <span>{bullet.slice(0, 40)}...</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      
      {/* Skills for non-sidebar layouts */}
      {!hasSidebar && (
        <div>
          <h2 
            className="font-bold uppercase mb-0.5 flex items-center gap-1"
            style={{ color: accentColor, fontSize: '5px' }}
          >
            <span className="w-2 h-0.5" style={{ backgroundColor: accentColor }}></span>
            Skills
          </h2>
          <div className="text-gray-700" style={{ fontSize: '3.5px' }}>
            {Object.entries(sample.skills).slice(0, 2).map(([category, skills]) => (
              <p key={category}>
                <span className="font-bold">{category}:</span> {skills.slice(0, 40)}...
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <Tilt3DCard
      className="group relative rounded-2xl overflow-hidden"
      maxTilt={6}
      scale={1.03}
    >
      <div 
        className="card-elevated rounded-2xl overflow-hidden"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Resume Preview */}
        <div
          className="aspect-[3/4] relative overflow-hidden"
          style={{ backgroundColor: "#f5f5f5" }}
        >
          <div className="absolute inset-2 bg-white rounded shadow-sm overflow-hidden">
            {/* Actual Resume Content - Full page */}
            <div className="h-full flex" style={{ fontFamily: "system-ui, sans-serif" }}>
              {isSidebarLeft && renderSidebar()}
              {renderMainContent(!hasSidebar)}
              {isSidebarRight && renderSidebar()}
              
              {/* Two Column Layout */}
              {isTwoColumn && !hasSidebar && (
                <div className="hidden"></div> // Handled by renderMainContent
              )}
            </div>
          </div>

          {/* Badges */}
          <div className="absolute top-2 left-2 flex gap-1">
            {template.popular && (
              <div className="bg-accent text-accent-foreground px-1.5 py-0.5 rounded-full text-[9px] font-semibold flex items-center gap-0.5 shadow-sm">
                <Crown className="w-2.5 h-2.5" />
                Popular
              </div>
            )}
            {template.new && (
              <div className="bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full text-[9px] font-semibold flex items-center gap-0.5 shadow-sm">
                <Sparkles className="w-2.5 h-2.5" />
                New
              </div>
            )}
          </div>

          {/* Layout & Photo Indicators */}
          <div className="absolute top-2 right-2 flex gap-1">
            {template.hasPhoto && (
              <div className="bg-white/90 backdrop-blur-sm px-1 py-0.5 rounded text-[8px] text-gray-600 flex items-center gap-0.5 shadow-sm">
                <Camera className="w-2 h-2" />
              </div>
            )}
            {(isTwoColumn || hasSidebar) && (
              <div className="bg-white/90 backdrop-blur-sm px-1 py-0.5 rounded text-[8px] text-gray-600 flex items-center gap-0.5 shadow-sm">
                <Columns className="w-2 h-2" />
              </div>
            )}
            {isOneColumn && (
              <div className="bg-white/90 backdrop-blur-sm px-1 py-0.5 rounded text-[8px] text-gray-600 flex items-center gap-0.5 shadow-sm">
                <AlignLeft className="w-2 h-2" />
              </div>
            )}
          </div>

          {/* Selected Indicator */}
          {isSelected && (
            <div className="absolute bottom-2 right-2 w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-sm">
              <Check className="w-3 h-3" />
            </div>
          )}

          {/* Hover Overlay with Color Picker */}
          <AnimatePresence>
            {isHovered && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center gap-3 p-4"
              >
                {/* Color Options */}
                <div className="flex flex-wrap gap-1.5 justify-center max-w-[120px]">
                  {template.colors.map((color) => (
                    <button
                      key={color}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedColor(color);
                      }}
                      className={`w-5 h-5 rounded-full border-2 transition-all hover:scale-110 ${
                        selectedColor === color ? 'border-white ring-2 ring-white/50' : 'border-white/50'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                
                <Button
                  onClick={() => onSelect(template.id, selectedColor)}
                  className="btn-primary transform transition-transform shadow-lg text-xs px-4 py-2"
                  size="sm"
                >
                  Use This Template
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Template Info */}
        <div className="p-3">
          <div className="flex items-center justify-between mb-0.5">
            <h3 className="font-display font-semibold text-foreground text-sm truncate">
              {template.name}
            </h3>
            <span
              className="text-[9px] px-1.5 py-0.5 rounded-full capitalize font-medium flex-shrink-0"
              style={{
                backgroundColor: `${selectedColor}15`,
                color: selectedColor,
              }}
            >
              {template.category}
            </span>
          </div>
          <p className="text-xs text-muted-foreground line-clamp-1">
            {template.description}
          </p>
          {template.industry && (
            <span className="text-[9px] text-muted-foreground">
              {template.industry}
            </span>
          )}
        </div>
      </div>
    </Tilt3DCard>
  );
};

export default TemplatePreview;
