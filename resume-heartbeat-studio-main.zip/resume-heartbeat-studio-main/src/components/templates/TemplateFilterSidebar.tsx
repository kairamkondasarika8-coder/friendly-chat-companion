import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, ChevronUp, X } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

interface FilterState {
  headshot: string[];
  columns: string[];
  style: string[];
  occupation: string[];
}

interface TemplateFilterSidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
}

const occupationCategories = [
  'Management & Executive',
  'Office & Administrative Support',
  'Business & Finance',
  'Retail & Sales',
  'Healthcare & Medical',
  'Food & Beverage',
  'Transportation',
  'Education & Library',
  'Computer & Technology',
  'Manufacturing & Production',
  'Construction & Trade',
  'Arts & Entertainment',
  'Architecture & Engineering',
  'Science',
  'Legal',
  'Agriculture & Natural Resources',
  'Public Safety',
  'Personal Care & Service',
  'Community & Social Service',
  'Military',
];

const TemplateFilterSidebar = ({ filters, onFiltersChange }: TemplateFilterSidebarProps) => {
  const [showAllOccupations, setShowAllOccupations] = useState(false);
  
  const displayedOccupations = showAllOccupations 
    ? occupationCategories 
    : occupationCategories.slice(0, 8);

  const hasActiveFilters = filters.headshot.length > 0 || filters.columns.length > 0 || filters.style.length > 0 || filters.occupation.length > 0;

  const toggleFilter = (category: keyof FilterState, value: string) => {
    const current = filters[category];
    const updated = current.includes(value)
      ? current.filter(v => v !== value)
      : [...current, value];
    onFiltersChange({ ...filters, [category]: updated });
  };

  const clearAll = () => {
    onFiltersChange({ headshot: [], columns: [], style: [], occupation: [] });
  };

  const FilterSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="mb-6">
      <h3 className="text-sm font-bold text-foreground mb-3">{title}</h3>
      {children}
    </div>
  );

  const FilterCheckbox = ({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) => (
    <label className="flex items-center gap-2.5 py-1 cursor-pointer group">
      <Checkbox checked={checked} onCheckedChange={onChange} />
      <span className="text-sm text-foreground group-hover:text-primary transition-colors">{label}</span>
    </label>
  );

  return (
    <div className="bg-card rounded-xl border p-5 sticky top-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-bold text-foreground">Filters</h2>
        {hasActiveFilters && (
          <button
            onClick={clearAll}
            className="text-sm text-primary hover:underline"
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* Headshot */}
      <FilterSection title="Headshot">
        <FilterCheckbox label="With photo" checked={filters.headshot.includes('with-photo')} onChange={() => toggleFilter('headshot', 'with-photo')} />
        <FilterCheckbox label="Without photo" checked={filters.headshot.includes('without-photo')} onChange={() => toggleFilter('headshot', 'without-photo')} />
      </FilterSection>

      {/* Columns */}
      <FilterSection title="Columns">
        <FilterCheckbox label="1 Column" checked={filters.columns.includes('one-column')} onChange={() => toggleFilter('columns', 'one-column')} />
        <FilterCheckbox label="2 Columns" checked={filters.columns.includes('two-column')} onChange={() => toggleFilter('columns', 'two-column')} />
        <FilterCheckbox label="Sidebar" checked={filters.columns.includes('sidebar')} onChange={() => toggleFilter('columns', 'sidebar')} />
      </FilterSection>

      {/* Style */}
      <FilterSection title="Style">
        <FilterCheckbox label="Traditional" checked={filters.style.includes('classic')} onChange={() => toggleFilter('style', 'classic')} />
        <FilterCheckbox label="Creative" checked={filters.style.includes('creative')} onChange={() => toggleFilter('style', 'creative')} />
        <FilterCheckbox label="Contemporary" checked={filters.style.includes('modern')} onChange={() => toggleFilter('style', 'modern')} />
        <FilterCheckbox label="Minimal" checked={filters.style.includes('minimal')} onChange={() => toggleFilter('style', 'minimal')} />
        <FilterCheckbox label="Professional" checked={filters.style.includes('professional')} onChange={() => toggleFilter('style', 'professional')} />
      </FilterSection>

      {/* Occupation */}
      <FilterSection title="Occupation">
        {displayedOccupations.map((occ) => (
          <FilterCheckbox
            key={occ}
            label={occ}
            checked={filters.occupation.includes(occ)}
            onChange={() => toggleFilter('occupation', occ)}
          />
        ))}
        <button
          onClick={() => setShowAllOccupations(!showAllOccupations)}
          className="flex items-center gap-1 text-sm text-primary hover:underline mt-2"
        >
          {showAllOccupations ? (
            <>Show less <ChevronUp className="w-3.5 h-3.5" /></>
          ) : (
            <>Show more <ChevronDown className="w-3.5 h-3.5" /></>
          )}
        </button>
      </FilterSection>
    </div>
  );
};

export { type FilterState };
export default TemplateFilterSidebar;
