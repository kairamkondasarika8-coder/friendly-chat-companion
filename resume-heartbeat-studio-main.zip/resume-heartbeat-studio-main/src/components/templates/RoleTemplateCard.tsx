import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Sparkles } from "lucide-react";
import { type Template } from "@/data/templates";
import { type RoleData } from "@/data/industryData";
import { getSampleDataForRoleLevel } from "@/data/roleSampleData";
import { Badge } from "@/components/ui/badge";

interface RoleTemplateCardProps {
  template: Template;
  role: RoleData;
  level: 'fresher' | 'intermediate' | 'experienced';
  isSelected: boolean;
  onSelect: () => void;
}

const RoleTemplateCard = ({
  template,
  role,
  level,
  isSelected,
  onSelect
}: RoleTemplateCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const [selectedColor, setSelectedColor] = useState(template.defaultColor);
  
  const sampleData = getSampleDataForRoleLevel(role.id, level);

  const SectionTitle = ({ children, withLine = true }: { children: string; withLine?: boolean }) => (
    <div className="mb-1">
      <h3 
        className="text-[6px] font-bold uppercase tracking-wider"
        style={{ color: selectedColor }}
      >
        {children}
      </h3>
      {withLine && <div className="h-[0.5px] mt-0.5" style={{ backgroundColor: selectedColor + '40' }} />}
    </div>
  );

  const renderSidebarLayout = () => (
    <div className={`flex h-full ${template.layout === 'sidebar-right' ? 'flex-row-reverse' : ''}`}>
      {/* Sidebar */}
      <div className="w-[38%] p-2.5 text-white" style={{ backgroundColor: selectedColor }}>
        {template.hasPhoto && (
          <div className="w-10 h-10 rounded-full bg-white/20 mx-auto mb-2 flex items-center justify-center">
            <span className="text-[8px] font-bold">{sampleData.name.split(' ').map(n => n[0]).join('')}</span>
          </div>
        )}
        <div className="text-[7px] font-bold text-center mb-0.5">{sampleData.name}</div>
        <div className="text-[5px] text-center opacity-90 mb-2">{sampleData.title}</div>
        
        <div className="h-[0.5px] bg-white/30 mb-2" />
        
        <div className="text-[5px] font-bold uppercase tracking-wider mb-1">Contact</div>
        <div className="space-y-0.5 text-[4.5px] opacity-90 mb-2.5">
          <div>📧 {sampleData.email}</div>
          <div>📱 {sampleData.phone}</div>
          <div>📍 {sampleData.location}</div>
          <div>🔗 {sampleData.linkedin}</div>
          {sampleData.github && <div>💻 {sampleData.github}</div>}
        </div>

        <div className="text-[5px] font-bold uppercase tracking-wider mb-1">Skills</div>
        {Object.entries(sampleData.skills).slice(0, 4).map(([cat, skills]) => (
          <div key={cat} className="mb-1.5">
            <div className="text-[4.5px] font-semibold opacity-80">{cat}</div>
            <div className="text-[4px] opacity-75 leading-relaxed">{skills}</div>
          </div>
        ))}

        {sampleData.certifications.length > 0 && (
          <>
            <div className="text-[5px] font-bold uppercase tracking-wider mb-1 mt-2">Certifications</div>
            {sampleData.certifications.slice(0, 3).map((cert, i) => (
              <div key={i} className="text-[4px] opacity-80 mb-0.5">• {cert}</div>
            ))}
          </>
        )}

        {sampleData.languages && (
          <>
            <div className="text-[5px] font-bold uppercase tracking-wider mb-1 mt-2">Languages</div>
            {sampleData.languages.map((lang, i) => (
              <div key={i} className="text-[4px] opacity-80">• {lang}</div>
            ))}
          </>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 p-2.5">
        <SectionTitle>Professional Summary</SectionTitle>
        <p className="text-[4.5px] text-gray-600 leading-[1.6] mb-2.5">{sampleData.summary}</p>

        <SectionTitle>Work Experience</SectionTitle>
        {sampleData.experience.slice(0, 3).map((exp, i) => (
          <div key={i} className="mb-2">
            <div className="flex justify-between items-baseline">
              <span className="text-[5px] font-bold text-gray-900">{exp.title}</span>
              <span className="text-[4px] text-gray-500">{exp.dates}</span>
            </div>
            <div className="text-[4.5px] text-gray-600 italic">{exp.company} — {exp.location}</div>
            <ul className="mt-0.5">
              {exp.bullets.slice(0, 3).map((b, j) => (
                <li key={j} className="text-[4px] text-gray-600 leading-[1.5] flex">
                  <span className="mr-1" style={{ color: selectedColor }}>•</span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <SectionTitle>Education</SectionTitle>
        {sampleData.education.map((edu, i) => (
          <div key={i} className="mb-1">
            <div className="flex justify-between">
              <span className="text-[5px] font-bold text-gray-900">{edu.degree}</span>
              <span className="text-[4px] text-gray-500">{edu.dates}</span>
            </div>
            <div className="text-[4.5px] text-gray-600">{edu.school}{edu.gpa ? ` | GPA: ${edu.gpa}` : ''}</div>
          </div>
        ))}

        {sampleData.projects && sampleData.projects.length > 0 && (
          <>
            <SectionTitle>Projects</SectionTitle>
            {sampleData.projects.slice(0, 2).map((p, i) => (
              <div key={i} className="mb-1">
                <div className="text-[5px] font-bold text-gray-900">{p.name} <span className="font-normal text-gray-500">| {p.tech}</span></div>
                <div className="text-[4px] text-gray-600">{p.description}</div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );

  const renderTwoColumnLayout = () => (
    <div className="h-full p-2.5">
      {/* Header */}
      <div className="text-center pb-1.5 mb-2 border-b-2" style={{ borderColor: selectedColor }}>
        {template.hasPhoto && (
          <div className="w-10 h-10 rounded-full mx-auto mb-1 flex items-center justify-center" style={{ backgroundColor: selectedColor + '20' }}>
            <span className="text-[8px] font-bold" style={{ color: selectedColor }}>{sampleData.name.split(' ').map(n => n[0]).join('')}</span>
          </div>
        )}
        <div className="text-[9px] font-bold text-gray-900 uppercase tracking-wide">{sampleData.name}</div>
        <div className="text-[6px] font-medium" style={{ color: selectedColor }}>{sampleData.title}</div>
        <div className="text-[4px] text-gray-500 mt-0.5">
          {sampleData.phone} | {sampleData.email} | {sampleData.location}
        </div>
      </div>

      {/* Summary */}
      <SectionTitle>Professional Summary</SectionTitle>
      <p className="text-[4.5px] text-gray-600 leading-[1.6] mb-2">{sampleData.summary}</p>

      {/* Two Column Body */}
      <div className="flex gap-2.5">
        <div className="flex-1">
          <SectionTitle>Work Experience</SectionTitle>
          {sampleData.experience.slice(0, 3).map((exp, i) => (
            <div key={i} className="mb-1.5">
              <div className="text-[5px] font-bold text-gray-900">{exp.title}</div>
              <div className="flex justify-between">
                <span className="text-[4.5px] text-gray-600">{exp.company}</span>
                <span className="text-[4px] text-gray-500">{exp.dates}</span>
              </div>
              {exp.bullets.slice(0, 2).map((b, j) => (
                <div key={j} className="text-[4px] text-gray-600 flex">
                  <span className="mr-1" style={{ color: selectedColor }}>•</span>
                  <span>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="w-[42%]">
          <SectionTitle>Skills</SectionTitle>
          {Object.entries(sampleData.skills).slice(0, 4).map(([cat, skills]) => (
            <div key={cat} className="mb-1">
              <div className="text-[4.5px] font-semibold text-gray-800">{cat}</div>
              <div className="text-[4px] text-gray-600">{skills}</div>
            </div>
          ))}

          <SectionTitle>Education</SectionTitle>
          {sampleData.education.map((edu, i) => (
            <div key={i} className="mb-1">
              <div className="text-[5px] font-bold text-gray-900">{edu.degree}</div>
              <div className="text-[4px] text-gray-600">{edu.school}</div>
              <div className="text-[4px] text-gray-500">{edu.dates}</div>
            </div>
          ))}

          {sampleData.certifications.length > 0 && (
            <>
              <SectionTitle>Certifications</SectionTitle>
              {sampleData.certifications.slice(0, 3).map((c, i) => (
                <div key={i} className="text-[4px] text-gray-600">• {c}</div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );

  const renderOneColumnLayout = () => (
    <div className="h-full p-2.5">
      {/* Header */}
      <div className="text-center mb-2">
        <div className="text-[10px] font-bold text-gray-900 uppercase tracking-wide">{sampleData.name}</div>
        <div className="text-[6px] font-medium" style={{ color: selectedColor }}>{sampleData.title}</div>
        <div className="text-[4px] text-gray-500 mt-0.5">
          {sampleData.location} | {sampleData.phone} | {sampleData.email}
        </div>
        {sampleData.linkedin && <div className="text-[4px] text-gray-500">{sampleData.linkedin}{sampleData.github ? ` | ${sampleData.github}` : ''}</div>}
      </div>
      <div className="h-[1px] mb-2" style={{ backgroundColor: selectedColor }} />

      <SectionTitle>Professional Summary</SectionTitle>
      <p className="text-[4.5px] text-gray-600 leading-[1.6] mb-2">{sampleData.summary}</p>

      <SectionTitle>Skills</SectionTitle>
      <div className="flex flex-wrap gap-x-3 mb-2">
        {Object.entries(sampleData.skills).slice(0, 3).map(([cat, skills]) => (
          <div key={cat} className="mb-0.5">
            <span className="text-[4.5px] font-semibold text-gray-800">{cat}: </span>
            <span className="text-[4px] text-gray-600">{skills}</span>
          </div>
        ))}
      </div>

      <SectionTitle>Work Experience</SectionTitle>
      {sampleData.experience.slice(0, 3).map((exp, i) => (
        <div key={i} className="mb-2">
          <div className="flex justify-between items-baseline">
            <span className="text-[5px] font-bold text-gray-900">{exp.title}</span>
            <span className="text-[4px] text-gray-500 italic">{exp.dates}</span>
          </div>
          <div className="text-[4.5px] text-gray-600">{exp.company} — {exp.location}</div>
          <ul className="mt-0.5">
            {exp.bullets.slice(0, 3).map((b, j) => (
              <li key={j} className="text-[4px] text-gray-600 leading-[1.5] flex">
                <span className="mr-1" style={{ color: selectedColor }}>•</span>
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}

      <SectionTitle>Education</SectionTitle>
      {sampleData.education.map((edu, i) => (
        <div key={i} className="flex justify-between mb-1">
          <div>
            <div className="text-[5px] font-bold text-gray-900">{edu.degree}</div>
            <div className="text-[4.5px] text-gray-600">{edu.school}</div>
          </div>
          <span className="text-[4px] text-gray-500">{edu.dates}</span>
        </div>
      ))}

      {sampleData.certifications.length > 0 && (
        <>
          <SectionTitle>Certifications</SectionTitle>
          <div className="text-[4px] text-gray-600">
            {sampleData.certifications.slice(0, 4).join(' • ')}
          </div>
        </>
      )}
    </div>
  );

  return (
    <motion.div
      className={`relative rounded-lg overflow-hidden cursor-pointer transition-all duration-300 ${
        isSelected ? 'ring-2 ring-primary ring-offset-2' : 'hover:shadow-2xl shadow-lg'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onSelect}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
    >
      {/* Full Page Resume Preview - A4 ratio */}
      <div className="aspect-[210/297] bg-white relative overflow-hidden border border-gray-200">
        {(template.layout === 'sidebar-left' || template.layout === 'sidebar-right') 
          ? renderSidebarLayout() 
          : template.layout === 'two-column' 
            ? renderTwoColumnLayout() 
            : renderOneColumnLayout()
        }
      </div>

      {/* Hover Overlay */}
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 flex items-center justify-center backdrop-blur-[1px]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center">
              <div className="flex flex-wrap justify-center gap-1.5 mb-3 max-w-[180px]">
                {template.colors.map((color) => (
                  <button
                    key={color}
                    className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-110 ${
                      selectedColor === color ? 'border-white scale-110' : 'border-white/30'
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={(e) => { e.stopPropagation(); setSelectedColor(color); }}
                  >
                    {selectedColor === color && <Check className="w-3 h-3 text-white mx-auto" />}
                  </button>
                ))}
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-xs flex items-center gap-1.5 mx-auto"
                onClick={(e) => { e.stopPropagation(); onSelect(); }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                Use This Template
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {isSelected && (
        <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
          <Check className="w-3 h-3" />
        </div>
      )}

      {(template.new || template.popular) && (
        <div className="absolute top-2 left-2">
          <Badge variant={template.new ? "default" : "secondary"} className="text-[9px] px-1.5 py-0.5">
            {template.new ? '✨ New' : '🔥 Popular'}
          </Badge>
        </div>
      )}

      {/* Template name below */}
      <div className="bg-card border-t p-2">
        <div className="text-xs font-medium text-foreground truncate">{template.name}</div>
        <div className="text-[10px] text-muted-foreground capitalize">{template.category} • {template.layout.replace('-', ' ')}</div>
      </div>
    </motion.div>
  );
};

export default RoleTemplateCard;
