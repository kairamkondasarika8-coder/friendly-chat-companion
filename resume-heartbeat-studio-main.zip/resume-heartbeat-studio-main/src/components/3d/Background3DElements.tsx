import { motion } from "framer-motion";

interface Background3DElementsProps {
  variant?: "default" | "subtle" | "colorful";
}

const Background3DElements = ({ variant = "default" }: Background3DElementsProps) => {
  const colors = {
    default: {
      primary: "hsl(var(--primary))",
      accent: "hsl(var(--accent))",
      muted: "hsl(var(--muted))",
    },
    subtle: {
      primary: "hsl(var(--primary) / 0.3)",
      accent: "hsl(var(--accent) / 0.3)",
      muted: "hsl(var(--muted) / 0.5)",
    },
    colorful: {
      primary: "#0d9488",
      accent: "#f97316",
      muted: "#6366f1",
    },
  };

  const currentColors = colors[variant];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
      {/* Large floating orb - top right */}
      <motion.div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-20 blur-3xl"
        style={{ backgroundColor: currentColors.primary }}
        animate={{
          x: [0, 30, 0],
          y: [0, 20, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Medium orb - bottom left */}
      <motion.div
        className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full opacity-15 blur-2xl"
        style={{ backgroundColor: currentColors.accent }}
        animate={{
          x: [0, -20, 0],
          y: [0, -30, 0],
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
      />

      {/* Small floating shapes */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-4 h-4 rounded-full opacity-40"
        style={{ backgroundColor: currentColors.primary }}
        animate={{
          y: [-20, 20, -20],
          x: [-10, 10, -10],
          rotate: [0, 360],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className="absolute top-1/3 right-1/4 w-6 h-6 rounded opacity-30"
        style={{ 
          backgroundColor: currentColors.accent,
          transform: "rotate(45deg)",
        }}
        animate={{
          y: [-15, 25, -15],
          rotate: [45, 225, 45],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1,
        }}
      />

      <motion.div
        className="absolute bottom-1/4 right-1/3 w-3 h-3 rounded-full opacity-50"
        style={{ backgroundColor: currentColors.muted }}
        animate={{
          y: [-25, 15, -25],
          x: [10, -10, 10],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 3,
        }}
      />

      <motion.div
        className="absolute top-2/3 left-1/3 w-8 h-8 rounded-lg opacity-20"
        style={{ backgroundColor: currentColors.primary }}
        animate={{
          y: [-10, 20, -10],
          rotate: [0, 180, 360],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
      />

      {/* Gradient mesh background */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `
            radial-gradient(ellipse at 20% 30%, ${currentColors.primary} 0%, transparent 50%),
            radial-gradient(ellipse at 80% 70%, ${currentColors.accent} 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, ${currentColors.muted} 0%, transparent 60%)
          `,
        }}
      />

      {/* Floating lines */}
      <motion.div
        className="absolute top-1/2 left-0 w-48 h-0.5 opacity-10"
        style={{ 
          background: `linear-gradient(90deg, transparent, ${currentColors.primary}, transparent)`,
        }}
        animate={{
          x: [0, 100, 0],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className="absolute top-1/4 right-0 w-32 h-0.5 opacity-10"
        style={{ 
          background: `linear-gradient(90deg, transparent, ${currentColors.accent}, transparent)`,
        }}
        animate={{
          x: [0, -80, 0],
          opacity: [0.1, 0.15, 0.1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 3,
        }}
      />

      {/* 3D perspective grid effect (subtle) */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          transform: 'perspective(500px) rotateX(60deg)',
          transformOrigin: 'center top',
        }}
      />
    </div>
  );
};

export default Background3DElements;
