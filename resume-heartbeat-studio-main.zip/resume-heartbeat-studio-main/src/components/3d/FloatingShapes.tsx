import { motion } from "framer-motion";

const FloatingShapes = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* 3D Floating Cube */}
      <motion.div
        className="absolute top-20 right-20 w-20 h-20"
        style={{ perspective: "1000px" }}
        animate={{
          rotateX: [0, 360],
          rotateY: [0, 360],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <div
          className="w-full h-full relative"
          style={{ transformStyle: "preserve-3d" }}
        >
          <motion.div
            className="absolute w-full h-full bg-primary/20 border border-primary/30 rounded-lg backdrop-blur-sm"
            style={{ transform: "translateZ(40px)" }}
          />
          <motion.div
            className="absolute w-full h-full bg-primary/10 border border-primary/20 rounded-lg"
            style={{ transform: "rotateY(90deg) translateZ(40px)" }}
          />
          <motion.div
            className="absolute w-full h-full bg-accent/20 border border-accent/30 rounded-lg"
            style={{ transform: "rotateX(90deg) translateZ(40px)" }}
          />
        </div>
      </motion.div>

      {/* 3D Rotating Ring */}
      <motion.div
        className="absolute bottom-40 left-20 w-32 h-32"
        style={{ perspective: "1000px" }}
        animate={{
          rotateY: [0, 360],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <div
          className="w-full h-full rounded-full border-4 border-primary/30"
          style={{ transformStyle: "preserve-3d" }}
        />
      </motion.div>

      {/* Floating Document */}
      <motion.div
        className="absolute top-40 left-1/4 w-16 h-20 bg-card/50 border border-border/50 rounded-lg shadow-lg backdrop-blur-sm"
        animate={{
          y: [-10, 10, -10],
          rotateZ: [-5, 5, -5],
          rotateX: [0, 10, 0],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ perspective: "1000px" }}
      >
        <div className="p-2 space-y-1">
          <div className="h-2 w-10 bg-primary/30 rounded" />
          <div className="h-1 w-12 bg-muted rounded" />
          <div className="h-1 w-8 bg-muted rounded" />
          <div className="h-1 w-10 bg-muted rounded" />
        </div>
      </motion.div>

      {/* 3D Pyramid */}
      <motion.div
        className="absolute bottom-20 right-1/4 w-12 h-12"
        style={{ perspective: "800px" }}
        animate={{
          rotateY: [0, 360],
          rotateX: [20, 20],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <div
          className="w-full h-full relative"
          style={{ transformStyle: "preserve-3d" }}
        >
          <div
            className="absolute w-0 h-0 border-l-[24px] border-r-[24px] border-b-[40px] border-l-transparent border-r-transparent border-b-accent/30"
            style={{ transform: "translateZ(20px)" }}
          />
        </div>
      </motion.div>

      {/* Glowing Orb */}
      <motion.div
        className="absolute top-1/2 right-10 w-24 h-24 rounded-full"
        style={{
          background: "radial-gradient(circle, hsl(174 72% 40% / 0.2) 0%, transparent 70%)",
          boxShadow: "0 0 60px 20px hsl(174 72% 40% / 0.1)",
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Floating Stars */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-accent/40 rounded-full"
          style={{
            top: `${20 + i * 15}%`,
            left: `${10 + i * 20}%`,
          }}
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.4, 0.8, 0.4],
            y: [-5, 5, -5],
          }}
          transition={{
            duration: 3 + i,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.5,
          }}
        />
      ))}

      {/* 3D Hexagon */}
      <motion.div
        className="absolute top-1/3 right-1/3 w-16 h-16"
        style={{ perspective: "600px" }}
        animate={{
          rotateZ: [0, 360],
          rotateY: [0, 180, 0],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <div
          className="w-full h-full"
          style={{
            clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
            background: "linear-gradient(135deg, hsl(174 72% 40% / 0.2), hsl(15 90% 60% / 0.2))",
            border: "1px solid hsl(174 72% 40% / 0.3)",
          }}
        />
      </motion.div>
    </div>
  );
};

export default FloatingShapes;
