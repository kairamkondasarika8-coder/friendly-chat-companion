import { motion } from "framer-motion";

const Hero3DElements = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Animated gradient blobs */}
      <motion.div
        className="absolute -top-20 -left-20 w-96 h-96 rounded-full opacity-30"
        style={{
          background: "radial-gradient(circle, hsl(174 72% 40%) 0%, transparent 70%)",
          filter: "blur(60px)",
        }}
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 30, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className="absolute -bottom-20 -right-20 w-80 h-80 rounded-full opacity-20"
        style={{
          background: "radial-gradient(circle, hsl(15 90% 60%) 0%, transparent 70%)",
          filter: "blur(50px)",
        }}
        animate={{
          scale: [1.2, 1, 1.2],
          x: [0, -20, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* 3D Floating Resume Card */}
      <motion.div
        className="absolute top-1/4 right-1/4 hidden lg:block"
        style={{ perspective: "1200px" }}
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <motion.div
          className="w-40 h-52 bg-card/80 backdrop-blur-lg rounded-xl border border-border/50 shadow-2xl p-4"
          style={{ transformStyle: "preserve-3d" }}
          animate={{
            rotateY: [-15, 15, -15],
            rotateX: [5, -5, 5],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <div className="space-y-2">
            <div className="h-4 w-20 bg-primary/30 rounded" />
            <div className="h-2 w-16 bg-muted rounded" />
            <div className="space-y-1 mt-4">
              <div className="h-1.5 w-full bg-muted/60 rounded" />
              <div className="h-1.5 w-5/6 bg-muted/60 rounded" />
              <div className="h-1.5 w-4/6 bg-muted/60 rounded" />
            </div>
            <div className="mt-3 flex gap-1">
              <div className="h-3 w-8 bg-accent/30 rounded-full" />
              <div className="h-3 w-10 bg-accent/30 rounded-full" />
            </div>
          </div>
          
          {/* Glow effect */}
          <div
            className="absolute inset-0 rounded-xl opacity-50"
            style={{
              background: "linear-gradient(135deg, transparent 0%, hsl(174 72% 40% / 0.1) 50%, transparent 100%)",
            }}
          />
        </motion.div>
      </motion.div>

      {/* 3D Rotating Badge */}
      <motion.div
        className="absolute bottom-1/3 left-1/6 hidden lg:block"
        style={{ perspective: "800px" }}
      >
        <motion.div
          className="w-20 h-20 rounded-full bg-gradient-to-br from-accent/20 to-primary/20 border border-accent/30 flex items-center justify-center shadow-xl"
          animate={{
            rotateY: [0, 360],
            scale: [1, 1.05, 1],
          }}
          transition={{
            rotateY: { duration: 15, repeat: Infinity, ease: "linear" },
            scale: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <span className="text-accent font-bold text-lg">ATS</span>
        </motion.div>
      </motion.div>

      {/* Particle field */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            background: i % 2 === 0 ? "hsl(174 72% 40% / 0.4)" : "hsl(15 90% 60% / 0.4)",
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-10, 10, -10],
            opacity: [0.2, 0.6, 0.2],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: 5 + Math.random() * 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: Math.random() * 2,
          }}
        />
      ))}

      {/* 3D Torus */}
      <motion.div
        className="absolute top-1/2 left-1/3 w-16 h-16 hidden lg:block"
        style={{ perspective: "600px" }}
        animate={{
          rotateX: [0, 360],
          rotateZ: [0, 180],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        <div
          className="w-full h-full rounded-full border-4 border-primary/30"
          style={{
            transformStyle: "preserve-3d",
            boxShadow: "inset 0 0 20px hsl(174 72% 40% / 0.2)",
          }}
        />
      </motion.div>
    </div>
  );
};

export default Hero3DElements;
