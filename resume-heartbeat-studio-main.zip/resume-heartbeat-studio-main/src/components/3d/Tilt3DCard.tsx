import { ReactNode, useRef, useState, useCallback, MouseEvent } from "react";
import { cn } from "@/lib/utils";

interface Tilt3DCardProps {
  children: ReactNode;
  className?: string;
  glareEnabled?: boolean;
  maxTilt?: number;
  maxMove?: number;
  scale?: number;
  perspective?: number;
  transitionSpeed?: number;
}

const Tilt3DCard = ({
  children,
  className,
  glareEnabled = true,
  maxTilt = 8,
  maxMove = 3,
  scale = 1.02,
  perspective = 1000,
  transitionSpeed = 400,
}: Tilt3DCardProps) => {
  const ref = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({
    rotateX: 0,
    rotateY: 0,
    x: 0,
    y: 0,
  });
  const [glarePosition, setGlarePosition] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = useCallback(
    (e: MouseEvent<HTMLDivElement>) => {
      if (!ref.current) return;

      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const mouseX = e.clientX - centerX;
      const mouseY = e.clientY - centerY;

      const rotateX = (mouseY / (rect.height / 2)) * -maxTilt;
      const rotateY = (mouseX / (rect.width / 2)) * maxTilt;
      const moveX = (mouseX / (rect.width / 2)) * maxMove;
      const moveY = (mouseY / (rect.height / 2)) * maxMove;

      // Glare position
      const glareX = ((e.clientX - rect.left) / rect.width) * 100;
      const glareY = ((e.clientY - rect.top) / rect.height) * 100;

      setTransform({ rotateX, rotateY, x: moveX, y: moveY });
      setGlarePosition({ x: glareX, y: glareY });
    },
    [maxTilt, maxMove]
  );

  const handleMouseEnter = useCallback(() => setIsHovered(true), []);
  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
    setTransform({ rotateX: 0, rotateY: 0, x: 0, y: 0 });
  }, []);

  const transformStyle = isHovered
    ? `perspective(${perspective}px) rotateX(${transform.rotateX}deg) rotateY(${transform.rotateY}deg) translateX(${transform.x}px) translateY(${transform.y}px) scale(${scale})`
    : `perspective(${perspective}px) rotateX(0deg) rotateY(0deg) translateX(0px) translateY(0px) scale(1)`;

  return (
    <div
      ref={ref}
      className={cn("relative overflow-hidden", className)}
      style={{
        transform: transformStyle,
        transition: `transform ${transitionSpeed}ms cubic-bezier(0.03, 0.98, 0.52, 0.99)`,
        transformStyle: "preserve-3d",
      }}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {children}
      
      {/* Glare effect */}
      {glareEnabled && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            opacity: isHovered ? 0.15 : 0,
            background: `radial-gradient(circle at ${glarePosition.x}% ${glarePosition.y}%, rgba(255,255,255,0.8) 0%, transparent 60%)`,
          }}
        />
      )}
    </div>
  );
};

export default Tilt3DCard;
