import { useAutoSave } from "@/hooks/use-auto-save";
import { motion, AnimatePresence } from "framer-motion";
import { Cloud, CloudOff, Check, Loader2 } from "lucide-react";

const AutoSaveIndicator = () => {
  const { isSaving, hasUnsavedChanges, lastSaved, getLastSavedText } = useAutoSave();

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 text-xs"
    >
      <AnimatePresence mode="wait">
        {isSaving ? (
          <motion.div
            key="saving"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex items-center gap-1.5 text-muted-foreground"
          >
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>Saving...</span>
          </motion.div>
        ) : hasUnsavedChanges ? (
          <motion.div
            key="unsaved"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex items-center gap-1.5 text-amber-600"
          >
            <CloudOff className="w-3.5 h-3.5" />
            <span>Unsaved changes</span>
          </motion.div>
        ) : lastSaved ? (
          <motion.div
            key="saved"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex items-center gap-1.5 text-green-600"
          >
            <Cloud className="w-3.5 h-3.5" />
            <Check className="w-2.5 h-2.5 -ml-1" />
            <span>{getLastSavedText()}</span>
          </motion.div>
        ) : (
          <motion.div
            key="notsaved"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex items-center gap-1.5 text-muted-foreground"
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>Auto-save enabled</span>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default AutoSaveIndicator;
