import { motion } from "framer-motion";
import Tilt3DCard from "@/components/3d/Tilt3DCard";
import { sampleResumeData } from "@/data/sampleResumeData";
import { Download, Mail, Phone, MapPin, Linkedin, Github } from "lucide-react";

const HeroResumePreview = () => {
  const sample = sampleResumeData;
  const primaryColor = "#1e3a5f"; // Navy - professional

  return (
    <div className="relative" style={{ perspective: "1200px" }}>
      <Tilt3DCard className="rounded-2xl" maxTilt={8} maxMove={6} scale={1.02} perspective={1200}>
        {/* Full-page A4 Resume */}
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden" style={{ aspectRatio: '210/297' }}>
          <div className="flex h-full">
            {/* Left Sidebar */}
            <div className="w-[180px] p-5 text-white relative" style={{ backgroundColor: primaryColor }}>
              {/* Profile */}
              <div className="w-20 h-20 mx-auto rounded-full bg-white/15 border-2 border-white/30 flex items-center justify-center mb-4">
                <span className="text-2xl font-bold text-white/90">
                  {sample.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>

              {/* Contact */}
              <div className="mb-5">
                <h3 className="text-[9px] font-bold uppercase tracking-widest mb-2 border-b border-white/20 pb-1">Contact</h3>
                <div className="space-y-1.5 text-[7.5px]">
                  <div className="flex items-center gap-1.5"><Phone className="w-2.5 h-2.5 flex-shrink-0" /><span>{sample.phone}</span></div>
                  <div className="flex items-center gap-1.5"><Mail className="w-2.5 h-2.5 flex-shrink-0" /><span className="break-all text-[7px]">{sample.email}</span></div>
                  <div className="flex items-center gap-1.5"><MapPin className="w-2.5 h-2.5 flex-shrink-0" /><span>{sample.location}</span></div>
                  <div className="flex items-center gap-1.5"><Linkedin className="w-2.5 h-2.5 flex-shrink-0" /><span>linkedin.com/in/alex</span></div>
                  <div className="flex items-center gap-1.5"><Github className="w-2.5 h-2.5 flex-shrink-0" /><span>github.com/alex</span></div>
                </div>
              </div>

              {/* Skills */}
              <div className="mb-5">
                <h3 className="text-[9px] font-bold uppercase tracking-widest mb-2 border-b border-white/20 pb-1">Skills</h3>
                <div className="space-y-1.5">
                  {[
                    { name: "React.js", level: 95 },
                    { name: "TypeScript", level: 90 },
                    { name: "Node.js", level: 85 },
                    { name: "Python", level: 75 },
                    { name: "AWS", level: 80 },
                    { name: "Docker", level: 70 },
                    { name: "PostgreSQL", level: 85 },
                  ].map((skill, i) => (
                    <div key={i}>
                      <div className="flex justify-between text-[7px] mb-0.5">
                        <span>{skill.name}</span>
                        <span className="opacity-60">{skill.level}%</span>
                      </div>
                      <div className="w-full h-1 bg-white/20 rounded-full">
                        <div className="h-full bg-white/80 rounded-full" style={{ width: `${skill.level}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Languages */}
              <div className="mb-5">
                <h3 className="text-[9px] font-bold uppercase tracking-widest mb-2 border-b border-white/20 pb-1">Languages</h3>
                <div className="space-y-1 text-[7.5px]">
                  <div className="flex justify-between"><span>English</span><span className="opacity-60">Native</span></div>
                  <div className="flex justify-between"><span>Spanish</span><span className="opacity-60">Conversational</span></div>
                </div>
              </div>

              {/* Certifications */}
              <div>
                <h3 className="text-[9px] font-bold uppercase tracking-widest mb-2 border-b border-white/20 pb-1">Certifications</h3>
                <div className="text-[7px] space-y-1 opacity-90">
                  <div>• AWS Solutions Architect</div>
                  <div>• Google Cloud Professional</div>
                  <div>• MongoDB Certified Dev</div>
                </div>
              </div>
            </div>

            {/* Right Content */}
            <div className="flex-1 p-5">
              {/* Name & Title */}
              <div className="mb-4">
                <h1 className="text-xl font-bold tracking-wide" style={{ color: primaryColor }}>{sample.name}</h1>
                <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-gray-500">{sample.title}</p>
              </div>

              {/* Summary */}
              <div className="mb-4">
                <h2 className="text-[10px] font-bold uppercase tracking-wider mb-1.5 pb-0.5 border-b-2" style={{ color: primaryColor, borderColor: primaryColor }}>
                  Professional Summary
                </h2>
                <p className="text-[8px] text-gray-600 leading-relaxed">{sample.summary}</p>
              </div>

              {/* Experience */}
              <div className="mb-4">
                <h2 className="text-[10px] font-bold uppercase tracking-wider mb-2 pb-0.5 border-b-2" style={{ color: primaryColor, borderColor: primaryColor }}>
                  Work Experience
                </h2>
                {sample.experience.slice(0, 2).map((exp, i) => (
                  <div key={i} className="mb-3">
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-[9px] font-bold text-gray-900">{exp.title}</h3>
                      <span className="text-[7px] text-gray-500">{exp.dates}</span>
                    </div>
                    <p className="text-[8px] text-gray-500 italic mb-0.5">{exp.company} | {exp.location}</p>
                    <ul className="space-y-0.5">
                      {exp.bullets.slice(0, 3).map((b, j) => (
                        <li key={j} className="text-[7.5px] text-gray-600 flex">
                          <span className="mr-1.5" style={{ color: primaryColor }}>•</span><span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              {/* Projects */}
              <div className="mb-4">
                <h2 className="text-[10px] font-bold uppercase tracking-wider mb-1.5 pb-0.5 border-b-2" style={{ color: primaryColor, borderColor: primaryColor }}>
                  Key Projects
                </h2>
                {sample.projects?.slice(0, 2).map((p, i) => (
                  <div key={i} className="mb-1.5">
                    <span className="text-[8px] font-bold text-gray-900">{p.name}</span>
                    <span className="text-[7px] text-gray-500"> | {p.tech}</span>
                    <p className="text-[7px] text-gray-600">{p.description}</p>
                  </div>
                ))}
              </div>

              {/* Education */}
              <div>
                <h2 className="text-[10px] font-bold uppercase tracking-wider mb-1.5 pb-0.5 border-b-2" style={{ color: primaryColor, borderColor: primaryColor }}>
                  Education
                </h2>
                {sample.education.map((edu, i) => (
                  <div key={i} className="flex justify-between">
                    <div>
                      <div className="text-[9px] font-bold text-gray-900">{edu.degree}</div>
                      <div className="text-[8px] text-gray-600">{edu.school} | GPA: {edu.gpa}</div>
                    </div>
                    <span className="text-[7px] text-gray-500">{edu.dates}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Tilt3DCard>

      {/* Floating ATS Badge */}
      <motion.div
        className="absolute -top-4 -right-4 z-10"
        animate={{ y: [-5, 5, -5], rotateZ: [-2, 2, -2] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        <Tilt3DCard className="rounded-full" maxTilt={15} scale={1.1}>
          <div className="bg-accent text-accent-foreground px-4 py-2 rounded-full text-sm font-bold shadow-xl">
            ATS Score: 95%
          </div>
        </Tilt3DCard>
      </motion.div>

      {/* Floating Download Card */}
      <motion.div
        className="absolute -bottom-6 -left-6 z-10"
        animate={{ y: [-8, 8, -8], x: [-3, 3, -3] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
      >
        <Tilt3DCard className="rounded-xl" maxTilt={10} scale={1.05}>
          <div className="bg-card rounded-xl shadow-xl border border-border p-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center">
                <Download className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-xs text-foreground">Download Ready</p>
                <p className="text-[10px] text-muted-foreground">PDF & Word</p>
              </div>
            </div>
          </div>
        </Tilt3DCard>
      </motion.div>
    </div>
  );
};

export default HeroResumePreview;
