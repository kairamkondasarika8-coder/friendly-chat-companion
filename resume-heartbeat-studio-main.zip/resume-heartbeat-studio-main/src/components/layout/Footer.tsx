import { Link } from "react-router-dom";
import { FileText, Twitter, Linkedin, Github, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";

const Footer = () => {
  const [email, setEmail] = useState("");

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Subscribed!",
        description: "You'll receive our latest resume tips and updates.",
      });
      setEmail("");
    }
  };

  const footerLinks = {
    product: [
      { label: "Templates", href: "/templates" },
      { label: "Create Resume", href: "/editor" },
      { label: "ATS Checker", href: "/editor" },
      { label: "Download Resume", href: "/editor" },
    ],
    company: [
      { label: "About Us", href: "/about" },
      { label: "Testimonials", href: "/#testimonials" },
      { label: "Contact", href: "/about" },
    ],
    resources: [
      { label: "Resume Tips", href: "/about" },
      { label: "Career Advice", href: "/about" },
      { label: "FAQ", href: "/about" },
    ],
  };

  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Github, href: "#", label: "GitHub" },
    { icon: Mail, href: "mailto:hello@resumepro.com", label: "Email" },
  ];

  return (
    <footer className="bg-foreground text-background">
      <div className="container-wide section-padding">
        {/* Newsletter Section */}
        <div className="text-center mb-16 pb-16 border-b border-background/10">
          <h3 className="font-display text-2xl md:text-3xl font-bold mb-4">
            Get Resume Tips & Updates
          </h3>
          <p className="text-background/70 mb-6 max-w-md mx-auto">
            Join thousands of job seekers receiving weekly career advice and resume tips.
          </p>
          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 bg-background/10 border-background/20 text-background placeholder:text-background/50 focus:border-primary"
            />
            <Button type="submit" className="btn-accent whitespace-nowrap">
              Subscribe
            </Button>
          </form>
        </div>

        {/* Main Footer Content */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center">
                <FileText className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-xl">
                Resume<span className="text-primary">Pro</span>
              </span>
            </Link>
            <p className="text-background/70 text-sm mb-4">
              Build professional, ATS-friendly resumes in minutes. 100% free, no hidden costs.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-lg bg-background/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all duration-200"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Product</h4>
            <ul className="space-y-2">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-background/70 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-background/70 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Resources</h4>
            <ul className="space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-background/70 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-background/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-background/50">
          <p>© {new Date().getFullYear()} ResumePro. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="#" className="hover:text-background transition-colors">
              Privacy Policy
            </Link>
            <Link to="#" className="hover:text-background transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
