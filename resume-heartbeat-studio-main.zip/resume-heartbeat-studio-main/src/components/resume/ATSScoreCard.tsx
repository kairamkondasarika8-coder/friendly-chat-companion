import { calculateATSScore, getScoreColor, getScoreLabel } from "@/utils/atsScore";
import { ResumeData } from "@/stores/resumeStore";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, AlertCircle, Lightbulb } from "lucide-react";

interface ATSScoreCardProps {
  data: ResumeData;
}

const ATSScoreCard = ({ data }: ATSScoreCardProps) => {
  const result = calculateATSScore(data);

  return (
    <div className="card-elevated rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-lg font-semibold text-foreground">
          ATS Score
        </h3>
        <div className={`text-3xl font-bold ${getScoreColor(result.score)}`}>
          {result.score}%
        </div>
      </div>

      <div className="mb-4">
        <Progress value={result.score} className="h-3" />
        <p className={`text-sm mt-1 ${getScoreColor(result.score)}`}>
          {getScoreLabel(result.score)}
        </p>
      </div>

      {/* Breakdown */}
      <div className="space-y-3 mb-6">
        {result.breakdown.map((item) => (
          <div key={item.category} className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{item.category}</span>
            <div className="flex items-center gap-2">
              <span className="text-foreground font-medium">
                {item.score}/{item.maxScore}
              </span>
              {item.score >= item.maxScore * 0.8 ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <AlertCircle className="w-4 h-4 text-yellow-500" />
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Suggestions */}
      {result.suggestions.length > 0 && (
        <div className="border-t border-border pt-4">
          <div className="flex items-center gap-2 mb-3 text-sm font-medium text-foreground">
            <Lightbulb className="w-4 h-4 text-accent" />
            Suggestions to Improve
          </div>
          <ul className="space-y-2">
            {result.suggestions.map((suggestion, index) => (
              <li
                key={index}
                className="text-sm text-muted-foreground flex items-start gap-2"
              >
                <span className="text-accent mt-1">•</span>
                {suggestion}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ATSScoreCard;
