import { ResumeData } from "@/stores/resumeStore";
import { templates } from "@/data/templates";
import { Mail, Phone, MapPin, Globe, Linkedin, Github } from "lucide-react";

interface ResumePreviewProps {
  data: ResumeData;
}

const ResumePreview = ({ data }: ResumePreviewProps) => {
  const template = templates.find((t) => t.id === data.selectedTemplate) || templates[0];
  const accentColor = template.defaultColor;

  const { personalInfo, education, experience, skills, projects, certifications, extracurriculars } = data;

  return (
    <div
      className="bg-white text-gray-900 p-8 min-h-[800px] shadow-lg"
      id="resume-preview"
      style={{ fontFamily: "'Times New Roman', 'Georgia', serif" }}
    >
      {/* Header - ATS Friendly */}
      <header className="mb-4 pb-3 border-b-2" style={{ borderColor: accentColor }}>
        <h1
          className="text-2xl font-bold mb-1 uppercase tracking-wide text-center"
          style={{ color: accentColor }}
        >
          {personalInfo.fullName || "YOUR NAME"}
        </h1>
        <p className="text-sm text-gray-600 text-center mb-2">
          {personalInfo.location || "City, State, Country"}
        </p>
        <div className="flex flex-wrap justify-center gap-3 text-xs text-gray-700">
          {personalInfo.phone && (
            <span className="flex items-center gap-1">
              <Phone className="w-3 h-3" />
              {personalInfo.phone}
            </span>
          )}
          {personalInfo.email && (
            <span className="flex items-center gap-1">
              <Mail className="w-3 h-3" />
              {personalInfo.email}
            </span>
          )}
          {personalInfo.linkedin && (
            <span className="flex items-center gap-1">
              <Linkedin className="w-3 h-3" />
              {personalInfo.linkedin}
            </span>
          )}
          {personalInfo.github && (
            <span className="flex items-center gap-1">
              <Github className="w-3 h-3" />
              {personalInfo.github}
            </span>
          )}
          {personalInfo.website && (
            <span className="flex items-center gap-1">
              <Globe className="w-3 h-3" />
              {personalInfo.website}
            </span>
          )}
        </div>
      </header>

      {/* Profile/Summary */}
      {personalInfo.summary && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-1 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Profile
          </h2>
          <p className="text-xs leading-relaxed text-gray-700">
            {personalInfo.summary}
          </p>
        </section>
      )}

      {/* Education */}
      {education.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Education
          </h2>
          <div className="space-y-2">
            {education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-xs text-gray-900">{edu.school}</h3>
                    <p className="text-xs text-gray-600 italic">
                      {edu.degree}
                      {edu.field && ` in ${edu.field}`}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-600">
                      {edu.startDate} - {edu.endDate}
                    </span>
                    {edu.gpa && (
                      <p className="text-xs text-gray-600">CGPA: {edu.gpa}</p>
                    )}
                  </div>
                </div>
                {edu.description && (
                  <ul className="text-xs text-gray-700 mt-1 ml-4 list-disc">
                    {edu.description.split('\n').map((item, i) => (
                      <li key={i}>{item.replace(/^[•\-]\s*/, '')}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Work Experience
          </h2>
          <div className="space-y-3">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <h3 className="font-bold text-xs text-gray-900">{exp.position}</h3>
                    <p className="text-xs text-gray-600 italic">
                      {exp.company}
                      {exp.location && `, ${exp.location}`}
                    </p>
                  </div>
                  <span className="text-xs text-gray-600 whitespace-nowrap">
                    {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                  </span>
                </div>
                {exp.description && (
                  <ul className="text-xs text-gray-700 ml-4 list-disc space-y-0.5">
                    {exp.description.split('\n').filter(line => line.trim()).map((item, i) => (
                      <li key={i}>{item.replace(/^[•\-]\s*/, '')}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Projects
          </h2>
          <div className="space-y-2">
            {projects.map((project) => (
              <div key={project.id}>
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-xs text-gray-900">
                    {project.name}
                    {project.technologies && (
                      <span className="font-normal italic text-gray-600">
                        {" | "}{project.technologies}
                      </span>
                    )}
                  </h3>
                  {project.link && (
                    <span className="text-xs text-gray-500">{project.link}</span>
                  )}
                </div>
                {project.description && (
                  <ul className="text-xs text-gray-700 mt-1 ml-4 list-disc">
                    {project.description.split('\n').filter(line => line.trim()).map((item, i) => (
                      <li key={i}>{item.replace(/^[•\-]\s*/, '')}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Technical Skills */}
      {skills.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Technical Skills
          </h2>
          <div className="text-xs text-gray-700 space-y-1">
            {/* Group skills by category if available */}
            {(() => {
              const categorizedSkills = skills.reduce((acc, skill) => {
                const cat = skill.category || 'Skills';
                if (!acc[cat]) acc[cat] = [];
                acc[cat].push(skill.name);
                return acc;
              }, {} as Record<string, string[]>);
              
              return Object.entries(categorizedSkills).map(([category, skillNames]) => (
                <p key={category}>
                  <span className="font-bold">{category}:</span> {skillNames.join(', ')}
                </p>
              ));
            })()}
          </div>
        </section>
      )}

      {/* Certifications */}
      {certifications && certifications.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Certificates
          </h2>
          <div className="space-y-1.5">
            {certifications.map((cert) => (
              <div key={cert.id} className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-xs text-gray-900">{cert.name}</h3>
                  {cert.description && (
                    <p className="text-xs text-gray-600 italic">{cert.description}</p>
                  )}
                </div>
                <span className="text-xs text-gray-600 whitespace-nowrap">
                  Issued: {cert.date}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Leadership / Extracurricular */}
      {extracurriculars && extracurriculars.length > 0 && (
        <section className="mb-4">
          <h2
            className="text-sm font-bold mb-2 uppercase tracking-wider border-b pb-1"
            style={{ color: accentColor, borderColor: accentColor }}
          >
            Leadership / Extracurricular
          </h2>
          <div className="space-y-2">
            {extracurriculars.map((activity) => (
              <div key={activity.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-xs text-gray-900">{activity.title}</h3>
                    {activity.description && (
                      <p className="text-xs text-gray-600 italic">{activity.description}</p>
                    )}
                  </div>
                  <span className="text-xs text-gray-600 whitespace-nowrap">
                    {activity.startDate} - {activity.endDate}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Empty State */}
      {!personalInfo.fullName &&
        experience.length === 0 &&
        education.length === 0 &&
        skills.length === 0 && (
          <div className="text-center text-gray-400 py-20">
            <p className="text-lg mb-2">Your resume preview will appear here</p>
            <p className="text-sm">Start filling in your details on the left</p>
          </div>
        )}
    </div>
  );
};

export default ResumePreview;
